#!/bin/bash
# WSL 混合训练脚本 — 顺序执行 4 个配置
# 结果保存在 output/checkpoints/train/avtrack/
# 日志保存在 logs/
set -e

cd /mnt/e/member/sth/IAVtrack-main
SAVE_DIR=./output
LOG_DIR=$HOME/iavtrack_logs
mkdir -p $LOG_DIR

echo "=============================================="
echo "  IAVtrack Mixed Training Pipeline"
echo "  Checkpoints: $SAVE_DIR/checkpoints/train/avtrack/"
echo "  Logs:        $LOG_DIR/"
echo "=============================================="

# ====== Step 1: Baseline (100 ep) ======
LOG1="$LOG_DIR/train_baseline.log"
echo ""
echo ">>> [1/4] Training Baseline (100 epochs)  |  log: $LOG1"
python tracking/train.py --script avtrack --config deit_tiny_patch16_224_30ep_baseline --save_dir $SAVE_DIR --mode single 2>&1 | tee $LOG1

# ====== Step 2: Baseline + BDDR (100 ep) ======
LOG2="$LOG_DIR/train_bddr.log"
echo ""
echo ">>> [2/4] Training Baseline + BDDR (100 epochs)  |  log: $LOG2"
python tracking/train.py --script avtrack --config ablation_02_bddr_v2 --save_dir $SAVE_DIR --mode single 2>&1 | tee $LOG2

# ====== Step 3: Baseline + MSCA (100 ep) ======
LOG3="$LOG_DIR/train_msca.log"
echo ""
echo ">>> [3/4] Training Baseline + MSCA (100 epochs)  |  log: $LOG3"
python tracking/train.py --script avtrack --config ablation_01_msca_hfda_v2 --save_dir $SAVE_DIR --mode single 2>&1 | tee $LOG3

# ====== Step 4: BDDR(frozen) + MSCA (Stage2, 100 ep) ======
LOG4="$LOG_DIR/train_stage2.log"
echo ""
echo ">>> [4/4] Training BDDR(frozen) + MSCA (Stage2, 100 epochs)  |  log: $LOG4"
python tracking/train.py --script avtrack --config ablation_stage2_msca_bddr_mixed --save_dir $SAVE_DIR --mode single 2>&1 | tee $LOG4

echo ""
echo "=============================================="
echo "  All training completed!"
echo "  Checkpoints: $SAVE_DIR/checkpoints/train/avtrack/"
echo "  Logs:        $LOG_DIR/"
echo "=============================================="
