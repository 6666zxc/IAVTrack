"""
BDDR v2: Background-Debiased Discriminative Routing

Fixes for mixed-dataset training (LaSOT + GOT-10k + UAV123):
  - neg_source_k=64 for stable bg_beacon across datasets
  - channel_alpha=0.02 conservative init to avoid corrupting foreground
  - alpha regularization (direct, gradient bypasses r_pos/r_neg)
  - temperature=5.0 on response to spread r away from 0.5
  - per-dataset gate diagnostics in aux dict
  - fuse small-init (std=0.01) for early gradient flow
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class BDDR(nn.Module):
    def __init__(
        self,
        dim: int = 192,
        num_pos_prompts: int = 4,
        num_neg_prompts: int = 2,
        neg_source_k: int = 64,
        ema_momentum: float = 0.9,
        use_learnable_pneg: bool = True,
        neg_temperature: float = None,
        pos_beacon_top_k: int = 8,
        spatial_decay: bool = True,
    ):
        super().__init__()
        self.dim = dim
        self.num_pos_prompts = num_pos_prompts
        self.num_neg_prompts = num_neg_prompts
        self.neg_source_k = neg_source_k
        self.ema_momentum = ema_momentum
        self.use_learnable_pneg = use_learnable_pneg
        self.pos_beacon_top_k = pos_beacon_top_k
        self.spatial_decay = spatial_decay
        # Softer temperature for bg_beacon mode to avoid r_neg dominating r_pos
        self.neg_temperature = neg_temperature if neg_temperature is not None else (
            1.5 if not use_learnable_pneg else 5.0
        )

        # ===== BCR: channel-wise debiasing (conservative init) =====
        self.channel_alpha = nn.Parameter(torch.ones(1, 1, dim) * 0.02)

        # ===== DANP: static prompts (VPT style, small random init) =====
        self.pos_static = nn.Parameter(torch.empty(num_pos_prompts, dim))
        nn.init.trunc_normal_(self.pos_static, std=0.02)
        self.neg_static = nn.Parameter(torch.empty(num_neg_prompts, dim))
        nn.init.trunc_normal_(self.neg_static, std=0.02)

        # ===== DANP: dynamic prompt projections =====
        self.pos_proj = nn.Linear(dim, num_pos_prompts * dim)
        self.neg_proj = nn.Linear(dim, num_neg_prompts * dim)

        # ===== Modulation strengths (init near target to avoid LR_BDDR bottleneck) =====
        self.alpha_pos_raw = nn.Parameter(torch.tensor(-1.0))   # σ(-1.0) ≈ 0.27
        self.alpha_neg_raw = nn.Parameter(torch.tensor(-1.0))

        # ===== Discriminator (for adversarial loss) =====
        self.discriminator = nn.Sequential(
            nn.Linear(dim, dim), nn.GELU(),
            nn.Linear(dim, 1),
        )

        # ===== BDDR: residual fusion (small-init for early gradient flow) =====
        self.fuse = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Linear(dim * 2, dim),
        )
        nn.init.trunc_normal_(self.fuse[-1].weight, std=0.01)
        nn.init.zeros_(self.fuse[-1].bias)

        # ===== Inference-only EMA negative beacon =====
        self.register_buffer('ema_neg_beacon', None, persistent=False)

    # ------------------------------------------------------------------
    # Beacon construction
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _get_pos_beacon(self, z: torch.Tensor) -> torch.Tensor:
        """Top-K magnitude-weighted positive beacon.

        Only the top-K highest-magnitude template tokens contribute to the beacon.
        For small UAV targets, this prevents background tokens from diluting the
        foreground representation (e.g. a 20×20 px target uses only ~2-4 tokens).
        """
        K = min(self.pos_beacon_top_k, z.shape[1])
        z_norm = z.norm(dim=-1, keepdim=True)                    # [B, N, 1]
        _, top_idx = z_norm.squeeze(-1).topk(K, dim=1)           # [B, K]
        z_top = z.gather(1, top_idx.unsqueeze(-1).expand(-1, -1, z.size(-1)))  # [B, K, C]
        z_norm_top = z_top.norm(dim=-1, keepdim=True)            # [B, K, 1]
        weights = F.softmax(z_norm_top * 2.0, dim=1)             # [B, K, 1]
        return (z_top * weights).sum(dim=1, keepdim=True)        # [B, 1, C]

    @torch.no_grad()
    def _get_bg_beacon(self, x: torch.Tensor,
                       pos_beacon: torch.Tensor) -> torch.Tensor:
        """Background beacon. Training: bottom-K; Inference: EMA.

        When spatial_decay is enabled, tokens farther from the image center
        receive a similarity penalty, making them more likely to be selected
        as background. UAV targets tend to stay near the center of the drone's
        field of view, so edge tokens are almost certainly background.
        """
        if self.training or self.ema_neg_beacon is None:
            K = min(self.neg_source_k, x.shape[1])
            sim_rough = (F.normalize(x, dim=-1)
                         * F.normalize(pos_beacon, dim=-1)).sum(dim=-1)

            if self.spatial_decay:
                N = x.shape[1]
                H = W = int(N ** 0.5)
                y = torch.arange(H, device=x.device, dtype=torch.float32)
                xc = torch.arange(W, device=x.device, dtype=torch.float32)
                gy, gx = torch.meshgrid(y, xc, indexing='ij')
                cy, cx = (H - 1) / 2.0, (W - 1) / 2.0
                dist = ((gy - cy) ** 2 + (gx - cx) ** 2).sqrt().flatten()  # [N]
                dist_norm = dist / (dist.max() + 1e-8)                     # [0, 1]
                sim_rough = sim_rough - 0.3 * dist_norm.unsqueeze(0)       # [B, N]

            _, low_idx = sim_rough.topk(K, dim=1, largest=False)
            bg_tokens = x.gather(1, low_idx.unsqueeze(-1).expand(-1, -1, x.size(-1)))
            return bg_tokens.mean(dim=1, keepdim=True)            # [B, 1, C]
        else:
            bg = self.ema_neg_beacon.to(x.device)
            if bg.dim() == 1:
                bg = bg.unsqueeze(0)
            return bg.unsqueeze(1)

    @torch.no_grad()
    def _get_neg_beacon(self, x_debiased: torch.Tensor,
                        pos_beacon: torch.Tensor) -> torch.Tensor:
        """Neg beacon from bottom-K tokens furthest from pos."""
        x_norm = F.normalize(x_debiased, dim=-1)
        t_norm = F.normalize(pos_beacon, dim=-1)
        scores = (x_norm * t_norm).sum(dim=-1)                   # [B, 256]
        K = min(self.neg_source_k, x_debiased.shape[1])
        _, low_idx = scores.topk(K, dim=1, largest=False)
        neg_tokens = x_debiased.gather(
            1, low_idx.unsqueeze(-1).expand(-1, -1, x_debiased.size(-1))
        )
        return neg_tokens.mean(dim=1, keepdim=True)               # [B, 1, C]

    # ------------------------------------------------------------------
    # Soft modulation (DANP style)
    # ------------------------------------------------------------------

    def _compute_modulation(self, x_debiased: torch.Tensor,
                            pos_beacon: torch.Tensor,
                            neg_beacon: torch.Tensor,
                            bg_beacon: torch.Tensor = None):
        """DANP-style bidirectional soft modulation."""
        B, N, C = x_debiased.shape

        # Dynamic prompts from beacons
        p_pos_dyn = self.pos_proj(pos_beacon.squeeze(1))

        # Combine static + dynamic, L2-normalize
        p_pos = (self.pos_static.unsqueeze(0)
                 + p_pos_dyn.view(B, self.num_pos_prompts, C)).mean(dim=1)
        p_pos = F.normalize(p_pos, dim=-1)

        if self.use_learnable_pneg:
            # Learnable p_neg: static + dynamic projection (VPT style)
            p_neg_dyn = self.neg_proj(neg_beacon.squeeze(1))
            p_neg = (self.neg_static.unsqueeze(0)
                     + p_neg_dyn.view(B, self.num_neg_prompts, C)).mean(dim=1)
            p_neg = F.normalize(p_neg, dim=-1)
        else:
            # Instance-level p_neg: directly use bg_beacon (avoids cross-dataset conflict)
            p_neg = F.normalize(bg_beacon.squeeze(1), dim=-1)

        # Scalar response per token (temperature=5.0 to spread r away from 0.5)
        x_norm = F.normalize(x_debiased, dim=-1)
        r_pos = torch.sigmoid(5.0 * (x_norm * p_pos.unsqueeze(1)).sum(dim=-1))
        r_neg = torch.sigmoid(self.neg_temperature * (x_norm * p_neg.unsqueeze(1)).sum(dim=-1))

        # Modulation strengths
        alpha_pos = torch.sigmoid(self.alpha_pos_raw)
        alpha_neg = torch.sigmoid(self.alpha_neg_raw)

        # Modulation factor
        f = 1 + alpha_pos * (2 * r_pos - 1) - alpha_neg * (2 * r_neg - 1)

        return f, (p_pos, p_neg), (r_pos, r_neg)

    # ------------------------------------------------------------------
    # Diagnostics (shared by compute_gate and forward)
    # ------------------------------------------------------------------

    def _compute_diagnostics(self, f, pos_beacon, neg_beacon, r_pos, r_neg,
                             p_pos=None, p_neg=None, bg_beacon=None):
        """Compute all diagnostic losses and stats."""
        alpha_pos = torch.sigmoid(self.alpha_pos_raw)
        alpha_neg = torch.sigmoid(self.alpha_neg_raw)

        # Direct alpha regularization: prevent collapse to 0 (bypasses r_pos/r_neg)
        alpha_target = 0.25
        alpha_loss = F.relu(alpha_target - alpha_pos) + F.relu(alpha_target - alpha_neg)

        # Contrastive: r_pos and r_neg must not both be high nor both low
        if self.use_learnable_pneg:
            contrast_loss = ((r_pos + r_neg - 1.0) ** 2).mean()
        else:
            # With fixed p_neg (=bg_beacon), r_neg is pinned by feature geometry.
            # Contrastive loss would force r_pos → 1 - r_neg ≈ 0.24 uniformly,
            # killing foreground enhancement ability. Disable it.
            contrast_loss = torch.tensor(0.0, device=f.device)

        # Beacon separability
        pos_beacon_n = F.normalize(pos_beacon, dim=-1)
        neg_beacon_n = F.normalize(neg_beacon, dim=-1)
        beacon_sim = (pos_beacon_n * neg_beacon_n).sum(dim=-1).mean()

        # Gate spread
        gate_spread = (f - 1.0).abs().mean()

        # Debiased vs original feature magnitude ratio
        # (computed outside this method since it needs x_debiased)

        diag = {
            'gate_magnitude_loss': alpha_loss + contrast_loss,
            'bddr/contrast_loss': contrast_loss.detach(),
            'bddr/beacon_sim': beacon_sim,
            'bddr/alpha_pos': alpha_pos,
            'bddr/alpha_neg': alpha_neg,
            'bddr/channel_alpha_mean': self.channel_alpha.mean(),
            'bddr/channel_alpha_std': self.channel_alpha.std(),
            'bddr/gate_spread': gate_spread,
            'bddr/r_pos_mean': r_pos.mean(),
            'bddr/r_pos_std': r_pos.std(),
            'bddr/r_neg_mean': r_neg.mean(),
            'bddr/r_neg_std': r_neg.std(),
        }

        # p_neg quality diagnostics (key for bg_beacon mode)
        if p_pos is not None and p_neg is not None:
            p_pos_n = F.normalize(p_pos, dim=-1)
            p_neg_n = F.normalize(p_neg, dim=-1)
            diag['bddr/pneg_vs_pos_sim'] = (p_pos_n * p_neg_n).sum(dim=-1).mean()
        if p_neg is not None and bg_beacon is not None:
            bg_n = F.normalize(bg_beacon.squeeze(1), dim=-1)
            p_neg_n = F.normalize(p_neg, dim=-1)
            diag['bddr/pneg_vs_bg_sim'] = (p_neg_n * bg_n).sum(dim=-1).mean()

        return diag

    # ------------------------------------------------------------------
    # Gate-only computation (for decoupled pipeline)
    # ------------------------------------------------------------------

    def compute_gate(self, z: torch.Tensor, x: torch.Tensor,
                     skip_mask: torch.Tensor = None):
        """Compute modulation gate. Returns f [B, N] and aux dict.

        skip_mask: [B] bool tensor. True = skip BDDR for this sample (return f=1).
                    Used to exclude COCO from BDDR training to prevent p_pos corruption.
        """
        if skip_mask is not None:
            skip_mask = skip_mask.bool()
        if skip_mask is not None and skip_mask.all():
            # All samples skipped: return identity gate + zero beacon
            B, N, C = x.shape
            zero_beacon = torch.zeros(B, 1, C, device=x.device, dtype=x.dtype)
            return torch.ones(B, N, device=x.device, dtype=x.dtype), {
                'bg_beacon': zero_beacon,
                'f': torch.ones(B, N, device=x.device, dtype=x.dtype),
            }

        pos_beacon = self._get_pos_beacon(z)
        bg_beacon = self._get_bg_beacon(x, pos_beacon)
        x_debiased = x - torch.clamp(self.channel_alpha, min=0) * bg_beacon
        neg_beacon = self._get_neg_beacon(x_debiased, pos_beacon)
        f, (p_pos, p_neg), (r_pos, r_neg) = self._compute_modulation(x_debiased, pos_beacon, neg_beacon, bg_beacon)

        # Override skipped samples to identity
        if skip_mask is not None and skip_mask.any():
            f = f.clone()
            f[skip_mask] = 1.0
            bg_beacon = bg_beacon.clone()
            bg_beacon[skip_mask] = 0.0

        # Diagnostics
        diag = self._compute_diagnostics(f, pos_beacon, neg_beacon, r_pos, r_neg,
                                         p_pos, p_neg, bg_beacon)

        # Feature magnitude monitoring
        diag['bddr/debias_ratio'] = (x_debiased.norm() / (x.norm() + 1e-8)).detach()
        diag['bddr/bg_beacon_norm'] = bg_beacon.norm().detach()

        aux = {
            'f': f,
            'p_pos': p_pos,
            'p_neg': p_neg,
            'bg_beacon': bg_beacon,
            'pos_beacon': pos_beacon,
        }
        aux.update(diag)
        return f, aux

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(self, z: torch.Tensor, x: torch.Tensor):
        pos_beacon = self._get_pos_beacon(z)
        bg_beacon = self._get_bg_beacon(x, pos_beacon)
        x_debiased = x - torch.clamp(self.channel_alpha, min=0) * bg_beacon
        neg_beacon = self._get_neg_beacon(x_debiased, pos_beacon)
        f, (p_pos, p_neg), (r_pos, r_neg) = self._compute_modulation(x_debiased, pos_beacon, neg_beacon, bg_beacon)

        x_mod = x_debiased * f.unsqueeze(-1)
        x_out = x + self.fuse(x_mod)

        diag = self._compute_diagnostics(f, pos_beacon, neg_beacon, r_pos, r_neg,
                                         p_pos, p_neg, bg_beacon)

        aux = {'f': f, 'p_pos': p_pos, 'p_neg': p_neg}
        aux.update(diag)
        return x_out, f, aux

    # ------------------------------------------------------------------
    # Inference-time state update
    # ------------------------------------------------------------------

    @torch.no_grad()
    def update_state(self, x: torch.Tensor, f: torch.Tensor,
                     momentum: float = None):
        if momentum is None:
            momentum = self.ema_momentum

        K = min(self.neg_source_k, x.shape[1])
        _, low_idx = f.topk(K, dim=1, largest=False)
        distractor_tokens = x.gather(
            1, low_idx.unsqueeze(-1).expand(-1, -1, x.size(-1))
        )
        neg_beacon_curr = distractor_tokens.mean(dim=1)

        if self.ema_neg_beacon is None:
            self.ema_neg_beacon = neg_beacon_curr
        else:
            self.ema_neg_beacon = (
                momentum * self.ema_neg_beacon
                + (1 - momentum) * neg_beacon_curr
            )
