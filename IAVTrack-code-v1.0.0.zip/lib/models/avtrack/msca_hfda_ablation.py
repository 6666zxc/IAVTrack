"""MSCA-HFDA ablation variants (non-invasive).

复用 MSCA_HFDA_V2 的稳定内部实现，不改动核心模块。每个变体只替换
需要关闭的分支为 nn.Identity，并把对应的可学习融合权重置零，从而让
``forward`` 原样运行、无需重写计算图。

Modes (via ``cfg.MODEL.ABLATION.MSCA_HFDA_MODE``):
  - 'full'      : MSCA + HFDA（原始实现）。
  - 'msca_only' : 仅多尺度通道注意力（MSCA），关闭 HFDA。
  - 'hfda_only' : 仅 Haar 小波频域注意力（HFDA），关闭 MSCA。
"""

import torch
import torch.nn as nn

from lib.models.avtrack.msca_hfda import MSCA_HFDA_V2


class MSCA_HFDA_MSCA_ONLY(MSCA_HFDA_V2):
    """仅保留 MSCA 分支；HFDA 退化为恒等，beta 固定为 0。

    beta 必须从 Parameter 改成固定 buffer（register_buffer），原因是：
    1) 直接给 Parameter 属性赋普通张量会触发 nn.Module 的类型检查报错；
    2) Stage2 冻结逻辑会遍历 named_parameters() 把所有 'msca_hfda' 参数重新置为
       可训练，若保留 Parameter 会导致 beta 在训练中漂移、把恒等分支加回来。
    buffer 不属于参数、不参与梯度，且会随 .to()/.cuda() 一起迁移设备。
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.hfda = nn.Identity()
        beta = self.beta
        self._parameters.pop('beta', None)
        self.register_buffer('beta', torch.zeros_like(beta))


class MSCA_HFDA_HFDA_ONLY(MSCA_HFDA_V2):
    """仅保留 HFDA 分支；MSCA 退化为恒等，alpha 固定为 0。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.msca_search = nn.Identity()
        self.msca_tmpl = nn.Identity()
        alpha = self.alpha
        self._parameters.pop('alpha', None)
        self.register_buffer('alpha', torch.zeros_like(alpha))


def build_msca_hfda(cfg_abl, dim):
    """根据配置开关选择 MSCA-HFDA 消融变体。

    cfg_abl 为 ``cfg.MODEL.ABLATION``（easydict）。缺省时保持 'full'，
    因此旧配置无需任何改动即可继续工作。
    """
    mode = 'full'
    if cfg_abl is not None:
        mode = getattr(cfg_abl, 'MSCA_HFDA_MODE', 'full')

    if mode == 'msca_only':
        return MSCA_HFDA_MSCA_ONLY(dim=dim)
    if mode == 'hfda_only':
        return MSCA_HFDA_HFDA_ONLY(dim=dim)

    # 'full'（默认）
    return MSCA_HFDA_V2(dim=dim)
