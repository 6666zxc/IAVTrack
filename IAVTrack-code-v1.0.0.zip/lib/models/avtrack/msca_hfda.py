"""
MSCA-HFDA V2: Multi-Scale Channel Attention + Haar-Wavelet Frequency-Domain Attention
======================================================================================
V2 Changes:
1. Additive fusion (a*alpha + b*beta)
2. Safe LayerScale init (1e-5) to fix double-zero-init bug
3. HFDA removes LL gate and zeros HH band (saves SR75)
4. LevelGate adds 3x3 DW Conv (spatial-frequency interaction)
5. Pre-fuse layer before Haar (Simple Fusion concept)
6. Asymmetric MSCA for Template/Search resolution mismatch
"""
from __future__ import annotations
from typing import Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F


class HaarWaveletTransform2D(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        ll = torch.tensor([[1.0, 1.0], [1.0, 1.0]]) * 0.5
        lh = torch.tensor([[1.0, 1.0], [-1.0, -1.0]]) * 0.5
        hl = torch.tensor([[1.0, -1.0], [1.0, -1.0]]) * 0.5
        hh = torch.tensor([[1.0, -1.0], [-1.0, 1.0]]) * 0.5
        self.register_buffer("filters", torch.stack([ll, lh, hl, hh]).unsqueeze(1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        if h % 2 or w % 2:
            x = F.pad(x, (0, w % 2, 0, h % 2), mode="replicate")
        filters = self.filters.repeat(c, 1, 1, 1)
        out = F.conv2d(x, filters, stride=2, groups=c)
        return out.view(b, c, 4, out.shape[-2], out.shape[-1])

    def inverse(self, coeffs: torch.Tensor) -> torch.Tensor:
        b, c, _, hh, hw = coeffs.shape
        ll, lh, hl, hh_band = torch.unbind(coeffs, dim=2)
        a00 = (ll + lh + hl + hh_band) * 0.5
        a01 = (ll + lh - hl - hh_band) * 0.5
        a10 = (ll - lh + hl - hh_band) * 0.5
        a11 = (ll - lh - hl + hh_band) * 0.5
        out = torch.empty(b, c, hh * 2, hw * 2, device=ll.device, dtype=ll.dtype)
        out[..., 0::2, 0::2] = a00
        out[..., 0::2, 1::2] = a01
        out[..., 1::2, 0::2] = a10
        out[..., 1::2, 1::2] = a11
        return out


class MultiScaleChannelAttention(nn.Module):
    def __init__(self, dim: int, dilations: Tuple[int, ...] = (1, 2, 3), reduction: int = 4):
        super().__init__()
        self.dw_convs = nn.ModuleList([
            nn.Conv2d(dim, dim, 3, padding=d, dilation=d, groups=dim, bias=False)
            for d in dilations
        ])
        self.dw_norms = nn.ModuleList([nn.GroupNorm(1, dim) for _ in dilations])
        self.fuse = nn.Conv2d(dim * len(dilations), dim, 1, bias=False)
        self.fuse_norm = nn.GroupNorm(1, dim)
        r = max(dim // reduction, 2)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(dim, r, bias=False), nn.ReLU(inplace=True),
            nn.Linear(r, dim, bias=False), nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _, _ = x.shape
        feats = [n(c(x)) for c, n in zip(self.dw_convs, self.dw_norms)]
        fused = self.fuse_norm(self.fuse(torch.cat(feats, dim=1)))
        ch = self.fc(self.gap(fused).view(b, c)).view(b, c, 1, 1)
        return ch * fused


class _LevelGateV2(nn.Module):
    def __init__(self, dim: int, num_bands: int = 2, reduction: int = 4):
        super().__init__()
        in_ch = num_bands * dim
        r = max(in_ch // reduction, 2)
        self.gate = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False),
            nn.BatchNorm2d(in_ch),
            nn.Conv2d(in_ch, r, 1, bias=False), nn.GELU(),
            nn.Conv2d(r, in_ch, 1, bias=False), nn.Sigmoid(),
        )
        self.bias = nn.Parameter(torch.zeros(1, in_ch, 1, 1))

    def forward(self, stacked: torch.Tensor) -> torch.Tensor:
        return stacked * self.gate(stacked) + self.bias


class HaarWaveletFrequencyAttentionV2(nn.Module):
    def __init__(self, dim: int, levels: int = 1, reduction: int = 4):
        super().__init__()
        self.dim = dim
        self.levels = levels
        self.haar = HaarWaveletTransform2D()
        self.pre_fuse = nn.Sequential(nn.Conv2d(dim, dim, 1, bias=False), nn.GELU())
        self.level_gates = nn.ModuleList([
            _LevelGateV2(dim, num_bands=2, reduction=reduction) for _ in range(levels)
        ])

    def _decompose(self, x):
        level_details = []
        cur = x
        for _ in range(self.levels):
            coeffs = self.haar(cur)
            ll, lh, hl, hh = torch.unbind(coeffs, dim=2)
            level_details.append([lh, hl])
            cur = ll
        return cur, level_details

    def _reconstruct(self, ll_final, level_details):
        cur = ll_final
        for k in range(self.levels - 1, -1, -1):
            lh, hl = level_details[k]
            hh = torch.zeros_like(lh)
            coeffs = torch.stack([cur, lh, hl, hh], dim=2)
            cur = self.haar.inverse(coeffs)
        return cur

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h, w = x.shape[-2:]
        x = self.pre_fuse(x)
        ll_final, level_details = self._decompose(x)
        for k in range(self.levels):
            stacked = torch.cat(level_details[k], dim=1)
            attended = self.level_gates[k](stacked)
            level_details[k] = list(torch.split(attended, self.dim, dim=1))
        out = self._reconstruct(ll_final, level_details)
        return out[..., :h, :w]


class MSCA_HFDA_V2(nn.Module):
    def __init__(self, dim: int, dilations_search: Tuple[int, ...] = (1, 2),
                 dilations_tmpl: Tuple[int, ...] = (1,), haar_levels: int = 1,
                 reduction: int = 4, attn_shortcut: bool = True):
        super().__init__()
        self.dim = dim
        self.attn_shortcut = attn_shortcut
        self.proj_in = nn.Conv2d(dim, dim, 1, bias=False)
        self.activation = nn.GELU()
        
        # Asymmetric MSCA
        self.msca_search = MultiScaleChannelAttention(dim, dilations_search, reduction)
        self.msca_tmpl = MultiScaleChannelAttention(dim, dilations_tmpl, reduction)
        
        self.hfda = HaarWaveletFrequencyAttentionV2(dim, haar_levels, reduction)
        self.alpha = nn.Parameter(torch.ones(1, dim, 1, 1))
        self.beta = nn.Parameter(torch.ones(1, dim, 1, 1))
        
        self.proj_out = nn.Conv2d(dim, dim, 1, bias=False)
        # LayerScale init (5e-3, stage2 freeze-friendly)
        self.layer_scale = nn.Parameter(torch.full((1, dim, 1, 1), 5e-3))
        
        # Stats for monitoring
        self.stats = {}

    def forward(self, x: torch.Tensor, is_search: bool = True) -> torch.Tensor:
        sc = x if self.attn_shortcut else 0
        x = self.activation(self.proj_in(x))
        a = self.msca_search(x) if is_search else self.msca_tmpl(x)
        b = self.hfda(x)
        combined = a * self.alpha + b * self.beta
        out = self.proj_out(combined) * self.layer_scale + sc
        
        # Monitoring stats
        with torch.no_grad():
            a_norm = a.norm(dim=1).mean()
            b_norm = b.norm(dim=1).mean()
            out_norm = out.norm(dim=1).mean()
            in_norm = sc.norm(dim=1).mean() if isinstance(sc, torch.Tensor) else 0
            
            msca_contrib = (a_norm * self.alpha.mean()).item()
            hfda_contrib = (b_norm * self.beta.mean()).item()
            total_contrib = msca_contrib + hfda_contrib + 1e-8
            
            self.stats = {
                'input_norm':       in_norm.item() if isinstance(in_norm, torch.Tensor) else in_norm,
                'msca_norm':        a_norm.item(),
                'hfda_norm':        b_norm.item(),
                'layer_scale':      self.layer_scale.mean().item(),
                'alpha_mean':       self.alpha.mean().item(),
                'alpha_std':        self.alpha.std().item(),
                'beta_mean':        self.beta.mean().item(),
                'beta_std':         self.beta.std().item(),
                'msca_contrib_ratio': msca_contrib / total_contrib,
                'hfda_contrib_ratio': hfda_contrib / total_contrib,
                'out_norm':         out_norm.item(),
                'out_input_ratio':  (out_norm / (in_norm + 1e-8)).item() if isinstance(in_norm, torch.Tensor) else 0,
            }
        
        return out


# Alias for backward compatibility
MSCA_HFDA = MSCA_HFDA_V2

def build_msca_fda(d_model: int, **kwargs) -> MSCA_HFDA_V2:
    return MSCA_HFDA_V2(dim=d_model, **kwargs)
