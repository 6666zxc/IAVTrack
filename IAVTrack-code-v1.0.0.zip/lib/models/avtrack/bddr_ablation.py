"""
BDDR ablation variants (non-invasive).

These subclasses reuse the stable BDDR internals (beacon construction,
modulation, diagnostics) from ``bddr.py`` without touching the core module.
The real ViT integration point only calls ``compute_gate`` (see
``vision_transformer.py``), so each variant overrides that single method.

Modes (selected via ``cfg.MODEL.ABLATION.BDDR_MODE``):
  - 'full'      : original BDDR (soft routing + channel debias + neg modulation).
  - 'wo_debias' : channel-wise debias disabled; modulation/neg still applied on raw x.
  - 'wo_neg'    : negative modulation removed -> f = 1 + alpha_pos * (2*r_pos - 1).
  - 'bcr'       : hard top-K routing contrast (f in {0,1}), emulating BCR pruning
                  within the fixed-shape soft-routing interface.
"""

import torch
import torch.nn as nn

from lib.models.avtrack.bddr import BDDR


class BDDR_WO_DEBIAS(BDDR):
    """Channel-wise debias disabled (alpha * bg_beacon removed everywhere)."""

    def compute_gate(self, z, x, skip_mask=None):
        if skip_mask is not None:
            skip_mask = skip_mask.bool()
        if skip_mask is not None and skip_mask.all():
            B, N, C = x.shape
            zero_beacon = torch.zeros(B, 1, C, device=x.device, dtype=x.dtype)
            return torch.ones(B, N, device=x.device, dtype=x.dtype), {
                'bg_beacon': zero_beacon,
                'f': torch.ones(B, N, device=x.device, dtype=x.dtype),
            }

        pos_beacon = self._get_pos_beacon(z)
        bg_beacon = self._get_bg_beacon(x, pos_beacon)

        # No debias: modulation operates on raw x.
        neg_beacon = self._get_neg_beacon(x, pos_beacon)
        f, (p_pos, p_neg), (r_pos, r_neg) = self._compute_modulation(
            x, pos_beacon, neg_beacon, bg_beacon
        )

        if skip_mask is not None and skip_mask.any():
            f = f.clone()
            f[skip_mask] = 1.0

        diag = self._compute_diagnostics(f, pos_beacon, neg_beacon, r_pos, r_neg,
                                         p_pos, p_neg, bg_beacon)
        # Effective debias is identity (ratio = 1.0); log the beacon magnitude for reference.
        diag['bddr/debias_ratio'] = (x.norm() / (x.norm() + 1e-8)).detach()
        diag['bddr/bg_beacon_norm'] = bg_beacon.norm().detach()

        # Return zero bg_beacon so the outer ViT line
        #   x_debiased = x - channel_alpha * bg_beacon
        # collapses to x (no core file change required).
        zero_beacon = torch.zeros_like(bg_beacon)
        aux = {
            'f': f,
            'p_pos': p_pos,
            'p_neg': p_neg,
            'bg_beacon': zero_beacon,
            'pos_beacon': pos_beacon,
        }
        aux.update(diag)
        return f, aux


class BDDR_WO_NEG(BDDR):
    """Negative modulation removed; positive-only soft routing."""

    def compute_gate(self, z, x, skip_mask=None):
        if skip_mask is not None:
            skip_mask = skip_mask.bool()
        if skip_mask is not None and skip_mask.all():
            B, N, C = x.shape
            zero_beacon = torch.zeros(B, 1, C, device=x.device, dtype=x.dtype)
            return torch.ones(B, N, device=x.device, dtype=x.dtype), {
                'bg_beacon': zero_beacon,
                'f': torch.ones(B, N, device=x.device, dtype=x.dtype),
            }

        pos_beacon = self._get_pos_beacon(z)
        bg_beacon = self._get_bg_beacon(x, pos_beacon)
        x_debiased = x - torch.clamp(self.channel_alpha, min=0) * bg_beacon
        neg_beacon = self._get_neg_beacon(x_debiased, pos_beacon)

        # Compute the full modulation only to obtain (p_pos, p_neg, r_pos, r_neg),
        # then drop the negative term from the gate.
        _, (p_pos, p_neg), (r_pos, r_neg) = self._compute_modulation(
            x_debiased, pos_beacon, neg_beacon, bg_beacon
        )
        alpha_pos = torch.sigmoid(self.alpha_pos_raw)
        f = 1 + alpha_pos * (2 * r_pos - 1)

        if skip_mask is not None and skip_mask.any():
            f = f.clone()
            f[skip_mask] = 1.0

        diag = self._compute_diagnostics(f, pos_beacon, neg_beacon, r_pos, r_neg,
                                         p_pos, p_neg, bg_beacon)
        diag['bddr/debias_ratio'] = (x_debiased.norm() / (x.norm() + 1e-8)).detach()
        diag['bddr/bg_beacon_norm'] = bg_beacon.norm().detach()

        aux = {
            'f': f,
            'p_pos': p_pos,
            'p_neg': p_neg,
            'bg_beacon': bg_beacon,
            'pos_beacon': pos_beacon,
        }
        aux.update(diag)
        return f, aux


class BDDR_BCR(BDDR):
    """Hard top-K routing contrast (BCR-style pruning emulation).

    The foreground response r_pos is used as the routing score; only the top-K
    tokens survive (f=1) and the rest are dropped (f=0). The fusion head is
    re-created with a zero first-layer bias so that fuse(0) == 0, i.e. dropped
    tokens pass through unchanged (x + 0), matching hard pruning semantics
    under the fixed [B, N, C] shape constraint.
    """

    def __init__(self, dim=192, keep_ratio=0.5, **kwargs):
        super().__init__(dim=dim, **kwargs)
        self.keep_ratio = float(keep_ratio)

        # fuse(0) == 0 so pruned tokens are unchanged by the residual fusion.
        self.fuse = nn.Sequential(
            nn.Linear(dim, dim * 2, bias=False),
            nn.GELU(),
            nn.Linear(dim * 2, dim),
        )
        nn.init.trunc_normal_(self.fuse[-1].weight, std=0.01)
        nn.init.zeros_(self.fuse[-1].bias)

    def compute_gate(self, z, x, skip_mask=None):
        if skip_mask is not None:
            skip_mask = skip_mask.bool()
        if skip_mask is not None and skip_mask.all():
            B, N, C = x.shape
            zero_beacon = torch.zeros(B, 1, C, device=x.device, dtype=x.dtype)
            return torch.ones(B, N, device=x.device, dtype=x.dtype), {
                'bg_beacon': zero_beacon,
                'f': torch.ones(B, N, device=x.device, dtype=x.dtype),
            }

        pos_beacon = self._get_pos_beacon(z)
        bg_beacon = self._get_bg_beacon(x, pos_beacon)
        x_debiased = x - torch.clamp(self.channel_alpha, min=0) * bg_beacon
        neg_beacon = self._get_neg_beacon(x_debiased, pos_beacon)

        _, (p_pos, p_neg), (r_pos, r_neg) = self._compute_modulation(
            x_debiased, pos_beacon, neg_beacon, bg_beacon
        )

        # Hard routing: keep top-K tokens by foreground response.
        N = x.shape[1]
        K = max(1, int(round(self.keep_ratio * N)))
        _, top_idx = r_pos.topk(K, dim=1)
        f = torch.zeros_like(r_pos)
        f.scatter_(1, top_idx, 1.0)

        if skip_mask is not None and skip_mask.any():
            f = f.clone()
            f[skip_mask] = 1.0

        diag = self._compute_diagnostics(f, pos_beacon, neg_beacon, r_pos, r_neg,
                                         p_pos, p_neg, bg_beacon)
        diag['bddr/debias_ratio'] = (x_debiased.norm() / (x.norm() + 1e-8)).detach()
        diag['bddr/bg_beacon_norm'] = bg_beacon.norm().detach()

        aux = {
            'f': f,
            'p_pos': p_pos,
            'p_neg': p_neg,
            'bg_beacon': bg_beacon,
            'pos_beacon': pos_beacon,
        }
        aux.update(diag)
        return f, aux


def build_bddr(cfg_abl, dim):
    """Factory selecting the BDDR ablation variant from config switches.

    cfg_abl is ``cfg.MODEL.ABLATION`` (easydict). Uses defaults when a key is
    absent so existing configs keep working unchanged.
    """
    mode = 'full'
    use_learnable_pneg = True
    spatial_decay = True
    keep_ratio = 0.5

    if cfg_abl is not None:
        mode = getattr(cfg_abl, 'BDDR_MODE', 'full')
        use_learnable_pneg = bool(getattr(cfg_abl, 'USE_LEARNABLE_PNEG', True))
        spatial_decay = bool(getattr(cfg_abl, 'BDDR_SPATIAL_DECAY', True))
        keep_ratio = float(getattr(cfg_abl, 'BDDR_BCR_KEEP_RATIO', 0.5))

    if mode == 'wo_debias':
        return BDDR_WO_DEBIAS(dim=dim, use_learnable_pneg=use_learnable_pneg,
                              spatial_decay=spatial_decay)
    if mode == 'wo_neg':
        return BDDR_WO_NEG(dim=dim, use_learnable_pneg=use_learnable_pneg,
                           spatial_decay=spatial_decay)
    if mode == 'bcr':
        return BDDR_BCR(dim=dim, keep_ratio=keep_ratio,
                        use_learnable_pneg=use_learnable_pneg,
                        spatial_decay=spatial_decay)

    # 'full' (default)
    return BDDR(dim=dim, use_learnable_pneg=use_learnable_pneg,
                spatial_decay=spatial_decay)
