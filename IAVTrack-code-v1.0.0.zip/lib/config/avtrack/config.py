from easydict import EasyDict as edict
import yaml

"""
Add default config for AVTrack.
"""
cfg = edict()

# MODEL
cfg.MODEL = edict()
cfg.MODEL.PRETRAIN_FILE = "mae_pretrain_vit_base.pth"
cfg.MODEL.IS_DISTILL = False
cfg.MODEL.EXTRA_MERGER = False

cfg.MODEL.RETURN_INTER = False
cfg.MODEL.RETURN_STAGES = []

# MODEL.BACKBONE
cfg.MODEL.BACKBONE = edict()
cfg.MODEL.BACKBONE.TYPE = "vit_base_patch16_224"
cfg.MODEL.BACKBONE.STRIDE = 16
cfg.MODEL.BACKBONE.MID_PE = False
cfg.MODEL.BACKBONE.SEP_SEG = False
cfg.MODEL.BACKBONE.CAT_MODE = 'direct'
cfg.MODEL.BACKBONE.MERGE_LAYER = 0
cfg.MODEL.BACKBONE.ADD_CLS_TOKEN = False
cfg.MODEL.BACKBONE.CLS_TOKEN_USE_MODE = 'ignore'

cfg.MODEL.BACKBONE.CE_KEEP_RATIO = []
cfg.MODEL.BACKBONE.CE_TEMPLATE_RANGE = 'ALL'  # choose between ALL, CTR_POINT, CTR_REC, GT_BOX

# Ablation switches (train + backbone). Set False to measure contribution of each part.
cfg.MODEL.ABLATION = edict()
cfg.MODEL.ABLATION.USE_BDDR = False
cfg.MODEL.ABLATION.USE_MSCA_HFDA = False
cfg.MODEL.ABLATION.USE_ADAPTIVE_SKIP = True
cfg.MODEL.ABLATION.USE_FOCAL_IOU = False
cfg.MODEL.ABLATION.USE_DAU_LIKE = False
cfg.MODEL.ABLATION.USE_LEARNABLE_PNEG = True

# BDDR ablation variant (only used when USE_BDDR is True).
# BDDR_MODE: 'full' | 'wo_debias' | 'wo_neg' | 'bcr'
cfg.MODEL.ABLATION.BDDR_MODE = 'full'
# Hard top-K keep ratio, only used when BDDR_MODE == 'bcr'.
cfg.MODEL.ABLATION.BDDR_BCR_KEEP_RATIO = 0.5

# MSCA-HFDA ablation variant (only used when USE_MSCA_HFDA is True).
# MSCA_HFDA_MODE: 'full' | 'msca_only' | 'hfda_only'
cfg.MODEL.ABLATION.MSCA_HFDA_MODE = 'full'

cfg.MODEL.NUM_OBJECT_QUERIES = 1  # used when saving all boxes in the tracker

# MODEL.HEAD
cfg.MODEL.HEAD = edict()
cfg.MODEL.HEAD.TYPE = "CENTER"
cfg.MODEL.HEAD.NUM_CHANNELS = 256

# TRAIN
cfg.TRAIN = edict()
cfg.TRAIN.LR = 0.0001
cfg.TRAIN.WEIGHT_DECAY = 0.0001
cfg.TRAIN.EPOCH = 500
cfg.TRAIN.LR_DROP_EPOCH = 400
cfg.TRAIN.BATCH_SIZE = 32
cfg.TRAIN.NUM_WORKER = 8
cfg.TRAIN.OPTIMIZER = "ADAMW"
cfg.TRAIN.BACKBONE_MULTIPLIER = 0.1
cfg.TRAIN.GIOU_WEIGHT = 2.0
cfg.TRAIN.L1_WEIGHT = 5.0
cfg.TRAIN.FREEZE_LAYERS = [0, ]
cfg.TRAIN.PRINT_INTERVAL = 50
cfg.TRAIN.VAL_EPOCH_INTERVAL = 20
cfg.TRAIN.GRAD_CLIP_NORM = 0.1
cfg.TRAIN.AMP = False

cfg.TRAIN.CE_START_EPOCH = 20  # candidate elimination start epoch
cfg.TRAIN.CE_WARM_EPOCH = 80  # candidate elimination warm up epoch
cfg.TRAIN.DROP_PATH_RATE = 0.1  # drop path rate for ViT backbone
cfg.TRAIN.TOKEN_COMPRESS_LAMBDA = 1.0
cfg.TRAIN.STAGE2_TRAIN = False  # freeze backbone+BDDR, only train MSCA-HFDA+head (use with PRETRAIN_FILE='AVTrack_ep0045.pth.tar')
cfg.TRAIN.CASO_STAGE4_TRAIN = False  # CASO Stage 4: freeze backbone, train MSCA+BDDR+Head with tiny per-module LR

# TRAIN.SCHEDULER
cfg.TRAIN.SCHEDULER = edict()
cfg.TRAIN.SCHEDULER.TYPE = "step"
cfg.TRAIN.SCHEDULER.DECAY_RATE = 0.1
cfg.TRAIN.SCHEDULER.WARMUP_EPOCHS = 3
# Per-module LR for Stage 4 (CASO): used only when CASO_STAGE4_TRAIN=True
cfg.TRAIN.SCHEDULER.LR_MSCA = 2e-6
cfg.TRAIN.SCHEDULER.LR_BDDR = 5e-6
cfg.TRAIN.SCHEDULER.LR_HEAD = 5e-6

# DATA
cfg.DATA = edict()
cfg.DATA.SAMPLER_MODE = "causal"  # sampling methods
cfg.DATA.MEAN = [0.485, 0.456, 0.406]
cfg.DATA.STD = [0.229, 0.224, 0.225]
cfg.DATA.MAX_SAMPLE_INTERVAL = 200
# DATA.TRAIN
cfg.DATA.TRAIN = edict()
cfg.DATA.TRAIN.DATASETS_NAME = ["LASOT", "GOT10K_vottrain", "UAV123_train"]
cfg.DATA.TRAIN.DATASETS_RATIO = [0.4, 0.45, 0.15]
cfg.DATA.TRAIN.SAMPLE_PER_EPOCH = 60000
# DATA.VAL
cfg.DATA.VAL = edict()
cfg.DATA.VAL.DATASETS_NAME = ["LASOT_val", "GOT10K_votval", "UAV123_val"]
cfg.DATA.VAL.DATASETS_RATIO = [0.4, 0.45, 0.15]
cfg.DATA.VAL.SAMPLE_PER_EPOCH = 10000
# DATA.SEARCH
cfg.DATA.SEARCH = edict()
cfg.DATA.SEARCH.SIZE = 320
cfg.DATA.SEARCH.SIZE_EVA = 224
cfg.DATA.SEARCH.FACTOR = 5.0
cfg.DATA.SEARCH.CENTER_JITTER = 4.5
cfg.DATA.SEARCH.SCALE_JITTER = 0.5
cfg.DATA.SEARCH.NUMBER = 1
# DATA.TEMPLATE
cfg.DATA.TEMPLATE = edict()
cfg.DATA.TEMPLATE.NUMBER = 1
cfg.DATA.TEMPLATE.SIZE = 128
cfg.DATA.TEMPLATE.SIZE_EVA = 112
cfg.DATA.TEMPLATE.FACTOR = 2.0
cfg.DATA.TEMPLATE.CENTER_JITTER = 0
cfg.DATA.TEMPLATE.SCALE_JITTER = 0

# TEST
cfg.TEST = edict()
cfg.TEST.TEMPLATE_FACTOR = 2.0
cfg.TEST.TEMPLATE_SIZE = 128
cfg.TEST.SEARCH_FACTOR = 5.0
cfg.TEST.SEARCH_SIZE = 320
cfg.TEST.EPOCH = 500

# Optional: use a different training run's checkpoint (inference-only ablation).
cfg.TEST.CHECKPOINT_NAME = ""

# Test-time post-processing ablation
cfg.TEST.ABLATION = edict()
cfg.TEST.ABLATION.USE_ATC = False

# —— ATC: Adaptive Threshold via Calibration ——
cfg.TEST.ATC_ALPHA = 0.92             # EMA weight for template update (higher = more conservative)
cfg.TEST.ATC_WINDOW = 50              # sliding window size for calibration
cfg.TEST.ATC_REFIT_INTERVAL = 10       # re-fit calibration every N frames
cfg.TEST.ATC_PMIN = 0.50              # absolute minimum p_max to allow update
cfg.TEST.ATC_SIM_LOW = 0.60           # minimum cos_sim(z_new, z_old) to allow update
cfg.TEST.ATC_EVAL_INTERVAL = 1       # ATC 评估间隔：1=每帧评估(原版)；>1=interval-anchored，仅锚点帧做门控与更新

# —— Template-update strategy ablation (对应 BACTrack Table V) ——
# UPDATE_MODE: 'none' (只用首帧) / 'always' (每帧) / 'fixed_interval' (每 N 帧) / 'fixed_thresh' (p_max > 阈值) / 'atc' (自适应)
cfg.TEST.UPDATE_MODE = 'none'
cfg.TEST.UPDATE_INTERVAL = 10         # for 'fixed_interval'
cfg.TEST.UPDATE_THRESH = 0.50         # for 'fixed_thresh'

# —— ATC internal-component ablation (G1/G2/G3 及辅助机制) ——
cfg.TEST.ATC_USE_FAILURE_DETECT = True  # 失败检测 + 硬重置
cfg.TEST.ATC_USE_PEAK_QUALITY = True    # 双峰抑制
cfg.TEST.ATC_USE_TEMPORAL = True        # 时序一致性（连续帧确认）
cfg.TEST.ATC_USE_G1 = True              # G1: peak > 校准阈值
cfg.TEST.ATC_USE_G2 = True              # G2: p_max > pmin
cfg.TEST.ATC_USE_G3 = True              # G3: 余弦相似度
cfg.TEST.ATC_USE_ANCHOR = True          # anchor 正则（拉回 z_t0）


def _edict2dict(dest_dict, src_edict):
    if isinstance(dest_dict, dict) and isinstance(src_edict, dict):
        for k, v in src_edict.items():
            if not isinstance(v, edict):
                dest_dict[k] = v
            else:
                dest_dict[k] = {}
                _edict2dict(dest_dict[k], v)
    else:
        return


def gen_config(config_file):
    cfg_dict = {}
    _edict2dict(cfg_dict, cfg)
    with open(config_file, 'w', encoding='utf-8') as f:
        yaml.dump(cfg_dict, f, default_flow_style=False)


def _update_config(base_cfg, exp_cfg):
    if isinstance(base_cfg, dict) and isinstance(exp_cfg, edict):
        for k, v in exp_cfg.items():
            if k in base_cfg:
                if not isinstance(v, dict):
                    base_cfg[k] = v
                else:
                    _update_config(base_cfg[k], v)
            else:
                print("Warning: {} not exist in config.py, using YAML value".format(k))
    else:
        return


def update_config_from_file(filename, base_cfg=None):
    exp_config = None
    with open(filename, encoding='utf-8') as f:
        exp_config = edict(yaml.safe_load(f))
        if base_cfg is not None:
            _update_config(base_cfg, exp_config)
        else:
            _update_config(cfg, exp_config)
