# Stub SummaryWriter for test-only environments without tensorboard
class SummaryWriter:
    def __init__(self, *args, **kwargs):
        pass
    def add_scalar(self, *args, **kwargs):
        pass
    def add_text(self, *args, **kwargs):
        pass
    def close(self):
        pass
