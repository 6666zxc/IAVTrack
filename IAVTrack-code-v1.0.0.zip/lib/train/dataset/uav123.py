import json
import os
import random
from collections import OrderedDict

import pandas
import torch

from .base_video_dataset import BaseVideoDataset
from lib.train.data import jpeg4py_loader
from lib.train.admin import env_settings

_SPECS_JSON = os.path.join(os.path.dirname(__file__), '..', 'data_specs', 'uav123_sequence_infos.json')


class Uav123(BaseVideoDataset):
    """UAV123 sequences for training / validation sampling.

    ``root`` should match test ``uav123_path``: the folder that contains ``anno/`` and ``data_seq/``.
    """

    def __init__(self, root=None, image_loader=jpeg4py_loader, split=None, data_fraction=None):
        root = env_settings().uav123_dir if root is None else root
        super().__init__('UAV123', root, image_loader)

        with open(_SPECS_JSON, 'r', encoding='utf-8') as f:
            meta = json.load(f)
        self._name_to_spec = {m['name']: m for m in meta}

        ltr_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
        if split == 'train':
            fp = os.path.join(ltr_path, 'data_specs', 'uav123_train_split.txt')
        elif split == 'val':
            fp = os.path.join(ltr_path, 'data_specs', 'uav123_val_split.txt')
        else:
            raise ValueError("split must be 'train' or 'val'")

        with open(fp, 'r', encoding='utf-8') as f:
            self.sequence_list = [ln.strip() for ln in f if ln.strip()]

        for n in self.sequence_list:
            if n not in self._name_to_spec:
                raise ValueError('Unknown UAV123 sequence in split file: {}'.format(n))

        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list) * data_fraction))

        classes = sorted(set(self._name_to_spec[n]['object_class'] for n in self.sequence_list))
        self.class_list = classes
        self.class_to_id = {c: i for i, c in enumerate(classes)}
        self.seq_per_class = self._build_seq_per_class()

    def _build_seq_per_class(self):
        seq_per_class = {}
        for seq_id, name in enumerate(self.sequence_list):
            cn = self._name_to_spec[name]['object_class']
            seq_per_class.setdefault(cn, []).append(seq_id)
        return seq_per_class

    def get_name(self):
        return 'uav123'

    def has_class_info(self):
        return True

    def has_occlusion_info(self):
        return False

    def get_sequences_in_class(self, class_name):
        return self.seq_per_class[class_name]

    def _join_root(self, rel):
        rel = rel.replace('/', os.sep)
        return os.path.normpath(os.path.join(self.root, rel))

    def _get_spec(self, seq_id):
        return self._name_to_spec[self.sequence_list[seq_id]]

    def _read_bb_anno(self, anno_rel):
        p = self._join_root(anno_rel)
        gt = pandas.read_csv(p, delimiter=',', header=None, na_filter=False, low_memory=False).values.astype('float32')
        return torch.tensor(gt)

    def get_sequence_info(self, seq_id):
        spec = self._get_spec(seq_id)
        bbox = self._read_bb_anno(spec['anno_path'])
        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        visible = valid.byte()
        return {'bbox': bbox, 'valid': valid, 'visible': visible}

    def _get_frame_path(self, seq_id, frame_id):
        spec = self._get_spec(seq_id)
        img_dir = self._join_root(spec['path'])
        fnum = spec['startFrame'] + frame_id
        fname = '{0:0{1}d}.{2}'.format(fnum, spec['nz'], spec['ext'])
        return os.path.join(img_dir, fname)

    def _get_frame(self, seq_id, frame_id):
        return self.image_loader(self._get_frame_path(seq_id, frame_id))

    def get_class_name(self, seq_id):
        return self._name_to_spec[self.sequence_list[seq_id]]['object_class']

    def get_frames(self, seq_id, frame_ids, anno=None):
        obj_class = self.get_class_name(seq_id)
        frame_list = [self._get_frame(seq_id, f_id) for f_id in frame_ids]
        object_meta = OrderedDict({'object_class_name': obj_class,
                                   'motion_class': None,
                                   'major_class': None,
                                   'root_class': None,
                                   'motion_adverb': None})
        if anno is None:
            anno = self.get_sequence_info(seq_id)
        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]
        return frame_list, anno_frames, object_meta
