import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
import os


class UAVDTDataset(BaseDataset):
    """UAVDT SOT benchmark.

    Uses official SOT annotations (UAV-benchmark-SOT_v1.0).
    Images: {base_path}/S0101/img000001.jpg ...
    Annotations: {base_path}/anno/S0101_gt.txt  (SOT format: x,y,w,h per frame)

    Publication:
        The Unmanned Aerial Vehicle Benchmark: Object Detection and Tracking
        Dawei Du et al., ECCV 2018
    """

    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.uavdt_path
        self.sequence_list = self._get_sequence_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_list])

    def _construct_sequence(self, sequence_name):
        # Read SOT annotation: one line per frame, format: x,y,w,h
        anno_path = '{}/anno/{}_gt.txt'.format(self.base_path, sequence_name)
        ground_truth_rect = np.loadtxt(anno_path, delimiter=',', dtype=np.float64)

        # Handle single-frame case (1D array)
        if ground_truth_rect.ndim == 1:
            ground_truth_rect = ground_truth_rect.reshape(1, -1)

        n_frames = ground_truth_rect.shape[0]

        # Target visibility: all frames have valid annotations in SOT format
        target_visible = np.ones(n_frames, dtype=bool)

        # Build frame paths: images directly under {base_path}/{seq_name}/
        frames_path = '{}/{}'.format(self.base_path, sequence_name)
        frame_list = [os.path.join(frames_path, 'img{:06d}.jpg'.format(i + 1))
                      for i in range(n_frames)]

        return Sequence(sequence_name, frame_list, 'uavdt',
                        ground_truth_rect, target_visible=target_visible)

    def __len__(self):
        return len(self.sequence_list)

    def _get_sequence_list(self):
        # List S-prefix directories directly under base_path
        seqs = sorted([d for d in os.listdir(self.base_path)
                       if d.startswith('S') and os.path.isdir(os.path.join(self.base_path, d))])
        return seqs
