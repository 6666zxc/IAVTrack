from collections import deque

from lib.models.avtrack import build_avtrack
from lib.test.tracker.basetracker import BaseTracker
import torch

from lib.test.tracker.vis_utils import gen_visualization
from lib.test.utils.hann import hann2d
from lib.train.data.processing_utils import sample_target
# for debug
import cv2
import os

from lib.test.tracker.data_utils import Preprocessor
from lib.utils.box_ops import clip_box
from lib.utils.misc import NestedTensor


def _abl_on(ab, key, default=True):
    if ab is None:
        return default
    return bool(getattr(ab, key, default))


class AVTrack(BaseTracker):
    def __init__(self, params, dataset_name):
        super(AVTrack, self).__init__(params)
        # Enforce deterministic CUDA ops for reproducibility (critical for ATC's online feedback loop)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        network = build_avtrack(params.cfg, training=False)
        network.load_state_dict(torch.load(self.params.checkpoint, map_location='cpu')['net'], strict=False)
        self.cfg = params.cfg
        self.network = network.cuda()
        self.network.eval()
        self.preprocessor = Preprocessor()
        self.state = None

        self.feat_sz = self.cfg.TEST.SEARCH_SIZE // self.cfg.MODEL.BACKBONE.STRIDE
        self.output_window = hann2d(torch.tensor([self.feat_sz, self.feat_sz]).long(), centered=True).cuda()

        self.debug = params.debug
        self.use_visdom = params.debug
        self.frame_id = 0
        if self.debug:
            if not self.use_visdom:
                self.save_dir = "debug"
                if not os.path.exists(self.save_dir):
                    os.makedirs(self.save_dir)
            else:
                self._init_visdom(None, 1)
        self.save_all_boxes = params.save_all_boxes
        self.z_dict0 = None
        self.is_distill = params.cfg.MODEL['IS_DISTILL']

        ab = getattr(self.cfg.TEST, 'ABLATION', None)

        # T0, M, embed vs image
        self.z_t0 = None
        self.z_memory = None
        self.m_image = None
        self._use_embed = False

        self.box_history = deque(maxlen=5)  # used for box smoothing in template extraction

        # ——— ATC: Adaptive Threshold via Calibration ——————————————————————————
        # Self-supervised online calibration of tracker confidence for template update.
        # — Conservative parameters for long-sequence robustness —
        self.use_atc = _abl_on(ab, 'USE_ATC', False)
        # —— 模板更新策略（对应 BACTrack Table V）：none/always/fixed_interval/fixed_thresh/atc ——
        self.update_mode = str(getattr(self.cfg.TEST, 'UPDATE_MODE', 'none'))
        if self.use_atc:
            self.update_mode = 'atc'
        self.update_interval = int(getattr(self.cfg.TEST, 'UPDATE_INTERVAL', 10))
        self.update_thresh = float(getattr(self.cfg.TEST, 'UPDATE_THRESH', 0.50))
        self.atc_alpha = float(getattr(self.cfg.TEST, 'ATC_ALPHA', 0.92))
        self.atc_window = int(getattr(self.cfg.TEST, 'ATC_WINDOW', 100))
        self.atc_refit_interval = int(getattr(self.cfg.TEST, 'ATC_REFIT_INTERVAL', 10))
        self.atc_pmin = float(getattr(self.cfg.TEST, 'ATC_PMIN', 0.50))
        self.atc_sim_low = float(getattr(self.cfg.TEST, 'ATC_SIM_LOW', 0.60))
        # interval-anchored ATC: 门控评估/更新仅在锚点帧进行(>1 时启用)；统计收集仍逐帧
        self.atc_eval_interval = max(1, int(getattr(self.cfg.TEST, 'ATC_EVAL_INTERVAL', 1)))
        self.atc_anchor_lambda = float(getattr(self.cfg.TEST, 'ATC_ANCHOR_LAMBDA', 0.10))
        # — New: temporal consistency gate —
        self.atc_confirm_frames = int(getattr(self.cfg.TEST, 'ATC_CONFIRM_FRAMES', 3))
        self._atc_confirm_cnt = 0
        # — New: failure detection & hard reset —
        self.atc_fail_thresh = float(getattr(self.cfg.TEST, 'ATC_FAIL_THRESH', 0.40))
        self.atc_fail_max = int(getattr(self.cfg.TEST, 'ATC_FAIL_MAX', 5))
        self.atc_reset_min_frames = int(getattr(self.cfg.TEST, 'ATC_RESET_MIN_FRAMES', 50))
        self._atc_fail_cnt = 0
        # —— ATC 内部组件开关（G1/G2/G3 及辅助机制，用于组件级消融）——
        self.atc_use_failure = bool(getattr(self.cfg.TEST, 'ATC_USE_FAILURE_DETECT', True))
        self.atc_use_peak_quality = bool(getattr(self.cfg.TEST, 'ATC_USE_PEAK_QUALITY', True))
        self.atc_use_temporal = bool(getattr(self.cfg.TEST, 'ATC_USE_TEMPORAL', True))
        self.atc_use_g1 = bool(getattr(self.cfg.TEST, 'ATC_USE_G1', True))
        self.atc_use_g2 = bool(getattr(self.cfg.TEST, 'ATC_USE_G2', True))
        self.atc_use_g3 = bool(getattr(self.cfg.TEST, 'ATC_USE_G3', True))
        self.atc_use_anchor = bool(getattr(self.cfg.TEST, 'ATC_USE_ANCHOR', True))
        # Calibration state
        self._atc_calib_x = []   # p_max values in sliding window
        self._atc_calib_y = []   # peakiness values in sliding window
        self._atc_last_refit = 0
        self._atc_slope = 0.0    # peakiness ≈ slope × p_max + offset
        self._atc_offset = 0.0

    def _has_embed(self):
        return hasattr(self.network.backbone, "forward_from_z_embed")

    def initialize(self, image, info: dict):
        z_patch_arr, resize_factor, z_amask_arr = sample_target(
            image, info['init_bbox'], self.params.template_factor, output_sz=self.params.template_size,
        )
        self.z_patch_arr = z_patch_arr
        template = self.preprocessor.process(z_patch_arr, z_amask_arr)
        with torch.no_grad():
            self.z_dict0 = self._clone_nested_tensor(template)
            self._use_embed = self._has_embed()
            if self._use_embed:
                b = self.network.backbone
                self.z_t0 = b.patch_embed(self.z_dict0.tensors) + b.pos_embed_z
                # MSCA-HFDA: apply after patch_embed on template (consistent with forward_from_z_embed)
                if hasattr(b, 'msca_hfda') and b.msca_hfda is not None:
                    B, N, C = self.z_t0.shape
                    Hz = Wz = int(N ** 0.5)
                    self.z_t0 = b.msca_hfda(self.z_t0.reshape(B, C, Hz, Wz), is_search=False).reshape(B, N, C)
                self.z_memory = self.z_t0.clone()
            else:
                self.m_image = self.z_dict0.tensors.clone()
                self.z_t0 = None
                self.z_memory = None

        self.state = info['init_bbox']
        self.frame_id = 0
        self.box_history.clear()
        # ATC reset
        self._atc_calib_x.clear()
        self._atc_calib_y.clear()
        self._atc_last_refit = 0
        self._atc_slope = 0.0
        self._atc_offset = 0.0
        self._atc_confirm_cnt = 0
        self._atc_fail_cnt = 0
        self._init_bbox_w = info['init_bbox'][2]
        self._init_bbox_h = info['init_bbox'][3]

        if self.save_all_boxes:
            nq = int(getattr(self.cfg.MODEL, 'NUM_OBJECT_QUERIES', 1))
            all_boxes_save = info['init_bbox'] * nq
            return {"all_boxes": all_boxes_save}

    def _clone_nested_tensor(self, nested_tensor: NestedTensor) -> NestedTensor:
        cloned_mask = nested_tensor.mask.clone() if nested_tensor.mask is not None else None
        return NestedTensor(nested_tensor.tensors.clone(), cloned_mask)

    def _z_final(self):
        if self._use_embed and self.z_t0 is not None:
            # 只要启用了任一在线更新策略（atc/always/fixed_interval/fixed_thresh），
            # 就用 z_memory（未更新时等于 z_t0）；'none' 才固定用首帧模板 z_t0。
            if self.update_mode != 'none' and self.z_memory is not None:
                return self.z_memory
            return self.z_t0
        return self.z_dict0.tensors

    def _template_similarity(self, template_a: NestedTensor, template_b: NestedTensor) -> float:
        feat_a = template_a.tensors.reshape(template_a.tensors.shape[0], -1)
        feat_b = template_b.tensors.reshape(template_b.tensors.shape[0], -1)
        return float(torch.nn.functional.cosine_similarity(feat_a, feat_b, dim=1).mean().item())

    def _z_cos_sim_t0(self, z_feat: torch.Tensor) -> float:
        a = self.z_t0.reshape(1, -1)
        b = z_feat.reshape(1, -1)
        return float(torch.nn.functional.cosine_similarity(a, b, dim=1).mean().item())

    def _min_template_area(self) -> float:
        """Current target pixel area (w * h)."""
        _, _, w, h = self.state
        return w * h

    # ——— ATC: Adaptive Threshold via Calibration ———————————————————————————————
    def _atc_peakiness(self, score_map):
        """Peakiness = (max - mean) / std. Sharp single-peak → unambiguous tracking."""
        sm = score_map.view(-1)
        mu, std = sm.mean(), sm.std()
        if std < 1e-6:
            return 0.0
        return float(((sm.max() - mu) / std).item())

    def _atc_peak_quality(self, score_map):
        """Peak-to-second-peak ratio. Suppresses multi-peak ambiguous responses."""
        sm = score_map.view(-1)
        vals, _ = torch.topk(sm, 2)
        if vals[1] < 1e-6:
            return 100.0
        return float((vals[0] / vals[1]).item())

    def _atc_fit(self):
        """Exponential-weighted linear regression: recent frames weigh more."""
        if len(self._atc_calib_x) < 20:
            self._atc_slope = 0.0
            self._atc_offset = 0.0
            return
        xs = torch.tensor(self._atc_calib_x, dtype=torch.float32)
        ys = torch.tensor(self._atc_calib_y, dtype=torch.float32)
        # Exponential weighting: newer frames get higher weight
        w = torch.exp(torch.linspace(0, 1, len(xs)))
        w = w / w.sum()
        mx = (xs * w).sum()
        my = (ys * w).sum()
        sxx = (w * (xs - mx) ** 2).sum()
        if sxx > 1e-3:
            sxy = (w * (xs - mx) * (ys - my)).sum()
            self._atc_slope = float((sxy / sxx).item())
            self._atc_offset = float(my.item()) - self._atc_slope * float(mx.item())
            residuals = ys - (self._atc_slope * xs + self._atc_offset)
            self._atc_offset += 0.25 * float((residuals * w).std().item())
        else:
            self._atc_slope = 0.0
            ys_sorted, idx = ys.sort()
            w_sorted = w[idx]
            cumw = w_sorted.cumsum(0)
            p75_idx = (cumw >= 0.75).nonzero(as_tuple=True)[0][0].item()
            self._atc_offset = float(ys_sorted[p75_idx].item()) + 0.15 * float((ys * w).std().item())

    def _atc_process(self, image, p_max, pred_score_map):
        """ATC template update with failure-detection and temporal-consistency gates.

        1. Failure detection → hard-reset to z_t0 on consecutive low-quality frames
        2. Peak quality check → suppress multi-peak ambiguous responses
        3. Temporal consistency → require consecutive-frame confirmation
        4. Scale penalty → reject extreme scale changes
        """
        if not self._use_embed or self.z_memory is None:
            return

        # === 1. Failure Detection & Hard Reset (long sequences only) ===
        if self.atc_use_failure:
            if p_max < self.atc_fail_thresh:
                self._atc_fail_cnt += 1
                self._atc_confirm_cnt = 0
                if self._atc_fail_cnt >= self.atc_fail_max and self.frame_id >= self.atc_reset_min_frames:
                    # Hard reset: accumulated drift on long sequence → revert to z_t0
                    self.z_memory = self.z_t0.clone()
                    self._atc_fail_cnt = 0
                    self._atc_calib_x.clear()
                    self._atc_calib_y.clear()
                    self._atc_last_refit = self.frame_id
                return
            else:
                self._atc_fail_cnt = 0

        # === 2. Peak Quality Check (dual-peak suppression) ===
        if self.atc_use_peak_quality:
            peak_ratio = self._atc_peak_quality(pred_score_map)
            if peak_ratio < 1.5:
                self._atc_confirm_cnt = 0
                return

        # === 3. Peakiness ===
        peak = self._atc_peakiness(pred_score_map)

        # === 4. Update Calibration Buffer (only confident frames) ===
        if p_max > self.atc_pmin:
            self._atc_calib_x.append(p_max)
            self._atc_calib_y.append(peak)
            if len(self._atc_calib_x) > self.atc_window:
                self._atc_calib_x.pop(0)
                self._atc_calib_y.pop(0)

        # === 5. Re-fit Calibration ===
        if self.frame_id - self._atc_last_refit >= self.atc_refit_interval:
            self._atc_fit()
            self._atc_last_refit = self.frame_id

        if len(self._atc_calib_x) < 20:
            return

        # === Interval-anchored evaluation ===
        # 统计(失败检测/校准缓冲/重拟合)仍逐帧进行，保证在线校准样本量；
        # 门控与模板更新仅在锚点帧评估（ATC_EVAL_INTERVAL > 1 时启用，=1 时与原版 ATC 完全一致）。
        if self.atc_eval_interval > 1 and self.frame_id % self.atc_eval_interval != 0:
            return

        # === 6. Three-Gate Check + Temporal Consistency ===
        calib_thresh = self._atc_slope * p_max + self._atc_offset
        g1 = (peak > calib_thresh) if self.atc_use_g1 else True
        g2 = (p_max > self.atc_pmin) if self.atc_use_g2 else True
        if not (g1 and g2):
            self._atc_confirm_cnt = 0
            return

        if self.atc_use_temporal:
            self._atc_confirm_cnt += 1
            if self._atc_confirm_cnt < self.atc_confirm_frames:
                return
            self._atc_confirm_cnt = 0

        # === 7. Extract Template Features ===
        t_current = self._extract_template_features(image)
        if t_current is None:
            return

        # === 8. G3: Cosine Similarity ===
        if self.atc_use_g3:
            sim = float(torch.nn.functional.cosine_similarity(
                self.z_memory.reshape(1, -1), t_current.reshape(1, -1), dim=1
            ).mean().item())
            if sim < self.atc_sim_low:
                return

        # === 9. Conservative EMA Update + Anchor Regularization ===
        self.z_memory = self.atc_alpha * self.z_memory + (1.0 - self.atc_alpha) * t_current
        if self.atc_use_anchor:
            self.z_memory = self.z_memory + self.atc_anchor_lambda * (self.z_t0 - self.z_memory)

    def _update_naive(self, image):
        """朴素模板更新（无自适应门控）：仅做 EMA + anchor，用于策略对比消融。"""
        if not self._use_embed or self.z_memory is None:
            return
        t_current = self._extract_template_features(image)
        if t_current is None:
            return
        self.z_memory = self.atc_alpha * self.z_memory + (1.0 - self.atc_alpha) * t_current
        self.z_memory = self.z_memory + self.atc_anchor_lambda * (self.z_t0 - self.z_memory)

    def _extract_template_features(self, image):
        """Extract template using predicted center + initial GT scale.

        Center tracks the target via box_history smoothing; scale is frozen at
        first-frame ground-truth to eliminate box-scale prediction errors from
        contaminating the template crop — the root cause of AUC regression.
        """
        try:
            if len(self.box_history) >= 1:
                boxes = list(self.box_history)
                cx = sum(b[0] + b[2]/2 for b in boxes) / len(boxes)
                cy = sum(b[1] + b[3]/2 for b in boxes) / len(boxes)
            else:
                cx = self.state[0] + self.state[2] / 2
                cy = self.state[1] + self.state[3] / 2
            w0, h0 = self._init_bbox_w, self._init_bbox_h
            anchor_box = [cx - w0/2, cy - h0/2, w0, h0]

            z_patch, _, z_amask = sample_target(
                image, anchor_box, self.params.template_factor, output_sz=self.params.template_size,
            )
            t_current = self.preprocessor.process(z_patch, z_amask)
            b = self.network.backbone
            ft = b.patch_embed(t_current.tensors) + b.pos_embed_z
            if hasattr(b, 'msca_hfda') and b.msca_hfda is not None:
                B, N, C = ft.shape
                Hz = Wz = int(N ** 0.5)
                ft = b.msca_hfda(ft.reshape(B, C, Hz, Wz), is_search=False).reshape(B, N, C)
            return ft
        except Exception:
            return None

    def track(self, image, info: dict = None):
        H, W, _ = image.shape
        self.frame_id += 1

        old_state = [float(x) for x in self.state]
        x_patch_arr, resize_factor, x_amask_arr = sample_target(
            image, self.state, self.params.search_factor, output_sz=self.params.search_size,
        )
        search = self.preprocessor.process(x_patch_arr, x_amask_arr)
        x_dict = search

        with torch.no_grad():
            if self._use_embed and self.z_memory is not None:
                out_dict = self.network.forward_from_z_embed(
                    self._z_final(), x_dict.tensors, [], [], is_distill=self.is_distill,
                )
            else:
                out_dict = self.network.forward(
                    template=self._z_final(), search=x_dict.tensors, template_anno=[], search_anno=[],
                    is_distill=self.is_distill,
                )

        pred_score_map = out_dict['score_map']
        response = self.output_window * pred_score_map
        pred_boxes = self.network.box_head.cal_bbox(response, out_dict['size_map'], out_dict['offset_map'])
        pred_boxes = pred_boxes.view(-1, 4)
        s_t = float(pred_score_map.max().item())
        pred_box = (pred_boxes.mean(dim=0) * self.params.search_size / resize_factor).tolist()
        self.state = clip_box(self.map_box_back(pred_box, resize_factor, prev_state=old_state), H, W, margin=10)

        B_t = self.state
        p_max = s_t

        # —— 模板更新分派（ATC / 朴素策略）——
        if self.update_mode == 'atc':
            self._atc_process(image, p_max, pred_score_map)
        elif self.update_mode == 'always':
            self._update_naive(image)
        elif self.update_mode == 'fixed_interval':
            if self.frame_id % self.update_interval == 0:
                self._update_naive(image)
        elif self.update_mode == 'fixed_thresh':
            if p_max > self.update_thresh:
                self._update_naive(image)
        # 'none' → 只用首帧模板，不更新

        self.box_history.append([float(x) for x in B_t])
        return self._track_return(out_dict, pred_score_map, pred_boxes, x_patch_arr, image, info, resize_factor)

    def _track_return(self, out_dict, pred_score_map, pred_boxes, x_patch_arr, image, info, resize_factor):
        if self.debug:
            if not self.use_visdom:
                x1, y1, w, h = self.state
                image_BGR = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                cv2.rectangle(
                    image_BGR, (int(x1), int(y1)), (int(x1 + w), int(y1 + h)), color=(0, 0, 255), thickness=2,
                )
                save_path = os.path.join(self.save_dir, "%04d.jpg" % self.frame_id)
                cv2.imwrite(save_path, image_BGR)
            else:
                self.visdom.register((image, info['gt_bbox'].tolist(), self.state), 'Tracking', 1, 'Tracking')
                self.visdom.register(torch.from_numpy(x_patch_arr).permute(2, 0, 1), 'image', 1, 'search_region')
                self.visdom.register(torch.from_numpy(self.z_patch_arr).permute(2, 0, 1), 'image', 1, 'template')
                self.visdom.register(pred_score_map.view(self.feat_sz, self.feat_sz), 'heatmap', 1, 'score_map')
                self.visdom.register(
                    (pred_score_map * self.output_window).view(self.feat_sz, self.feat_sz), 'heatmap', 1, 'score_map_hann',
                )
                if 'removed_indexes_s' in out_dict and out_dict['removed_indexes_s']:
                    removed_indexes_s = out_dict['removed_indexes_s']
                    removed_indexes_s = [x.cpu().numpy() for x in removed_indexes_s]
                    masked_search = gen_visualization(x_patch_arr, removed_indexes_s)
                    self.visdom.register(torch.from_numpy(masked_search).permute(2, 0, 1), 'image', 1, 'masked_search')
                while self.pause_mode:
                    if self.step:
                        self.step = False
                        break
        if self.save_all_boxes:
            all_boxes = self.map_box_back_batch(pred_boxes * self.params.search_size / resize_factor, resize_factor)
            all_boxes_save = all_boxes.view(-1).tolist()
            return {"target_bbox": self.state, "all_boxes": all_boxes_save}
        return {"target_bbox": self.state}

    def map_box_back(self, pred_box: list, resize_factor: float, prev_state=None):
        s = self.state if prev_state is None else prev_state
        cx_prev, cy_prev = s[0] + 0.5 * s[2], s[1] + 0.5 * s[3]
        cx, cy, w, h = pred_box
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return [cx_real - 0.5 * w, cy_real - 0.5 * h, w, h]

    def map_box_back_batch(self, pred_box: torch.Tensor, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box.unbind(-1)
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return torch.stack([cx_real - 0.5 * w, cy_real - 0.5 * h, w, h], dim=-1)

    def add_hook(self):
        enc_attn_weights = []
        for i in range(12):
            self.network.backbone.blocks[i].attn.register_forward_hook(
                lambda self, input, output: enc_attn_weights.append(output[1])
            )
        self.enc_attn_weights = enc_attn_weights


def get_tracker_class():
    return AVTrack
