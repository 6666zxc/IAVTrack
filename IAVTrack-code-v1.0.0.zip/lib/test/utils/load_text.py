import numpy as np
import pandas as pd
import io


def _loadtxt_utf8(path, delimiter, dtype):
    try:
        return np.loadtxt(path, delimiter=delimiter, dtype=dtype, encoding='utf-8')
    except TypeError:
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read()
        return np.loadtxt(io.StringIO(text), delimiter=delimiter, dtype=dtype)


def load_text_numpy(path, delimiter, dtype):
    if isinstance(delimiter, (tuple, list)):
        for d in delimiter:
            try:
                ground_truth_rect = _loadtxt_utf8(path, d, dtype)
                return ground_truth_rect
            except:
                pass
        raise Exception('Could not read file {}'.format(path))
    else:
        ground_truth_rect = _loadtxt_utf8(path, delimiter, dtype)
        return ground_truth_rect


def load_text_pandas(path, delimiter, dtype):
    if isinstance(delimiter, (tuple, list)):
        for d in delimiter:
            try:
                ground_truth_rect = pd.read_csv(path, delimiter=d, header=None, dtype=dtype, na_filter=False,
                                                low_memory=False).values
                return ground_truth_rect
            except Exception as e:
                pass

        raise Exception('Could not read file {}'.format(path))
    else:
        ground_truth_rect = pd.read_csv(path, delimiter=delimiter, header=None, dtype=dtype, na_filter=False,
                                        low_memory=False).values
        return ground_truth_rect


def load_text(path, delimiter=' ', dtype=np.float32, backend='numpy'):
    if backend == 'numpy':
        return load_text_numpy(path, delimiter, dtype)
    elif backend == 'pandas':
        return load_text_pandas(path, delimiter, dtype)


def load_str(path):
    with open(path, "r") as f:
        text_str = f.readline().strip().lower()
    return text_str
