# IAVtrack: Information-Adaptive Visual Tracking

**IAVtrack** extends [AVTrack](https://github.com/wuyou3474/AVTrack) with pluggable modules for feature enhancement, mutual-information-based representation learning, and robust template memory update.

> All modules are designed as **pluggable, ablation-friendly** --- every component can be independently toggled via config.

---

## What's New vs. Original AVTrack

| # | Module | What It Does | Config Switch |
|---|--------|-------------|---------------|
| 1 | **MSCA-HFDA V2: Multi-Scale Channel + Haar-Wavelet Frequency-Domain Attention** | Pre-encoder token refinement on ViT embeddings (dim=192): asymmetric multi-scale DW conv channel attention (MSCA, dilations 1/2/3 for search, 1/2 for template) + Haar wavelet frequency-domain attention (HFDA V2, detail-band gates, HH zeroing, pre-fuse layer, additive fusion with LayerScale) | `MODEL.ABLATION.USE_MSCA_HFDA` |
| 2 | **BDDR: Background-Debiased Discriminative Routing** | Pre-encoder DANP-style bidirectional soft modulation: channel-wise background debiasing + pos/neg beacon construction + static+dynamic prompts + scalar response modulation + zero-init residual fusion MLP; preserves full 256-token search set | `MODEL.ABLATION.USE_BDDR` |
| 3 | **Adaptive Layer Skip** | Per-block conditional execution with activeness loss (weight=12) to maintain ~70% activation rate | `MODEL.ABLATION.USE_ADAPTIVE_SKIP` |
| 4 | **Anchored EMA Memory + 6-Gate Update** | First-frame anchor fusion + conditional EMA with WEMA adaptive smoothing, soft-vote gating, occlusion/drift recovery | `TEST.ABLATION.*` |
| 5 | **ATC: Adaptive Threshold via Calibration** | Test-time self-supervised calibration: collects (p_max, peakiness) pairs per-sequence, fits linear model, gates template updates via 3-condition check. Zero training cost, per-sequence adaptation. | `TEST.ABLATION.USE_ATC` |

---

## Architecture Overview

```
   Template (128sq) -- PatchEmbed -- MSCA-HFDA V2 (token refine) -- +pos_embed
   Search   (256sq) -- PatchEmbed -- MSCA-HFDA V2 (token refine) -- +pos_embed
                                                            |
                                                            v
                          +----------------------------+
                          |  BDDR: Bidirectional Soft  |
                          |  Modulation                |
                          |  (channel debias +         |
                          |   pos/neg prompts +        |
                          |   residual fusion)         |
                          +------------+--------------+
                                       |
              +----------  ViT Encoder (12 layers) ----------+
              |  +-- Adaptive Layer Skip (per block) --+     |
              |  |  p = sigma(Linear(320,1)(x[:,:,0])) |    |
              |  |  L_act = L1(p_bar, 0.7)  (wt 12)    |    |
              |  +-------------------------------------+     |
              |  +-- Attention Sharpening --------------+     |
              |  |  attn = attn + 0.1 * attn^2          |    |
              |  +-------------------------------------+     |
              +----------------------+------------------------+
                                     |
                       +-- Box Head + Global MI Loss --+
                       |  score_map + size_map +       |
                       |  offset_map + mine_loss (JSD) |
                       +--------------+----------------+
                                      |
              +------- Tracker: Anchored EMA Memory -----+
              |  T_final = beta*T0 + (1-beta)*M         |
              |  M_t = alpha_t*M_{t-1} + (1-alpha_t)*f_t|
              |  WEMA / Soft-vote / Occlusion Lock      |
              +------------------------------------------+
                                      |
              +------- ATC: Adaptive Calibration -------+
              |  Per-sequence (p_max, peakiness) pairs  |
              |  Linear regression → 3-gate check:      |
              |  G1: quality > calibrated threshold     |
              |  G2: p_max > min confidence             |
              |  G3: cos_sim > drift threshold          |
              |  Update: z_mem = 0.92*z_old + 0.08*z_new|
              +------------------------------------------+
```

Pipeline: `RGB -> PatchEmbed -> MSCA-HFDA V2 (token refine) -> +pos_embed -> BDDR -> ViT -> Box Head -> ATC Gate`

---

## Multi-Stage Training

IAVtrack uses a 2-stage training strategy to progressively integrate BDDR and MSCA-HFDA:

### Stage 1: BDDR Training

Backbone + BDDR + Head are jointly trained. Backbone uses reduced LR (0.1x multiplier). BDDR learns to debias background and produce discriminative soft modulation.

| Item | Value |
|------|-------|
| **Config** | `ablation_02_bddr_v2.yaml` |
| **Backbone** | deit_tiny_patch16_224 (DeiT-tiny, ImageNet-1k pretrained) |
| **Dataset** | LaSOT + GOT10K + COCO17 + TrackingNet (0.3:0.3:0.2:0.2) |
| **Epochs** | 80 |
| **LR** | 4e-4 (backbone: 4e-5 via 0.1x multiplier) |
| **LR Drop** | epoch 64 |
| **Frozen** | cls patch embed (layer 0) |
| **Trained** | Backbone (0.1x LR), BDDR, Head |
| **AMP** | True |
| **Output** | `AVTrack_ep0080.pth.tar` |

```
python tracking/train.py --script avtrack --config ablation_02_bddr_v2 --save_dir ./output
```

### Stage 2: MSCA-HFDA Training (Frozen BDDR)

Backbone + BDDR are **frozen**. Only MSCA-HFDA module and Head are trained. Loads the Stage 1 checkpoint as pretrained weights.

| Item | Value |
|------|-------|
| **Config** | `ablation_stage2_msca_bddr_mixed_v2.yaml` |
| **Pretrained** | Stage 1 checkpoint: `output/checkpoints/train/avtrack/ablation_02_bddr_v2/AVTrack_ep0080.pth.tar` |
| **Dataset** | LaSOT + GOT10K + COCO17 + TrackingNet (0.3:0.3:0.2:0.2) |
| **Epochs** | 80 |
| **LR** | 4e-4 |
| **LR Drop** | epoch 64 |
| **Frozen** | Backbone, BDDR |
| **Trained** | MSCA-HFDA, Head |
| **Flag** | `STAGE2_TRAIN: true` |
| **Output** | `AVTrack_ep0080.pth.tar` |

```
python tracking/train.py --script avtrack --config ablation_stage2_msca_bddr_mixed_v2 --save_dir ./output
```

### Stage 2 Variant: Joint Training (No Freeze)

Single-variable counterpart to the frozen Stage 2: `STAGE2_TRAIN: false` keeps **backbone and BDDR trainable**, so BDDR and MSCA-HFDA are optimized end-to-end together. It starts from the pretrained backbone instead of the Stage 1 checkpoint, which makes it a single-stage version of the same module combination. All other hyper-parameters (LR, epoch schedule, dataset ratios, `USE_*` switches) are identical to the frozen config.

| Item | Value |
|------|-------|
| **Config** | `ablation_stage2_msca_bddr_mixed_v2_nofreeze.yaml` |
| **Pretrained** | `mae_pretrain_vit_base.pth` (dead code --- the backbone loads timm's ImageNet-1k weights) |
| **Dataset** | LaSOT + GOT10K + COCO17 + TrackingNet (0.3:0.3:0.2:0.2) |
| **Epochs** | 80 |
| **LR** | 4e-4 (backbone: 4e-5 via 0.1x multiplier) |
| **LR Drop** | epoch 64 |
| **Frozen** | cls patch embed (layer 0) |
| **Trained** | Backbone (0.1x LR), BDDR, MSCA-HFDA, Head |
| **Flag** | `STAGE2_TRAIN: false` |
| **Output** | `AVTrack_ep0080.pth.tar` |

```
python tracking/train.py --script avtrack --config ablation_stage2_msca_bddr_mixed_v2_nofreeze --save_dir ./output
```

### Training Summary

```
Stage 1 (80ep)                Stage 2 (80ep)
┌─────────────────┐          ┌─────────────────┐
│ Backbone (0.1x) │          │ Backbone (FRZ)  │
│ BDDR            │  ────→   │ BDDR    (FRZ)   │
│ Head            │          │ MSCA-HFDA       │
│                 │          │ Head            │
└─────────────────┘          └─────────────────┘
    joint training             freeze backbone+BDDR
                               train MSCA-HFDA+Head
```

The no-freeze variant replaces Stage 2 with one joint run: no Stage 1 checkpoint is loaded and backbone + BDDR stay trainable (backbone at 0.1x LR) alongside MSCA-HFDA and Head.

### GOT-10k Variant (Single-Stage)

For quick experiments, a single-stage config trains all modules jointly on GOT-10k only:

| Config | MSCA-HFDA | BDDR | Epochs | Dataset |
|--------|:---:|:---:|:------:|---------|
| `ablation_stage2_msca_bddr_got10k.yaml` | YES | YES | 45 | GOT10K_vottrain |

---

## ATC: Adaptive Threshold via Calibration

ATC is a **test-time-only** self-supervised calibration module. It operates per-sequence with zero additional training.

### Motivation

Standard confidence thresholds (e.g., `p_max > 0.8`) are fixed and cannot adapt to varying sequence difficulty. ATC learns a *calibrated* quality threshold online for each sequence, preventing the tracker from incorporating low-quality or ambiguous frames into its template memory.

### How It Works

```
Per frame:
  1. Compute peakiness = (max - mean) / std of score_map
  2. Append (p_max, peakiness) to sliding window (size=50)
  3. Every 10 frames: fit peakiness = slope × p_max + offset (linear regression)
  4. Three-gate check:
     ┌─────────────────────────────────────────────────────┐
     │ G1: peakiness > slope × p_max + offset              │
     │     → current frame quality exceeds calibrated norm │
     │ G2: p_max > ATC_PMIN (0.5)                          │
     │     → absolute minimum confidence floor             │
     │ G3: cos_sim(z_new, z_memory) > ATC_SIM_LOW (0.6)    │
     │     → template hasn't drifted                       │
     └─────────────────────────────────────────────────────┘
  5. If all gates pass: z_memory = 0.92 × z_old + 0.08 × z_new
```

### Key Design

- **peakiness** = `(max - mean) / std`: sharp single-peak score map → unambiguous tracking → high quality
- **Linear calibration**: maps raw confidence `p_max` to expected quality `peakiness`; a frame is "good" when its actual quality exceeds what the model predicts from raw confidence alone
- **Conservative EMA**: 92% old + 8% new prevents abrupt memory corruption
- **Zero training**: all statistics collected per-sequence online

### Config

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.ABLATION.USE_ATC` | `False` | Enable ATC adaptive calibration |
| `TEST.ATC_ALPHA` | `0.92` | EMA weight for template update (higher = more conservative) |
| `TEST.ATC_WINDOW` | `50` | Sliding window size for calibration data |
| `TEST.ATC_REFIT_INTERVAL` | `10` | Re-fit calibration every N frames |
| `TEST.ATC_PMIN` | `0.50` | Absolute minimum p_max to allow update |
| `TEST.ATC_SIM_LOW` | `0.60` | Minimum cos_sim(z_new, z_old) to allow update |

### Enabling ATC

ATC is a test-time feature. Add to any test config YAML or command line:

```yaml
TEST:
  ABLATION:
    USE_ATC: true
  ATC_ALPHA: 0.92
  ATC_WINDOW: 50
```

See `ablation_bddr_atc.yaml` for a complete example.

---

## MSCA-HFDA V2: Multi-Scale Channel + Haar Frequency-Domain Attention

MSCA-HFDA V2 operates on **ViT embedding tokens** (e.g. 192-dim) after PatchEmbed, refining token features via dual-branch attention with additive fusion and LayerScale.

**File:** `lib/models/avtrack/msca_hfda.py`

### V2 Changes from V1

1. **Additive fusion** (`a*alpha + b*beta`) instead of multiplicative
2. **Safe LayerScale init** (1e-3) to fix double-zero-init bug
3. **HFDA removes LL gate** and **zeros HH band** (saves SR75)
4. **LevelGate adds 3x3 DW Conv** for spatial-frequency interaction
5. **Pre-fuse layer** before Haar (Simple Fusion concept)
6. **Asymmetric MSCA** for template/search resolution mismatch (search: dilations 1/2/3, template: dilations 1/2)

### Branch A --- Multi-Scale Channel Attention (MSCA)

```
DWConv 3x3 (d=1) ─┐
DWConv 3x3 (d=2) ─┼─ Concat -> 1x1 fuse -> GroupNorm
DWConv 3x3 (d=3) ─┘                       |
                                         v
                                  GAP -> FC(dim->r->dim) -> Sigmoid
                                         |
                                  channel weights (B, C, 1, 1)
```

- **Multi-scale depthwise dilated convs** capture different receptive fields
- **Asymmetric**: search uses dilations (1,2,3), template uses (1,2) to match resolution
- **Fused + SE gating** produces channel attention
- Output `a` is element-wise multiplied with the fused feature

### Branch B --- Haar-Wavelet Frequency-Domain Attention V2 (HFDA V2)

```
PreFuse(1x1+GELU) -> HaarDWT -> LL, LH, HL, HH(zeroed)
                                         |
                              stacked(LH, HL) -> _LevelGateV2
                              (3x3 DWConv + BN + 1x1 + GELU + 1x1 + Sigmoid + bias)
                                         |
                              Haar inverse(LL + gated_LH + gated_HL + 0)
```

- **Pre-fuse layer** (1x1 conv + GELU) before Haar decomposition
- **Haar wavelet decomposition** splits input into LL + 3 detail bands
- **HH band is zeroed** (V2: removes high-frequency noise, saves SR75)
- **LL is passed through un-gated** (V2: removes LL gate)
- **_LevelGateV2** (3x3 DWConv + BN + 1x1 + GELU + 1x1 + Sigmoid, with learnable bias) gates detail bands
- **Exact reconstruction** via Haar inverse

### Fusion (V2: Additive + LayerScale)

```
combined = a * alpha + b * beta
out = proj_out(combined) * layer_scale + shortcut
```

- `alpha`, `beta`: learnable per-channel scaling (init=1.0)
- `layer_scale`: learnable scalar (init=1e-3) for safe training
- `attn_shortcut`: residual connection (default True)

### Config

| Config | Default | Description |
|--------|---------|-------------|
| `MODEL.ABLATION.USE_MSCA_HFDA` | `False` | Enable MSCA-HFDA V2 after PatchEmbed |
| Internal | `dim=192` | Matches ViT embed dim automatically |
| Internal | `dilations_search=(1,2,3)` | MSCA scale sizes for search branch |
| Internal | `dilations_tmpl=(1,2)` | MSCA scale sizes for template branch |
| Internal | `haar_levels=1` | L-level wavelet decomposition |
| Internal | `reduction=4` | Channel attention bottleneck |

### Monitoring Stats

`MSCA_HFDA.stats` exposes real-time diagnostics (no_grad):

| Key | Meaning |
|-----|---------|
| `input_norm` | Input feature L2 norm |
| `msca_norm` / `hfda_norm` | Branch output norms (balance indicator) |
| `msca_contrib_ratio` / `hfda_contrib_ratio` | Relative branch contribution |
| `alpha_mean` / `alpha_std` | MSCA branch scaling statistics |
| `beta_mean` / `beta_std` | HFDA branch scaling statistics |
| `layer_scale` | LayerScale value (training stability) |
| `out_norm` | Output feature L2 norm |
| `out_input_ratio` | Output / input norm ratio (stability) |

---

## BDDR: Background-Debiased Discriminative Routing

BDDR replaces the hard Top-K token deletion of traditional routers with **DANP-style bidirectional soft modulation**,
operating AFTER MSCA-HFDA and BEFORE the ViT Encoder. This preserves all 256 search tokens for downstream modules
while enhancing target-discriminative features.

**File:** `lib/models/avtrack/bddr.py`

### Core Pipeline

```
  z [B,64,C]                              x [B,256,C]
      |                                        |
      v                                        v
+--------------+                       +--------------+
| Magnitude-   |                       | Channel-wise |
| Weighted Pool|                       | Debiasing    |
| (pos beacon) |                       | x - alpha*bg |
+------+-------+                       +------+-------+
       |                                |
  pos_beacon                          x_debiased
       |                                |
       +----------+---------------------+
                  |
                  v
          neg_beacon = bottom-K(x_debiased, pos_beacon)   [training: from bg; inference: EMA]
                  |
                  v
          +-------+--------+
          | DANP-style Soft |
          | Modulation      |
          |  - Static+Dynamic|
          |    pos/neg prompts|
          |  - Contrastive-  |
          |    normalized    |
          |    sigmoid       |
          |  - alpha_pos/neg |
          |    modulation    |
          +-------+--------+
                  |
                  v
          f = 1 + alpha_pos*(2*r_pos-1) - alpha_neg*(2*r_neg-1)
                  |
                  v
          x_mod = x_debiased * f.unsqueeze(-1)
                  |
                  v
          x_out = x + Fuse(x_mod)    [zero-init Fuse MLP]
```

### Key Components

| Component | Description |
|-----------|-------------|
| **Pos beacon** | Magnitude-weighted pool of template tokens (L2-norm softmax weighting) |
| **Bg beacon** | Training: bottom-K tokens furthest from pos beacon; Inference: EMA-updated from low-modulation tokens |
| **Neg beacon** | Bottom-K tokens from debiased search features furthest from pos beacon |
| **Channel-wise debiasing** | `x_debiased = x - channel_alpha * bg_beacon` (learnable per-channel alpha, init=0.1) |
| **Static prompts** | Learnable VPT-style pos/neg prompt vectors |
| **Dynamic prompts** | Linear projections from pos/neg beacons, combined with static prompts and L2-normalized |
| **Soft modulation** | Contrastive-normalized sigmoid response: `r = sigma((logit - mean) / (std + eps))`, then `f = 1 + alpha_pos*(2*r_pos-1) - alpha_neg*(2*r_neg-1)` |
| **Residual fusion** | Zero-init 2-layer MLP: `x_out = x + Fuse(x_mod)` ensures identity at init |
| **Discriminator** | 2-layer MLP for adversarial loss (hinge: `relu(1 - d_pos + d_neg).mean()`) |

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| DANP-style soft modulation (not Top-K) | Preserves full token set; gradient continuous; compatible with downstream modules |
| Channel-wise alpha (learnable) | Background strength varies per channel; scalar lambda is insufficient |
| Magnitude-weighted pos beacon | L2-norm weighting focuses on salient target regions, ignores padding |
| EMA neg beacon (inference only) | Captures dynamic distractors across frames without training cost |
| Contrastive normalization of logits | Prevents sigmoid saturation when MSCA-HFDA shifts feature distribution |
| Zero-init Fuse MLP | Guarantees identity mapping at training start; stable optimization |
| Adversarial loss on discriminator | Encourages pos/neg prompts to be discriminative |

### Config

| Config | Default | Description |
|--------|---------|-------------|
| `MODEL.ABLATION.USE_BDDR` | `False` | Enable BDDR soft modulation before ViT Encoder |

---

## Training Losses

Total loss (non-distill):

```
loss = tracking_loss + 0.05 * mine_loss + 12 * activeness_loss + 0.01 * bddr_adv_loss
```

where `tracking_loss = giou_weight * giou + l1_weight * l1 + focal_weight * focal`

| Loss | Weight | Description |
|------|:------:|-------------|
| GIoU | 2.0 | Generalized IoU on predicted boxes |
| L1 | 5.0 | L1 distance on predicted boxes |
| Focal | 1.0 | Focal loss on score/heatmap |
| mine_loss | 0.05 | JSD mutual information estimation (global MI) |
| activeness_loss | 12.0 | L1 loss between mean activation prob and target 0.7 |
| bddr_adv_loss | 0.01 | Hinge adversarial loss on BDDR discriminator |

Optional losses:

| Loss | Weight | Condition |
|------|:------:|-----------|
| focal_iou | --- | When `USE_FOCAL_IOU=True`: `(1-IoU)^2` weighting on tracking loss |
| distill_loss | 0.0001 | When `IS_DISTILL=True`: MI-based distillation from teacher ensemble |

---

## Anchored EMA Memory Update

### Memory Fusion (Inference)

```
T_final(t) = beta_t * T0 + (1-beta_t) * M_{t-1}
```

- **T0**: first-frame anchor template (frozen)
- **M**: memory template (updated via conditional EMA)
- **beta_t**: adaptive anchor weight derived from occlusion state and appearance similarity

### Conditional EMA Update

```
M_t = alpha_t * M_{t-1} + (1-alpha_t) * f_t          if all_g = True
      M_{t-1}                                          otherwise
```

### WEMA (Confidence-Weighted EMA)

```
alpha_t = alpha_high - (alpha_high - alpha_low) * sigma(k * (p_max - tau))
```

Higher peak confidence -> lower alpha_t -> higher new-frame weight -> more aggressive update.

### 6-Gate Soft-Vote

Six conditions are scored and weighted-summed:

| Gate | Condition | Weight |
|------|-----------|:------:|
| G1 | delta_t >= delta_t_min (minimum interval) | 1.0 |
| G2 | not occlusion-locked | 1.5 |
| G3 | p_max > tau (confidence) | 1.0 |
| G4 | stable streak >= N (consecutive high-conf) | 0.8 |
| G5 | IoU(B_t, B_bar) >= eta (motion consistency) | 1.0 |
| G6 | sim(f_t, T0) in [rho_low, rho_high] | 1.2 |

Update if sum w_i * g_i >= theta (soft-vote threshold).

### Adaptive beta_t

```
beta_t = beta_base + occ_boost + lambda * (1 - sim(M, T0))
```

- **occlusion**: beta_t >= beta_max (rely more on anchor)
- **appearance drift**: similarity drops -> beta_t increases -> prevent memory corruption

### Protection Mechanisms

- **Occlusion Lock**: p_max < lock_conf -> freeze memory; unlock after N consecutive p_max > unlock_conf
- **Drift Reset**: p_max < drift_conf for N frames -> reset M = T0

---

## Full Formula Reference

| Module | Key Formula |
|--------|------------|
| **MSCA-HFDA V2** | `combined = MSCA(x)*alpha + HFDA(x)*beta`, `out = proj_out(combined) * layer_scale + shortcut`, where MSCA = `sigma(FC(GAP(fused))) * fused`, HFDA = `HaarInv(LL + LevelGate(LH,HL) + 0)` |
| **BDDR** | `x_debiased = x - alpha * bg_beacon`, `f = 1 + alpha_pos*(2*r_pos-1) - alpha_neg*(2*r_neg-1)`, `x_out = x + Fuse(x_debiased * f)` |
| **Adaptive Skip** | `p_i = sigma(W * x[:,:,0].detach())`, `L_act = |p_bar - 0.7|_1` (weight=12) |
| **Attention Sharpening** | `attn = softmax(QK^T/sqrt(d)) + 0.1 * softmax(QK^T/sqrt(d))^2` |
| **Global MI** | `I_JSD(Z;X) = E_PZX[-sp(-T_theta(z,x))] - E_PZ_PX[sp(T_theta(z',x))]` |
| **Anchored EMA** | `T_final(t) = beta_t * T0 + (1-beta_t) * M_{t-1}`, `M_t = alpha_t*M_{t-1} + (1-alpha_t)*f_t` (if soft-vote sum(w_i*g_i) >= theta) |
| **WEMA** | `alpha_t = alpha_high - (alpha_high - alpha_low) * sigma(k*(p_max - tau))` |
| **Adaptive beta** | `beta_t = beta_0 + Delta_occ + lambda*(1 - sim(M, T0))` |
| **ATC** | `peakiness = (max - mean)/std`; G1: `peakiness > slope*p_max + offset`; update: `z_mem = 0.92*z_old + 0.08*z_new` |
| **Training Loss** | `loss = L_track + 0.05*L_mine + 12*L_act + 0.01*L_bddr_adv` |

---

## Project Structure

```
IAVtrack-main/
├── lib/
│   ├── config/avtrack/config.py          # All hyperparameters & ablation switches
│   ├── models/
│   │   ├── avtrack/
│   │   │   ├── avtrack.py                # AVTrack model + build_avtrack()
│   │   │   ├── vision_transformer.py     # ViT backbone + Adaptive Layer Skip + BDDR + MSCA-HFDA hook + Attention Sharpening
│   │   │   ├── msca_hfda.py              # MSCA-HFDA V2: MSCA channel attention + Haar HFDA
│   │   │   ├── bddr.py                   # BDDR: DANP-style bidirectional soft modulation + adversarial discriminator
│   │   │   ├── loss_functions.py         # DJSLoss (JSD mutual information estimator)
│   │   │   ├── statistics_network.py     # Global/Local statistics networks
│   │   │   ├── deit.py, eva.py           # Backbone variants (DeiT, EVA-02)
│   │   │   ├── base_backbone.py          # Base backbone (forward_from_z_embed)
│   │   │   └── utils.py                  # combine_tokens / recover_tokens
│   │   └── layers/                       # Head, patch_embed, attention, RPE
│   ├── train/
│   │   ├── train_script.py               # Multi-stage frozen training logic
│   │   ├── actors/avtrack.py             # Training actor + loss computation
│   │   ├── trainers/                     # Base training loop (base_trainer, ltr_trainer)
│   │   ├── data/                         # Image loader, transforms, sampler, processing, wandb_logger
│   │   └── dataset/                      # Dataset loaders (LaSOT, GOT-10k, COCO, UAV123, TrackingNet, ImageNetVID)
│   ├── test/
│   │   ├── tracker/
│   │   │   ├── avtrack.py                # Inference tracker (anchor+EMA+WEMA+6 gates + BDDR state + ATC)
│   │   │   ├── basetracker.py            # Base tracker class
│   │   │   ├── data_utils.py             # Preprocessor for tracker input
│   │   │   └── vis_utils.py              # Visualization utilities
│   │   └── evaluation/                   # Dataset wrappers (LaSOT, GOT-10k, UAV, etc.)
│   └── utils/                            # Box ops, heatmap utils, focal loss
├── tracking/
│   ├── train.py                          # Training launcher
│   ├── test.py                           # Testing/evaluation launcher
│   ├── video_demo.py                     # Single-video demo
│   └── profile_model.py                  # FLOPs & FPS profiling
├── experiments/
│   └── avtrack/                          # Ablation config YAML files
└── README.md
```

---

## Usage

### Installation

```bash
conda create -n IAVtrack python=3.9
conda activate IAVtrack
pip install -r requirements.txt
```

### Data Preparation

Put tracking datasets in `./data`:

```
${PROJECT_ROOT}
 -- data
     -- lasot
         |-- airplane / basketball / bear ...
     -- got10k
         |-- test / train / val
     -- coco
         |-- annotations / images
     -- trackingnet
         |-- TRAIN_0 .. TRAIN_11 / TEST
     -- uav123
         |-- anno / data_seq
     -- uav123@10fps
         |-- anno / data_seq
     -- uavdt
         |-- anno / sequences
     -- visdrone2018
         |-- annotations / sequences
     -- dtb70
         |-- Animal1 .. Zebra
```

### Path Setting

```bash
cd <PATH_of_IAVtrack>
python tracking/create_default_local_file.py --workspace_dir . --data_dir ./data --save_dir ./output
```

Or modify directly:
- `lib/train/admin/local.py`  --- training paths
- `lib/test/evaluation/local.py` --- testing paths

---

### Training

Download pretrained weights and place under `$USER_ROOT$/.cache/torch/hub/checkpoints/`:
- [DeiT-Tiny](https://dl.fbaipublicfiles.com/deit/deit_tiny_patch16_224-a1311bcf.pth)
- [Eva02-Tiny](https://huggingface.co/Yuxin-CV/EVA-02/resolve/main/eva02/pt/eva02_Ti_pt_in21k_p14.pt)
- [ViT-Tiny](https://storage.googleapis.com/vit_models/augreg/Ti_16-i21k-300ep-lr_0.001-aug_none-wd_0.03-do_0.0-sd_0.0--imagenet2012-steps_20k-lr_0.03-res_224.npz)

> **Note:** The config `PRETRAIN_FILE: mae_pretrain_vit_base.pth` in the original AVTrack is dead code --- the backbone loads timm's ImageNet-1k weights via `pretrained=True`. It has been removed from the baseline config.

#### Quick Start: Baseline Training

```bash
# Train AVTrack-DeiT baseline (80 epochs, mixed datasets)
python tracking/train.py --script avtrack --config deit_tiny_patch16_224_30ep_baseline --save_dir ./output
```

#### Full Pipeline: BDDR + MSCA-HFDA

```bash
# Stage 1: Train BDDR (80 epochs)
python tracking/train.py --script avtrack --config ablation_02_bddr_v2 --save_dir ./output

# Stage 2: Freeze backbone+BDDR, train MSCA-HFDA (80 epochs)
python tracking/train.py --script avtrack --config ablation_stage2_msca_bddr_mixed_v2 --save_dir ./output

# Stage 2 variant: no freeze, train everything end-to-end (80 epochs)
python tracking/train.py --script avtrack --config ablation_stage2_msca_bddr_mixed_v2_nofreeze --save_dir ./output
```

#### GOT-10k Only

```bash
# Baseline (GOT-10k)
$env:CUDA_VISIBLE_DEVICES=0; python tracking/train.py --script avtrack --config ablation_00_baseline_got10k --save_dir ./output/avtrack/ablation_00_baseline_got10k --mode single

# BDDR (GOT-10k)
$env:CUDA_VISIBLE_DEVICES=0; python tracking/train.py --script avtrack --config ablation_02_bddr_got10k --save_dir ./output/avtrack/ablation_02_bddr_got10k --mode single

# Full (BDDR + MSCA-HFDA, GOT-10k, single-stage)
$env:CUDA_VISIBLE_DEVICES=0; python tracking/train.py --script avtrack --config ablation_stage2_msca_bddr_got10k --save_dir ./output/avtrack/ablation_stage2_msca_bddr_got10k --mode single
```

#### Multi-GPU

```bash
# 4 GPUs
python tracking/train.py --script avtrack --config deit_tiny_patch16_224_30ep_baseline --save_dir ./output --mode multiple --nproc_per_node 4
```

### Testing / Evaluation

```bash
# Dataset evaluation (standard)
python tracking/test.py avtrack deit_tiny_patch16_224 --dataset_name lasot
python tracking/test.py avtrack deit_tiny_patch16_224 --dataset_name got10k
python tracking/test.py avtrack deit_tiny_patch16_224 --dataset_name uav123

# With ATC enabled (requires ATC in test config)
python tracking/test.py avtrack deit_tiny_patch16_224 --dataset_name lasot --config ablation_bddr_atc

# Specify checkpoint
python tracking/test.py avtrack deit_tiny_patch16_224 --dataset_name lasot --checkpoint ./output/checkpoints/train/avtrack/ablation_02_bddr_v2/AVTrack_ep0080.pth.tar

# Multi-GPU testing
python tracking/test.py avtrack deit_tiny_patch16_224 --dataset_name lasot --num_gpus 4
```

### Ablation Experiments

Config presets in `experiments/avtrack/` --- toggle individual modules to measure their contribution.

#### Single-Stage Ablation (Mixed Datasets)

| # | Config | MSCA-HFDA | BDDR | ATC | Epochs |
|---|--------|:---:|:---:|:---:|:------:|
| 0 | `deit_tiny_patch16_224_30ep_baseline.yaml` | | | | 80 |
| 1 | `ablation_02_bddr_v2.yaml` | | YES | | 80 |
| 2 | `ablation_stage2_msca_bddr_mixed_v2_nofreeze.yaml` | YES | YES | | 80 |
| 3 | `ablation_bddr_atc.yaml` | | YES | YES | 80* |
| 4 | `ablation_stage2_msca_bddr_mixed_v2_atc.yaml` | YES | YES | YES | 80* |

> `*` ATC is test-time only; the training config is unchanged (`ablation_02_bddr_v2.yaml` / `ablation_stage2_msca_bddr_mixed_v2.yaml`).

Branch-level ablation of the MSCA-HFDA module (`MSCA_HFDA_MODE`):

| Config | Mode | Active branch |
|--------|------|---------------|
| `ablation_01_msca_only.yaml` | `msca_only` | multi-scale channel attention only |
| `ablation_01_hfda_only.yaml` | `hfda_only` | Haar frequency-domain attention only |
| `ablation_01_msca_hfda_v2.yaml` | (both) | full V2 module |

#### Single-Stage Ablation (GOT-10k Only)

| # | Config | MSCA-HFDA | BDDR | Epochs |
|---|--------|:---:|:---:|:------:|
| 0 | `ablation_00_baseline_got10k.yaml` | | | 45 |
| 1 | `ablation_01_msca_hfda_got10k.yaml` | YES | | 45 |
| 2 | `ablation_02_bddr_got10k.yaml` | | YES | 60 |
| 3 | `ablation_stage2_msca_bddr_got10k.yaml` | YES | YES | 45 |

#### Multi-Stage Ablation (Full Pipeline)

| # | Config | Stage | Frozen | Trained | Epochs |
|---|--------|:-----:|--------|---------|:------:|
| 1 | `ablation_02_bddr_v2.yaml` | Stage 1 | layer 0 | Backbone(0.1x) + BDDR + Head | 80 |
| 2 | `ablation_stage2_msca_bddr_mixed_v2.yaml` | Stage 2 | Backbone + BDDR | MSCA-HFDA + Head | 80 |
| 3 | `ablation_stage2_msca_bddr_mixed_v2_nofreeze.yaml` | joint | layer 0 | Backbone(0.1x) + BDDR + MSCA-HFDA + Head | 80 |

#### Existing Config Files

```
experiments/avtrack/
├── deit_tiny_patch16_224_30ep_baseline.yaml    # Baseline (80ep, mixed)
├── ablation_00_baseline_got10k.yaml            # Baseline (45ep, GOT-10k)
├── ablation_01_msca_only.yaml                  # MSCA-HFDA: msca_only (80ep, mixed)
├── ablation_01_msca_only_atc.yaml              # msca_only + ATC (test)
├── ablation_01_hfda_only.yaml                  # MSCA-HFDA: hfda_only (80ep, mixed)
├── ablation_01_hfda_only_atc.yaml              # hfda_only + ATC (test)
├── ablation_01_msca_hfda_v2.yaml               # MSCA-HFDA V2 full (80ep, mixed)
├── ablation_01_msca_hfda_got10k.yaml           # MSCA-HFDA (45ep, GOT-10k)
├── ablation_02_bddr_v2.yaml                    # BDDR v2 (80ep, mixed)
├── ablation_02_bddr_got10k.yaml                # BDDR (60ep, GOT-10k)
├── ablation_02_bddr_wo_neg.yaml                # BDDR w/o negative beacon
├── ablation_02_bddr_wo_debias.yaml             # BDDR w/o debiasing
├── ablation_02_bddr_bcr.yaml                   # BDDR w/ BCR
├── ablation_05_msca_hfda_bddr_got10k.yaml      # MSCA-HFDA + EMA memory (45ep, GOT-10k)
├── ablation_stage2_msca_bddr_mixed.yaml        # Stage 2, frozen (mixed)
├── ablation_stage2_msca_bddr_mixed_atc.yaml    # Stage 2, frozen (mixed) + ATC (test)
├── ablation_stage2_msca_bddr_mixed_v2.yaml     # Stage 2, frozen (mixed)  -- main result
├── ablation_stage2_msca_bddr_mixed_v2_atc.yaml # Stage 2, frozen (mixed) + ATC  -- main result
├── ablation_stage2_msca_bddr_mixed_v2_nofreeze.yaml  # Stage 2 variant: no freeze (joint)
├── ablation_stage2_msca_bddr_got10k.yaml       # MSCA-HFDA + BDDR joint (45ep, GOT-10k)
├── ablation_stage2_msca_bddr_got10k_stage2.yaml# MSCA-HFDA + BDDR, stage-2 variant (GOT-10k)
├── ablation_stage2_msca_bddr_got10k_atc.yaml   # MSCA-HFDA + BDDR (GOT-10k) + ATC (test)
├── ablation_baseline_atc.yaml                  # Baseline + ATC (test)
├── ablation_bddr_atc.yaml                      # BDDR + ATC (test)
├── ablation_msca_atc.yaml                      # MSCA-HFDA + ATC (test)
├── ablation_atc_full.yaml                      # ATC: all components on
├── ablation_atc_anchored.yaml                  # ATC: anchor memory only
├── ablation_atc_wo_anchor.yaml                 # ATC: w/o anchor memory
├── ablation_atc_wo_failure.yaml                # ATC: w/o failure detection
├── ablation_atc_wo_peakquality.yaml            # ATC: w/o peak-quality gate
├── ablation_atc_wo_temporal.yaml               # ATC: w/o temporal gate
├── ablation_upd_none.yaml                      # Template update: none
├── ablation_upd_interval.yaml                  # Template update: fixed interval
├── ablation_upd_thresh.yaml                    # Template update: confidence threshold
└── ablation_upd_always.yaml                    # Template update: always

### Video Demo

```bash
python tracking/video_demo.py avtrack deit_tiny_patch16_224 /path/to/video.mp4
python tracking/video_demo.py avtrack deit_tiny_patch16_224 /path/to/video.mp4 --optional_box 100 200 50 80 --save_results
```

### Profile (FPS & FLOPs)

```bash
python tracking/profile_model.py --script avtrack --config deit_tiny_patch16_224_30ep_baseline
```

---

## Config Reference

Core configuration is in `lib/config/avtrack/config.py`. Override via experiment YAML files.

### Backbone

| Config | Default | Description |
|--------|---------|-------------|
| `MODEL.BACKBONE.TYPE` | `vit_base_patch16_224` | Backbone: `deit_tiny_patch16_224`, `vit_tiny_patch16_224`, `eva02_tiny_patch14_224`, etc. |
| `MODEL.BACKBONE.STRIDE` | `16` | Patch stride |
| `MODEL.BACKBONE.CAT_MODE` | `direct` | Template-search token concatenation mode |

### Ablation Switches (Train + Backbone)

| Config | Default | Description |
|--------|---------|-------------|
| `MODEL.ABLATION.USE_MSCA_HFDA` | `False` | MSCA-HFDA V2: asymmetric MSCA channel attention + Haar HFDA, after PatchEmbed on ViT embeddings |
| `MODEL.ABLATION.USE_BDDR` | `False` | BDDR DANP-style bidirectional soft modulation before ViT Encoder |
| `MODEL.ABLATION.USE_ADAPTIVE_SKIP` | `True` | Per-block conditional execution + activeness loss (weight=12) |
| `MODEL.ABLATION.USE_FOCAL_IOU` | `False` | Focal IoU weighting on box regression |

### Multi-Stage Training Flags

| Config | Default | Description |
|--------|---------|-------------|
| `TRAIN.STAGE2_TRAIN` | `False` | Freeze backbone+BDDR, train MSCA-HFDA+Head only |
| `TRAIN.FREEZE_BACKBONE_TRAIN_BDDR` | `False` | Freeze backbone, train BDDR+Head only |

### Training

| Config | Default | Description |
|--------|---------|-------------|
| `MODEL.IS_DISTILL` | `False` | Enable knowledge distillation training |
| `MODEL.EXTRA_MERGER` | `False` | Extra merger module |
| `MODEL.RETURN_INTER` | `False` | Return intermediate features |
| `MODEL.NUM_OBJECT_QUERIES` | `1` | Number of object queries |

### ATC (Test-Time Adaptive Calibration)

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.ABLATION.USE_ATC` | `False` | Enable ATC adaptive calibration |
| `TEST.ATC_ALPHA` | `0.92` | EMA weight for template update |
| `TEST.ATC_WINDOW` | `50` | Sliding window size for calibration |
| `TEST.ATC_REFIT_INTERVAL` | `10` | Re-fit calibration every N frames |
| `TEST.ATC_PMIN` | `0.50` | Absolute minimum p_max threshold |
| `TEST.ATC_SIM_LOW` | `0.60` | Minimum cosine similarity for update |

### Anchored EMA Memory (Inference)

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.EMA_ALPHA` | `0.97` | Static EMA update coefficient (when WEMA off) |
| `TEST.ANCHOR_BETA` | `0.7` | Static anchor fusion coefficient (when adaptive beta off) |
| `TEST.GATE_TAU` | `0.8` | Confidence threshold for update |
| `TEST.DELTA_T_MIN` | `5` | Min frames between updates |
| `TEST.STABLE_MIN` | `2` | Min consecutive high-confidence frames |
| `TEST.BOX_IOU_WITH_HISTORY` | `0.7` | IoU threshold for motion consistency |
| `TEST.FT_SIM_LOW` | `0.6` | Lower bound for appearance similarity |
| `TEST.FT_SIM_HIGH` | `0.95` | Upper bound for appearance similarity |

**Occlusion & Drift:**

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.LOCK_OCC_CONF` | `0.5` | Score below -> occlusion lock |
| `TEST.UNLOCK_OCC_FRAMES` | `10` | Consecutive frames above threshold to unlock |
| `TEST.UNLOCK_OCC_CONF` | `0.8` | Score above -> count for unlock streak |
| `TEST.DRIFT_CONF` | `0.4` | Score below -> drift counter increments |
| `TEST.DRIFT_FRAMES` | `5` | Consecutive drift -> reset memory to T0 |

**WEMA:**

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.WEMA_ALPHA_HIGH` | `0.98` | Max EMA coefficient (low confidence, conservative) |
| `TEST.WEMA_ALPHA_LOW` | `0.93` | Min EMA coefficient (high confidence, aggressive) |
| `TEST.WEMA_K` | `8.0` | Sigmoid steepness |

**Adaptive beta:**

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.BETA_BASE` | `0.50` | Base anchor weight (no occlusion, high similarity) |
| `TEST.BETA_MAX` | `0.85` | Max anchor weight under occlusion |
| `TEST.BETA_LAMBDA` | `0.25` | Sensitivity to appearance drift |

**Soft-Vote Gating:**

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.SOFT_VOTE_THETA` | `3.8` | Weighted sum threshold for update |
| `TEST.GATE_W1` | `1.0` | delta_t_min gate weight |
| `TEST.GATE_W2` | `1.5` | Not-occluded gate weight (highest priority) |
| `TEST.GATE_W3` | `1.0` | Confidence gate weight |
| `TEST.GATE_W4` | `0.8` | Stability gate weight |
| `TEST.GATE_W5` | `1.0` | Motion consistency gate weight |
| `TEST.GATE_W6` | `1.2` | Appearance similarity gate weight |

**Peak Feature:**

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.PEAK_NEIGHBOUR_K` | `3` | Half-width of peak region |
| `TEST.PEAK_NEIGHBOUR_LAMBDA` | `0.40` | Fusion weight (0.4 peak + 0.6 crop) |

**Ablation Switches:**

| Config | Default | Description |
|--------|---------|-------------|
| `TEST.ABLATION.USE_ANCHOR_MEMORY_FUSION` | `True` | Anchor + memory fusion in template path |
| `TEST.ABLATION.USE_EMA_MEMORY_UPDATE` | `True` | Conditional EMA memory updates |
| `TEST.ABLATION.USE_GATE_G1`~`G6` | `True` | Individual gate switches |
| `TEST.ABLATION.USE_OCCLUSION_LOCK` | `True` | Occlusion lock/unlock logic |
| `TEST.ABLATION.USE_DRIFT_RESET` | `True` | Drift detection & memory reset |
| `TEST.ABLATION.USE_WEMA` | `True` | Confidence-weighted adaptive EMA |
| `TEST.ABLATION.USE_ADAPTIVE_BETA` | `True` | Adaptive anchor fusion weight |
| `TEST.ABLATION.USE_SOFT_VOTE` | `True` | Soft-vote gating instead of hard AND |
| `TEST.ABLATION.USE_PEAK_FEATURE` | `True` | Peak neighbourhood feature for EMA update |

---

## Backbone Variants

Available backbones (set via `MODEL.BACKBONE.TYPE`):

| Backbone | Params | Patch | Embed Dim | Depth | Heads |
|----------|:------:|:-----:|:---------:|:-----:|:-----:|
| `deit_tiny_patch16_224` | 5.7M | 16 | 192 | 12 | 3 |
| `deit_tiny_distilled_patch16_224` | 5.7M | 16 | 192 | 6 | 3 |
| `vit_tiny_patch16_224` | 5.7M | 16 | 192 | 12 | 3 |
| `vit_tiny_distilled_patch16_224` | 5.7M | 16 | 192 | 6 | 3 |
| `eva02_tiny_patch14_224` | 5.7M | 14 | 192 | 12 | 3 |
| `eva02_tiny_distilled_patch14_224` | 5.7M | 14 | 192 | 12 | 3 |

---

## License

This project is released under the same license as the original AVTrack. See [LICENSE](LICENSE) for details.
