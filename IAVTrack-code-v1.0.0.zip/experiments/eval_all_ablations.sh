#!/bin/bash
cd "$(dirname "$0")/.."
echo "Working dir: $(pwd)"

mkdir -p output/test/eval_cache 2>/dev/null || true

python3 -c "
import os, sys, numpy as np, torch
sys.path.insert(0, os.getcwd())
np.set_printoptions(precision=3, suppress=True)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.analysis.extract_results import extract_results

def eval_and_print(label, ds_list, cfg_list):
    print()
    print('=' * 65)
    print(f'  {label}')
    print('=' * 65)
    for ds_name in ds_list:
        dataset = get_dataset(ds_name)
        trackers = [Tracker('avtrack', c, ds_name) for c in cfg_list]
        report = ds_name if ds_name != 'got10k_test' else 'got10k'

        # 直接算结果（extract_results 保存 pkl 失败不会抛异常了）
        data = extract_results(trackers, dataset, report, skip_missing_seq=False)

        auc = np.array(data['ave_success_rate_plot_overlap']).mean(axis=(0,2)) * 100
        prec = np.array(data['ave_success_rate_plot_center'])[:, :, 20].mean(axis=0) * 100

        print(f'--- {ds_name} ---')
        for i, cfg in enumerate(cfg_list):
            print(f'  {cfg:<50s}  AUC={auc[i]:.2f}  Prec@20={prec[i]:.2f}')
        print()

# ---- NoATC ----
eval_and_print('Mixed (No ATC)', ['uavdt','uav123','dtb70'], [
    'deit_tiny_patch16_224_30ep_baseline',
    'ablation_02_bddr_v2',
    'ablation_stage2_msca_bddr_mixed',
])

# ---- WithATC ----
eval_and_print('Mixed (With ATC)', ['uavdt','uav123','dtb70'], [
    'ablation_02_bddr_v2_atc',
    'ablation_stage2_msca_bddr_mixed_atc',
])

# ---- GOT10k ----
eval_and_print('GOT-10k', ['got10k_test'], [
    'ablation_02_bddr_got10k',
    'ablation_stage2_msca_bddr_got10k_stage2',
])
print('Done.')
"
