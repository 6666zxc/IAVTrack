#!/bin/bash
# ============================================================================
#  IAVtrack Ablation Training Pipeline (5 steps, 350 GPU-epochs total)
#  Run in WSL: bash experiments/train_all_ablations.sh
#  Note: ATC is inference-time only, no training needed.
#
#  Mixed dataset first, GOT-10k last:
#    Step 1: Baseline (AM only, mixed)    → 100 ep  [resume if exists]
#    Step 2: BDDR v2 (AM+BDDR, mixed)     → 80 ep   [从头训]
#    Step 3: MSCA Stage2 (frozen B+BDDR, mixed)  → 80 ep
#    Step 4: BDDR GOT-10k                  → 45 ep
#    Step 5: MSCA Stage2 (frozen B+BDDR, GOT-10k) → 45 ep
# ============================================================================
set -e

cd "$(dirname "$0")/.."
echo "Working dir: $(pwd)"
echo "Save root: $(pwd)/output"

SAVE_ROOT="output"
MODE="single"

run_train() {
    local step="$1"; local config="$2"; local epochs="$3"
    echo ""
    echo "=============================================="
    echo "  Step ${step}: ${config} (${epochs} epochs)"
    echo "=============================================="
    if [ "$MODE" = "single" ]; then
        python tracking/train.py --script avtrack --config "$config" --save_dir "$SAVE_ROOT"
    else
        python tracking/train.py --script avtrack --config "$config" --save_dir "$SAVE_ROOT" \
            --mode multiple --nproc_per_node "$NPROC"
    fi
}

# ---- Mixed Dataset ----
# Step 1: Baseline (已完成，跳过)
# run_train "1/5" "deit_tiny_patch16_224_30ep_baseline" "100"

# Step 2: BDDR v2 (从头训 80 epoch)
run_train "2/5" "ablation_02_bddr_v2" "80"

# Step 3: MSCA Stage2 mixed (freeze backbone+BDDR, train MSCA)
run_train "3/5" "ablation_stage2_msca_bddr_mixed" "80"

# ---- GOT-10k (暂不跑) ----
# Step 4: BDDR GOT-10k
# run_train "4/5" "ablation_02_bddr_got10k" "45"

# Step 5: MSCA Stage2 GOT-10k (freeze backbone+BDDR, train MSCA)
# run_train "5/5" "ablation_stage2_msca_bddr_got10k_stage2" "45"

echo ""
echo "=============================================="
echo "  Training Pipeline Complete!"
echo "=============================================="
echo "Checkpoints:"
echo "  ---- Mixed Dataset ----"
echo "  $SAVE_ROOT/checkpoints/train/avtrack/deit_tiny_patch16_224_30ep_baseline/AVTrack_ep0100.pth.tar"
echo "  $SAVE_ROOT/checkpoints/train/avtrack/ablation_02_bddr_v2/AVTrack_ep0080.pth.tar"
echo "  $SAVE_ROOT/checkpoints/train/avtrack/ablation_stage2_msca_bddr_mixed/AVTrack_ep0080.pth.tar"
echo "  ---- GOT-10k ----"
echo "  $SAVE_ROOT/checkpoints/train/avtrack/ablation_02_bddr_got10k/AVTrack_ep0045.pth.tar"
echo "  $SAVE_ROOT/checkpoints/train/avtrack/ablation_stage2_msca_bddr_got10k_stage2/AVTrack_ep0045.pth.tar"
