#!/bin/bash
# ============================================================================
#  V2 Ablation Evaluation
#  Run in WSL: bash experiments/eval_v2_ablations.sh
#
#  评估 V2 版本消融实验（USE_LEARNABLE_PNEG=false）:
#    Baseline               — deit_tiny_patch16_224_30ep_baseline
#    BDDR                   — ablation_02_bddr_v2
#    MSCA+HFDA              — ablation_01_msca_hfda_v2
#    BDDR+MSCA+HFDA         — ablation_stage2_msca_bddr_mixed_v2
#    BDDR+MSCA+HFDA+ATC     — ablation_stage2_msca_bddr_mixed_v2_atc
#
#  指标: 标准 OPE  AUC / Prec@20 (小数形式, 与之前评估一致)
# ============================================================================
cd "$(dirname "$0")/.."
echo "Working dir: $(pwd)"

mkdir -p output/test/eval_cache 2>/dev/null || true

python3 -c "
import os, sys, numpy as np
sys.path.insert(0, os.getcwd())

from lib.test.evaluation import get_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.analysis.extract_results import extract_results

CFG_LABELS = [
    ('deit_tiny_patch16_224_30ep_baseline',    'Baseline'),
    ('ablation_02_bddr_v2',                    'BDDR'),
    ('ablation_01_msca_hfda_v2',               'MSCA+HFDA'),
    ('ablation_stage2_msca_bddr_mixed_v2',     'BDDR+MSCA+HFDA'),
    ('ablation_stage2_msca_bddr_mixed_v2_atc', 'BDDR+MSCA+HFDA+ATC'),
]

for ds_name in ['uavdt', 'uav123', 'dtb70']:
    dataset = get_dataset(ds_name)
    trackers = [Tracker('avtrack', c, ds_name) for c, _ in CFG_LABELS]
    report = ds_name if ds_name != 'got10k_test' else 'got10k'
    data = extract_results(trackers, dataset, report, skip_missing_seq=False)

    auc = np.array(data['ave_success_rate_plot_overlap']).mean(axis=(0, 2))
    prec = np.array(data['ave_success_rate_plot_center'])[:, :, 20].mean(axis=0)

    print(ds_name)
    print('=' * 46)
    print('{:<26s}{:>8s}{:>10s}'.format('Tracker', 'AUC', 'Prec@20'))
    print('-' * 46)
    for i, (_, label) in enumerate(CFG_LABELS):
        print('{:<26s}{:>8.4f}{:>10.4f}'.format(label, auc[i], prec[i]))
    print()
print('Done.')
"
