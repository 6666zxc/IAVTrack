#!/bin/bash
# ============================================================================
#  IAVtrack Ablation Test Pipeline
#  Run in WSL: bash experiments/test_all_ablations.sh
#
#  测试所有消融实验，两轮结果存到不同文件夹：
#    folder1: without_ATC  — 不含 ATC 的原始模型
#    folder2: with_ATC     — 含 ATC 的推理
# ============================================================================
set -e

cd "$(dirname "$0")/.."
echo "Working dir: $(pwd)"

# ---------- 配置 ----------
TRACKER="avtrack"
MIXED_DATASETS=("uavdt" "uav123" "dtb70")
GOT10K_DATASETS="got10k_test"
NUM_GPUS=1
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# ---------- without ATC ----------
FOLDER1="output/test/tracking_results_noATC_${TIMESTAMP}"
echo "============================================"
echo "  Round 1: Without ATC"
echo "  Results → ${FOLDER1}"
echo "============================================"

for ds in "${MIXED_DATASETS[@]}"; do
    for cfg in deit_tiny_patch16_224_30ep_baseline ablation_02_bddr_v2 ablation_stage2_msca_bddr_mixed; do
        echo ""
        echo "[noATC] ${cfg} @ ${ds}"
        python tracking/test.py "$TRACKER" "$cfg" \
            --dataset_name "$ds" --num_gpus "$NUM_GPUS" \
            --results_dir "${FOLDER1}"
    done
done

# GOT-10k models on got10k_test
for cfg in ablation_02_bddr_got10k ablation_stage2_msca_bddr_got10k_stage2; do
    echo ""
    echo "[noATC] ${cfg} @ got10k_test"
    python tracking/test.py "$TRACKER" "$cfg" \
        --dataset_name got10k_test --num_gpus "$NUM_GPUS" \
        --results_dir "${FOLDER1}"
done

# ---------- with ATC ----------
FOLDER2="output/test/tracking_results_withATC_${TIMESTAMP}"
echo ""
echo "============================================"
echo "  Round 2: With ATC"
echo "  Results → ${FOLDER2}"
echo "============================================"

for ds in "${MIXED_DATASETS[@]}"; do
    for cfg in ablation_02_bddr_v2_atc ablation_stage2_msca_bddr_mixed_atc; do
        echo ""
        echo "[withATC] ${cfg} @ ${ds}"
        python tracking/test.py "$TRACKER" "$cfg" \
            --dataset_name "$ds" --num_gpus "$NUM_GPUS" \
            --results_dir "${FOLDER2}"
    done
done

echo ""
echo "============================================"
echo "  All tests complete!"
echo "  No ATC : ${FOLDER1}"
echo "  With ATC: ${FOLDER2}"
echo "============================================"
