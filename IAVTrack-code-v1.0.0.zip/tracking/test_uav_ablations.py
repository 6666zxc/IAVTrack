"""
顺序测试脚本：在 UAVDT, UAV123, UAV123_20l 上运行 4 个消融配置
结果保存到 output/test/tracking_results/avtrack/ 下对应子目录
"""
import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.evaluation.environment import env_settings

EXPERIMENTS = [
    ("deit_tiny_patch16_224_30ep_baseline",          "Baseline"),
    ("ablation_02_bddr_v2",                           "BDDR"),
    ("ablation_stage2_msca_bddr_mixed",               "BDDR+MSCA"),
    ("ablation_stage2_msca_bddr_mixed_atc",           "BDDR+MSCA+ATC"),
]

DATASETS = ["uavdt", "uav123", "uav123_20l"]

TRACKER_NAME = "avtrack"
NUM_GPUS = 1

def main():
    env = env_settings()
    # 直接写入 tracking_results 目录（与已有 DTB70 结果汇合）
    results_root = os.path.join(env.save_dir, "test", "tracking_results", TRACKER_NAME)

    total = len(EXPERIMENTS) * len(DATASETS)
    count = 0

    print("=" * 70)
    print(f"结果根目录: {results_root}")
    print(f"共 {len(EXPERIMENTS)} 个实验 × {len(DATASETS)} 个数据集 = {total} 次测试")
    print("=" * 70)

    for exp_idx, (param_name, exp_label) in enumerate(EXPERIMENTS, 1):
        for ds_idx, ds_name in enumerate(DATASETS, 1):
            count += 1
            print(f"\n{'=' * 70}")
            print(f"[{count}/{total}] 实验 {exp_idx}/{len(EXPERIMENTS)}: {exp_label}")
            print(f"        数据集 {ds_idx}/{len(DATASETS)}: {ds_name}")
            print(f"        配置: {param_name}")
            print(f"{'=' * 70}")

            dataset = get_dataset(ds_name)
            tracker = Tracker(TRACKER_NAME, param_name, ds_name, run_id=None)

            # 覆盖 results_dir 指向 tracking_results/avtrack/<config>
            tracker.results_dir = os.path.join(results_root, param_name)
            os.makedirs(os.path.join(tracker.results_dir, ds_name), exist_ok=True)

            run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=NUM_GPUS)

            print(f"[{count}/{total}] 完成: {exp_label} @ {ds_name}")

    print(f"\n{'=' * 70}")
    print(f"全部完成! 结果保存在: {results_root}")
    print(f"{'=' * 70}")

if __name__ == "__main__":
    main()
