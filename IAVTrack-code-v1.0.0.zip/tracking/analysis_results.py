import _init_paths
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [8, 8]

from lib.test.analysis.plot_results import plot_results, print_results, print_per_sequence_results
from lib.test.evaluation import get_dataset, trackerlist

for dataset_name in ['dtb70', 'uav123', 'uav123_20l', 'uavdt', 'visdrone2018']:
    trackers = []
    trackers.extend(trackerlist(name='avtrack', parameter_name='deit_tiny_patch16_224_30ep_baseline',
                                dataset_name=dataset_name, run_ids=None, display_name='Baseline'))
    trackers.extend(trackerlist(name='avtrack', parameter_name='ablation_02_bddr_v2',
                                dataset_name=dataset_name, run_ids=None, display_name='BDDR'))
    dataset = get_dataset(dataset_name)
    print_results(trackers, dataset, dataset_name, merge_results=True, plot_types=('success', 'prec'),
                  exclude_invalid_frames=True, force_evaluation=True)
    print()
