#!/usr/bin/env python3
"""Run IAVTrack on selected UAV123 sequences and dump the appearance-collection
template crops (initial template + every ATC-accepted update crop), for Fig.5-style
visualization. Repo code is NOT modified: we monkey-patch tracker methods.

Usage:
    python tracking/dump_appearance.py --config ablation_stage2_msca_bddr_mixed_atc \
        --seqs group2_1 car14 person18 \
        --uav123_root /mnt/e/member/sth/IAVtrack-main/data/UAV123 \
        --out_root "/mnt/e/member/sth/efficient contrast/appearance_dump"
"""
import argparse
import importlib
import os
import re
import sys

_prj = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _prj not in sys.path:
    sys.path.insert(0, _prj)

import cv2
import numpy as np

from lib.train.data.processing_utils import sample_target

# seq -> (image dir, startFrame, endFrame, anno file)  (same as uav123dataset.py)
SEQS = {
    'group2_1':  ('data_seq/UAV123/group2',   1, 907,  'anno/UAV123/group2_1.txt'),
    'car14':     ('data_seq/UAV123/car14',    1, 1327, 'anno/UAV123/car14.txt'),
    'person18':  ('data_seq/UAV123/person18', 1, 1393, 'anno/UAV123/person18.txt'),
}


def load_gt(path):
    boxes = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = re.split(r'[\s,]+', line)
            if len(parts) < 4:
                continue
            boxes.append([float(p) for p in parts[:4]])
    return np.array(boxes, dtype=np.float64)


def run_sequence(seq_name, cfg_name, root, out_root):
    img_sub, start, end, anno_sub = SEQS[seq_name]
    frames = [os.path.join(root, img_sub, '%06d.jpg' % f) for f in range(start, end + 1)]
    gt = load_gt(os.path.join(root, anno_sub))

    param_module = importlib.import_module('lib.test.parameter.avtrack')
    params = param_module.parameters(cfg_name)
    params.debug = 0
    params.save_all_boxes = False

    tracker_module = importlib.import_module('lib.test.tracker.avtrack')
    tracker = tracker_module.get_tracker_class()(params, 'uav123')

    seq_out = os.path.join(out_root, seq_name)
    os.makedirs(seq_out, exist_ok=True)
    for fn in os.listdir(seq_out):
        if fn.startswith('update_f') or fn in ('init_template.png', 'boxes.txt', 'updates.txt'):
            os.remove(os.path.join(seq_out, fn))

    updates = []
    captured = {'crop': None}
    orig_extract = tracker._extract_template_features
    orig_atc = tracker._atc_process

    def wrapped_extract(image):
        # recompute the exact crop the tracker extracts (same state -> same crop)
        try:
            if len(tracker.box_history) >= 1:
                boxes = list(tracker.box_history)
                cx = sum(b[0] + b[2] / 2 for b in boxes) / len(boxes)
                cy = sum(b[1] + b[3] / 2 for b in boxes) / len(boxes)
            else:
                cx = tracker.state[0] + tracker.state[2] / 2
                cy = tracker.state[1] + tracker.state[3] / 2
            w0, h0 = tracker._init_bbox_w, tracker._init_bbox_h
            anchor_box = [cx - w0 / 2, cy - h0 / 2, w0, h0]
            z_patch, _, _ = sample_target(image, anchor_box, tracker.params.template_factor,
                                          output_sz=tracker.params.template_size)
            captured['crop'] = z_patch
        except Exception:
            captured['crop'] = None
        return orig_extract(image)

    def wrapped_atc(image, p_max, pred_score_map):
        captured['crop'] = None
        zm = tracker.z_memory
        before = float(zm.abs().sum().item()) if zm is not None else None
        orig_atc(image, p_max, pred_score_map)
        zm2 = tracker.z_memory
        if zm2 is None or captured['crop'] is None:
            return
        after = float(zm2.abs().sum().item())
        if before is None or abs(after - before) > 1e-9:
            fid = tracker.frame_id
            updates.append(fid)
            cv2.imwrite(os.path.join(seq_out, 'update_f%06d.png' % fid),
                        cv2.cvtColor(captured['crop'], cv2.COLOR_RGB2BGR))

    tracker._extract_template_features = wrapped_extract
    tracker._atc_process = wrapped_atc

    boxes_out = []
    for i, fp in enumerate(frames):
        image = cv2.cvtColor(cv2.imread(fp), cv2.COLOR_BGR2RGB)
        if i == 0:
            tracker.initialize(image, {'init_bbox': gt[0]})
            cv2.imwrite(os.path.join(seq_out, 'init_template.png'),
                        cv2.cvtColor(tracker.z_patch_arr, cv2.COLOR_RGB2BGR))
            boxes_out.append(gt[0].tolist())
        else:
            out = tracker.track(image, None)
            boxes_out.append([float(v) for v in out['target_bbox'][:4]])
        if (i + 1) % 200 == 0:
            print('[%s] %d/%d  updates=%d' % (seq_name, i + 1, len(frames), len(updates)), flush=True)

    with open(os.path.join(seq_out, 'boxes.txt'), 'w') as f:
        for b in boxes_out:
            f.write(','.join('%.2f' % v for v in b) + '\n')
    with open(os.path.join(seq_out, 'updates.txt'), 'w') as f:
        f.write(','.join(str(u) for u in updates))
    print('[%s] DONE  frames=%d  accepted template updates=%d' % (seq_name, len(frames), len(updates)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--config', default='ablation_stage2_msca_bddr_mixed_atc')
    p.add_argument('--seqs', nargs='+', default=['group2_1', 'car14', 'person18'])
    p.add_argument('--uav123_root', default='/mnt/e/member/sth/IAVtrack-main/data/UAV123')
    p.add_argument('--out_root', default='/mnt/e/member/sth/efficient contrast/appearance_dump')
    args = p.parse_args()
    for s in args.seqs:
        run_sequence(s, args.config, args.uav123_root, args.out_root)


if __name__ == '__main__':
    main()
