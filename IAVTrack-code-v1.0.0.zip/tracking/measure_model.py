"""测量 AVTrack 模型参数量与 FPS（论文 Table 用）。

用法:
  # 1) 参数量（基于 yaml 配置构建模型结构，无需 checkpoint）
  python tracking/measure_model.py ablation_stage2_msca_bddr_got10k_atc

  # 2) 参数量 + 直接跑 FPS（加载 checkpoint，用真实图像按完整跟踪流程计时）
  python tracking/measure_model.py ablation_stage2_msca_bddr_got10k_atc --fps

  # 3) 从已有的 *_time.txt 统计 FPS（等于真实评测时的 FPS）
  python tracking/measure_model.py ablation_stage2_msca_bddr_got10k_atc --from_time
"""
import os
import sys
import glob
import time
import argparse

prj = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if prj not in sys.path:
    sys.path.insert(0, prj)

import numpy as np
import torch
import cv2

from lib.config.avtrack.config import cfg, update_config_from_file
from lib.models.avtrack import build_avtrack


def count_params(yaml_name):
    yaml_file = os.path.join(prj, 'experiments/avtrack/%s.yaml' % yaml_name)
    if not os.path.isfile(yaml_file):
        sys.exit('yaml 不存在: %s' % yaml_file)
    update_config_from_file(yaml_file)
    model = build_avtrack(cfg, training=False)

    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)

    # 推理时实际使用的模块（global_stat_x/djs_loss 仅训练用）
    # 注意: bddr/msca_hfda 会被挂载到 backbone 上，需按参数对象集合去重
    infer_names = {
        'backbone': model.backbone,
        'box_head': model.box_head,
        'bddr': model.bddr,
        'msca_hfda': model.msca_hfda,
    }
    all_params = set(model.parameters())
    gs_params = set(model.global_stat_x.parameters())
    infer_set = all_params - gs_params          # 去掉仅训练组件
    # 各子模块单独统计（backbone 只算未挂载的部分）
    def mod_params(m):
        return set(m.parameters())
    print('%-22s %10s' % ('模块', '参数量 (M)'))
    print('-' * 36)
    for k, m in infer_names.items():
        if m is not None:
            n = sum(p.numel() for p in mod_params(m))
            print('%-22s %10.3f' % (k, n / 1e6))
    print('%-22s %10.3f' % ('global_stat_x (仅训练)', sum(p.numel() for p in gs_params) / 1e6))
    print('-' * 36)
    infer_total = sum(p.numel() for p in infer_set)
    print('%-22s %10.3f' % ('推理参数量（去重）', infer_total / 1e6))
    print('%-22s %10.3f' % ('完整模型（含训练组件）', total / 1e6))
    print('%-22s %10.3f' % ('可训练', trainable / 1e6))
    return model


def fps_from_time_files(yaml_name):
    """从真实评测生成的 *_time.txt 统计 FPS（去掉首帧初始化）。"""
    got10k_dir = os.path.join(prj, 'output/test/tracking_results/avtrack', yaml_name, 'got10k')
    if not os.path.isdir(got10k_dir):
        sys.exit('未找到结果目录: %s（请先跑完测试）' % got10k_dir)
    times = []
    for tf in glob.glob(os.path.join(got10k_dir, '*_time.txt')):
        t = np.loadtxt(tf, delimiter='\t', dtype=float)
        if t.ndim == 0:
            continue
        if len(t) > 1:
            times.extend(t[1:])   # 去掉第 0 帧初始化
        else:
            times.extend(t)
    if not times:
        sys.exit('time 文件为空')
    fps = 1.0 / np.mean(times)
    print('序列数: %d, 统计帧数: %d' % (len(glob.glob(os.path.join(got10k_dir, '*_time.txt'))), len(times)))
    print('平均每帧耗时: %.3f ms, FPS: %.2f' % (np.mean(times) * 1e3, fps))
    return fps


def measure_fps(yaml_name, num_frames=200, warmup=10, seq_idx=0):
    """加载真实 checkpoint，用真实图像按 initialize+track 完整流程计时。"""
    from lib.test.evaluation.tracker import Tracker
    from lib.test.evaluation import get_dataset

    tracker = Tracker('avtrack', yaml_name, 'got10k_test')
    trk = tracker.create_tracker(tracker.get_parameters())

    dataset = get_dataset('got10k_test')
    seq = dataset[seq_idx]
    image = tracker._read_image(seq.frames[0])
    init_info = seq.init_info()

    # 初始化（不计时）
    trk.initialize(image, init_info)

    # warmup（不计时）
    for i in range(1, min(warmup + 1, len(seq.frames))):
        img = tracker._read_image(seq.frames[i])
        info = seq.frame_info(i)
        info['previous_output'] = {}
        trk.track(img, info)

    # 计时
    times = []
    for i in range(warmup + 1, min(warmup + 1 + num_frames, len(seq.frames))):
        img = tracker._read_image(seq.frames[i])
        info = seq.frame_info(i)
        info['previous_output'] = {}
        start = time.time()
        trk.track(img, info)
        torch.cuda.synchronize()
        times.append(time.time() - start)

    fps = len(times) / float(sum(times))
    print('序列: %s, 计时帧数: %d' % (seq.name, len(times)))
    print('平均每帧耗时: %.3f ms, FPS: %.2f' % (np.mean(times) * 1e3, fps))
    return fps


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('yaml_name', type=str)
    parser.add_argument('--fps', action='store_true', help='加载真实 checkpoint 跑 FPS')
    parser.add_argument('--from_time', action='store_true', help='从已有 *_time.txt 统计 FPS')
    args = parser.parse_args()

    count_params(args.yaml_name)

    if args.fps:
        print('\n===== FPS（实测） =====')
        measure_fps(args.yaml_name)
    if args.from_time:
        print('\n===== FPS（来自评测 time 文件） =====')
        fps_from_time_files(args.yaml_name)
