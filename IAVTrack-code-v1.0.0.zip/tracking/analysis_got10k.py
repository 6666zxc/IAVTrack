"""
GOT-10k 评估: AO / SR0.50 / SR0.75
结果在默认 tracking_results/ 的 got10k/ 子目录
"""
import _init_paths
import os
import torch
import numpy as np
from tqdm import tqdm

from lib.test.evaluation import get_dataset
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

RESULTS_DIR = r"E:\member\sth\IAVtrack-main\output\test\tracking_results"
PARAM_NAME = "ablation_stage2_msca_bddr_got10k_atc"
DS_NAME = "got10k_val"

dataset = get_dataset(DS_NAME)
n_seqs = len(dataset)
results_subdir = "got10k"  # GOT-10k 保存结果的子目录名

all_ao = []
all_sr50 = []
all_sr75 = []

missing = 0
for seq in tqdm(dataset, desc="GOT-10k"):
    results_path = os.path.join(RESULTS_DIR, "avtrack", PARAM_NAME, results_subdir, f"{seq.name}.txt")
    if not os.path.isfile(results_path):
        missing += 1
        continue

    pred_bb = torch.tensor(load_text(str(results_path), delimiter=('\t', ','), dtype=np.float64))
    anno_bb = torch.tensor(seq.ground_truth_rect)

    try:
        err_overlap, _, _, valid_frame = calc_seq_err_robust(pred_bb, anno_bb, seq.dataset, None)
    except Exception as e:
        print(f"  [ERR] {seq.name}: {e}")
        continue

    overlaps = err_overlap[valid_frame]
    if len(overlaps) == 0:
        continue

    ao = overlaps.mean().item()
    sr50 = (overlaps > 0.5).float().mean().item()
    sr75 = (overlaps > 0.75).float().mean().item()

    all_ao.append(ao)
    all_sr50.append(sr50)
    all_sr75.append(sr75)

n_eval = len(all_ao)
print(f"\n{'=' * 60}")
print(f"  GOT-10k Test  —  BDDR+MSCA+ATC")
print(f"  {n_eval}/{n_seqs} sequences evaluated  (missing={missing})")
print(f"{'=' * 60}")
print(f"  AO (Average Overlap):    {np.mean(all_ao)*100:.2f}")
print(f"  SR0.50 (IoU > 0.50):     {np.mean(all_sr50)*100:.2f}")
print(f"  SR0.75 (IoU > 0.75):     {np.mean(all_sr75)*100:.2f}")
print(f"{'=' * 60}")
