"""测试 MSCA 在 UAVDT, UAV123, UAV123_20l, DTB70 上"""
import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker

PARAM = "ablation_01_msca_hfda_v2"
LABEL = "MSCA"
DATASETS = ["uavdt", "uav123", "uav123_20l", "dtb70"]
TRACKER_NAME = "avtrack"

def main():
    results_root = os.path.join(
        os.path.dirname(__file__), "..", "output", "test", "tracking_results", TRACKER_NAME
    )
    results_root = os.path.abspath(results_root)

    for ds_name in DATASETS:
        print(f"\n{'='*50}")
        print(f"  {LABEL} @ {ds_name}")
        print(f"{'='*50}")

        dataset = get_dataset(ds_name)
        tracker = Tracker(TRACKER_NAME, PARAM, ds_name, run_id=None)
        tracker.results_dir = os.path.join(results_root, PARAM)
        os.makedirs(os.path.join(tracker.results_dir, ds_name), exist_ok=True)

        run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=1)
        print(f"完成: {LABEL} @ {ds_name}")

    print(f"\n全部完成 → {results_root}/{PARAM}")

if __name__ == "__main__":
    main()
