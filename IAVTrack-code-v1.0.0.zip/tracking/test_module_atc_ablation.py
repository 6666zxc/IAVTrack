"""
模块组合 + ATC 消融测试：baseline+ATC / BDDR+ATC / MSCA+ATC。

数据集：DTB70、UAVDT（用户指定）。
结果写入 output/test/tracking_results/avtrack/<config>/，供 eval_module_atc_ablation.py 读取。
"""
import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.evaluation.environment import env_settings

EXPERIMENTS = [
    ("ablation_baseline_atc", "Baseline + ATC"),
    ("ablation_bddr_atc",     "BDDR + ATC"),
    ("ablation_msca_atc",     "MSCA-HFDA + ATC"),
]

DATASETS = ["dtb70", "uavdt"]
TRACKER_NAME = "avtrack"
NUM_GPUS = 1


def main():
    env = env_settings()
    results_root = os.path.join(env.save_dir, "test", "tracking_results", TRACKER_NAME)

    total = len(EXPERIMENTS) * len(DATASETS)
    count = 0

    print("=" * 70)
    print(f"结果根目录: {results_root}")
    print(f"共 {len(EXPERIMENTS)} 个配置 × {len(DATASETS)} 个数据集 = {total} 次测试")
    print("=" * 70)

    for exp_idx, (param_name, exp_label) in enumerate(EXPERIMENTS, 1):
        for ds_idx, ds_name in enumerate(DATASETS, 1):
            count += 1
            print(f"\n{'=' * 70}")
            print(f"[{count}/{total}] {exp_label}  @  {ds_name}  ({param_name})")
            print(f"{'=' * 70}")

            dataset = get_dataset(ds_name)
            tracker = Tracker(TRACKER_NAME, param_name, ds_name, run_id=None)
            tracker.results_dir = os.path.join(results_root, param_name)
            os.makedirs(os.path.join(tracker.results_dir, ds_name), exist_ok=True)

            run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=NUM_GPUS)

            print(f"[{count}/{total}] 完成: {exp_label} @ {ds_name}")

    print(f"\n全部完成! 结果保存在: {results_root}")


if __name__ == "__main__":
    main()
