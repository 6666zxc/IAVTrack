#!/usr/bin/env python3
"""Generate paper-ready heatmaps for IAVTrack without modifying repo core code.

Two kinds of heatmap are produced and overlaid on the search-region crop:
  1. score map   —— classification response from the Center head (pred_score_map),
                    the standard "localization heatmap" in tracking papers.
  2. attention map —— template -> search attention weights from the ViT backbone,
                    i.e. how much the template tokens attend to each search token
                    (closest analogue to BACTrack Fig.7, single-template version).

Implementation is done by monkey-patching tracker methods / registering forward
hooks, so `lib/` stays untouched (test-time only).

Usage:
    python tracking/vis_heatmap.py --config ablation_stage2_msca_bddr_mixed \
        --seqs group2_1 --frames 50 150 300 500 \
        --uav123_root "E:/member/sth/IAVtrack-main/data/UAV123" \
        --out_root "E:/member/sth/IAVtrack-main/output/heatmaps" \
        --mode both
"""
import argparse
import importlib
import os
import re
import subprocess
import sys

_prj = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _prj not in sys.path:
    sys.path.insert(0, _prj)

import cv2
import numpy as np
import torch

try:
    from PIL import Image, ImageDraw, ImageFont
    _HAS_PIL = True
except Exception:
    _HAS_PIL = False

# 中文字体候选（Windows 自带），按优先级取第一个存在的
_FONT_CANDIDATES = [
    r'C:\Windows\Fonts\msyh.ttc',      # 微软雅黑
    r'C:\Windows\Fonts\simhei.ttf',    # 黑体
    r'C:\Windows\Fonts\Deng.ttf',      # 等线
]
_FONT_CACHE = {}

# seq -> (image dir, startFrame, endFrame, anno file)  (same as uav123dataset.py)
SEQS = {
    'group2_1': ('data_seq/UAV123/group2', 1, 907, 'anno/UAV123/group2_1.txt'),
    'car14': ('data_seq/UAV123/car14', 1, 1327, 'anno/UAV123/car14.txt'),
    'person18': ('data_seq/UAV123/person18', 1, 1393, 'anno/UAV123/person18.txt'),
}


def _patch_wsl_paths():
    """local.py 写死为 WSL 路径(/mnt/e/...)，在 Windows 下运行时映射为 E:/...（不改仓库文件）。"""
    import lib.test.evaluation.local as local_mod
    orig = local_mod.local_env_settings

    def win_settings():
        s = orig()
        for attr in dir(s):
            if attr.startswith('_'):
                continue
            v = getattr(s, attr)
            if isinstance(v, str) and v.startswith('/mnt/'):
                parts = v.split('/')
                if len(parts) >= 4 and len(parts[2]) == 1:
                    setattr(s, attr, parts[2].upper() + ':/' + '/'.join(parts[3:]))
        return s

    local_mod.local_env_settings = win_settings


def load_gt(path):
    boxes = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = re.split(r'[\s,]+', line)
            if len(parts) < 4:
                continue
            boxes.append([float(p) for p in parts[:4]])
    return np.array(boxes, dtype=np.float64)


def heatmap_overlay(image_rgb, heat2d, alpha=0.55, cmap=cv2.COLORMAP_JET):
    """Overlay a single-channel heatmap on an RGB image. Returns a BGR image."""
    h, w = image_rgb.shape[:2]
    heat = cv2.resize(heat2d.astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC)
    vmin, vmax = float(heat.min()), float(heat.max())
    if vmax - vmin < 1e-8:
        heat_n = np.zeros_like(heat)
    else:
        heat_n = (heat - vmin) / (vmax - vmin)
    heat_u8 = (heat_n * 255).astype(np.uint8)
    heat_bgr = cv2.applyColorMap(heat_u8, cmap)
    img_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    return cv2.addWeighted(img_bgr, 1.0 - alpha, heat_bgr, alpha, 0.0)


def draw_box_bgr(img_bgr, box_cxcywh_norm, color=(0, 0, 255), thickness=2):
    """box_cxcywh_norm: (cx, cy, w, h) normalized to [0, 1] relative to the crop."""
    h, w = img_bgr.shape[:2]
    cx, cy, bw, bh = box_cxcywh_norm
    x1 = int((cx - bw / 2.0) * w)
    y1 = int((cy - bh / 2.0) * h)
    x2 = int((cx + bw / 2.0) * w)
    y2 = int((cy + bh / 2.0) * h)
    cv2.rectangle(img_bgr, (x1, y1), (x2, y2), color, thickness)
    return img_bgr


def _gt_box_in_crop(gt_box, pre_state, resize_factor, search_size):
    """把整帧 GT [x,y,w,h] 映射为 search crop 内归一化 (cx,cy,w,h)。

    几何与 lib/test/tracker/avtrack.py::map_box_back 互逆：
    crop 中心 = 裁剪时 state 的中心（pre_state），crop 边长 = search_size / resize_factor。
    """
    gx, gy, gw, gh = gt_box
    cx_prev = pre_state[0] + 0.5 * pre_state[2]
    cy_prev = pre_state[1] + 0.5 * pre_state[3]
    half_side = 0.5 * search_size / resize_factor
    gcx = gx + 0.5 * gw
    gcy = gy + 0.5 * gh
    cx_norm = ((gcx - cx_prev + half_side) * resize_factor) / search_size
    cy_norm = ((gcy - cy_prev + half_side) * resize_factor) / search_size
    w_norm = (gw * resize_factor) / search_size
    h_norm = (gh * resize_factor) / search_size
    return np.array([cx_norm, cy_norm, w_norm, h_norm], dtype=np.float64)


def _box_in_view(box_norm, margin=0.0):
    """判断归一化框 (cx,cy,w,h) 是否在裁剪视野内（允许 margin 比例越界仍算可见）。"""
    cx, cy, w, h = box_norm
    return (cx + w / 2.0 > -margin and cx - w / 2.0 < 1.0 + margin and
            cy + h / 2.0 > -margin and cy - h / 2.0 < 1.0 + margin)


def _load_cn_font(size):
    """加载中文字体（带缓存），失败返回 None。"""
    if size in _FONT_CACHE:
        return _FONT_CACHE[size]
    if _HAS_PIL:
        for fp in _FONT_CANDIDATES:
            if os.path.exists(fp):
                try:
                    font = ImageFont.truetype(fp, size)
                    _FONT_CACHE[size] = font
                    return font
                except Exception:
                    continue
    _FONT_CACHE[size] = None
    return None


def add_title_bar(img_bgr, title, bar_h=None, bar_color=(255, 255, 255), text_color=(0, 0, 0)):
    """在 BGR 图顶部加一条白底标题栏（支持中英文）。返回新的 BGR 图。"""
    h, w = img_bgr.shape[:2]
    if bar_h is None:
        bar_h = max(30, int(round(h * 0.07)))
    font_size = max(14, int(bar_h * 0.55))

    if _HAS_PIL:
        bar_rgb = np.full((bar_h, w, 3), 255, dtype=np.uint8)
        pil = Image.fromarray(bar_rgb)
        draw = ImageDraw.Draw(pil)
        font = _load_cn_font(font_size)
        if font is not None:
            bbox = draw.textbbox((0, 0), title, font=font)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            x = (w - tw) // 2 - bbox[0]
            y = (bar_h - th) // 2 - bbox[1]
            draw.text((x, y), title, font=font, fill=text_color)
            bar_bgr = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)
        else:
            bar_bgr = np.full((bar_h, w, 3), bar_color, dtype=np.uint8)
    else:
        # 无 PIL 时回退：只画英文（cv2 不支持中文）
        bar_bgr = np.full((bar_h, w, 3), bar_color, dtype=np.uint8)
        cv2.putText(bar_bgr, title, (10, bar_h // 2 + font_size // 3),
                    cv2.FONT_HERSHEY_SIMPLEX, font_size / 30.0, text_color, 1, cv2.LINE_AA)

    return np.vstack([bar_bgr, img_bgr])


def _attention_hook(module):
    """Return a forward hook that re-computes and caches attention weights.

    The stock Attention uses F.scaled_dot_product_attention (fused) and does not
    expose weights, so we recompute them from q/k without touching the forward pass.
    """
    def hook(m, inputs, output):
        x = inputs[0]  # norm1(x), [B, N, C]
        with torch.no_grad():
            B, N, C = x.shape
            qkv = m.qkv(x).reshape(B, N, 3, m.num_heads, m.head_dim).permute(2, 0, 3, 1, 4)
            q, k, _ = qkv.unbind(0)
            q, k = m.q_norm(q), m.k_norm(k)
            q = q * m.scale
            attn = q @ k.transpose(-2, -1)
            attn = attn.softmax(dim=-1)
            m._last_attn = attn.detach().cpu()
    return hook


def register_attention_hooks(backbone, layer='last'):
    """Register attention hooks. Returns (handles, layer_indices)."""
    n = len(backbone.blocks)
    indices = [n - 1] if layer == 'last' else list(range(n))
    handles = []
    for i in indices:
        attn = backbone.blocks[i].attn
        attn._last_attn = None
        handles.append(attn.register_forward_hook(_attention_hook(attn)))
    return handles, indices


def attention_map(backbone, indices, lens_z, feat_sz):
    """Average template->search attention over heads/templates/layers -> (feat_sz, feat_sz)."""
    maps = []
    for i in indices:
        attn = backbone.blocks[i].attn._last_attn
        if attn is None:
            continue
        t2s = attn[0, :, :lens_z, lens_z:]          # [num_heads, lens_z, lens_x]
        m = t2s.mean(dim=0).mean(dim=0)             # [lens_x]
        maps.append(m.reshape(feat_sz, feat_sz).numpy())
    if not maps:
        return np.zeros((feat_sz, feat_sz), dtype=np.float32)
    return np.mean(np.stack(maps), axis=0)


def _build_tracker(cfg_name):
    """构建一个 tracker 实例并做 monkey-patch。返回 (tracker, captured, backbone, lens_z, feat_sz)。"""
    _patch_wsl_paths()
    param_module = importlib.import_module('lib.test.parameter.avtrack')
    params = param_module.parameters(cfg_name)
    params.debug = 0
    params.save_all_boxes = False

    tracker_module = importlib.import_module('lib.test.tracker.avtrack')
    tracker = tracker_module.get_tracker_class()(params, 'uav123')

    backbone = tracker.network.backbone
    lens_z = int(backbone.pos_embed_z.shape[1])
    feat_sz = tracker.feat_sz

    captured = {}
    orig_return = tracker._track_return

    def wrapped_return(out_dict, pred_score_map, pred_boxes, x_patch_arr, image, info, resize_factor):
        captured['score_map'] = pred_score_map.detach().cpu().squeeze().numpy()
        captured['pred_boxes'] = pred_boxes.detach().cpu()
        captured['x_patch'] = x_patch_arr
        captured['resize_factor'] = float(resize_factor)
        return orig_return(out_dict, pred_score_map, pred_boxes, x_patch_arr, image, info, resize_factor)

    tracker._track_return = wrapped_return

    # 记录每次 track() 裁剪搜索区域时的 state（用于把整帧 GT 框映射到 search crop）
    orig_track = tracker.track

    def wrapped_track(image, info=None):
        captured['_pre_state'] = [float(x) for x in tracker.state]
        return orig_track(image, info)

    tracker.track = wrapped_track

    return tracker, captured, backbone, lens_z, feat_sz


def _run_to_frame(tracker, captured, frames, gt, target_idx, mode, attn_layer):
    """从 tracker 当前状态继续推进到 target_idx（含），返回该帧的可视化素材 dict。

    tracker 内部用 captured['_next_frame'] 记录下一帧要处理的图像索引；
    首次调用时从 0 开始 initialize。同一 tracker 多次调用时，target_idx 必须单调递增。
    """
    backbone = tracker.network.backbone
    lens_z = int(backbone.pos_embed_z.shape[1])
    feat_sz = tracker.feat_sz

    handles, attn_indices = ([], [])
    if mode in ('attn', 'both'):
        handles, attn_indices = register_attention_hooks(backbone, attn_layer)

    start_i = captured.get('_next_frame', 0)
    try:
        for i in range(start_i, target_idx + 1):
            image = cv2.cvtColor(cv2.imread(frames[i]), cv2.COLOR_BGR2RGB)
            if i == 0:
                tracker.initialize(image, {'init_bbox': gt[0]})
                captured['_next_frame'] = 1
                continue
            tracker.track(image, None)
            captured['_next_frame'] = i + 1
            if i != target_idx:
                continue

            img_rgb = captured['x_patch']
            pred_box = captured['pred_boxes'].mean(dim=0).numpy()
            res = {
                'search_rgb': img_rgb,
                'pred_box': pred_box,
                'score_map': captured['score_map'] if mode in ('score', 'both') else None,
                'attn_map': attention_map(backbone, attn_indices, lens_z, feat_sz) if mode in ('attn', 'both') else None,
                'resize_factor': captured.get('resize_factor'),
                'pre_state': captured.get('_pre_state'),
            }
            return res
        raise RuntimeError('target frame %d not reached (start_i=%d)' % (target_idx, start_i))
    finally:
        for h in handles:
            h.remove()


def add_bottom_label(img_bgr, label, bar_h=None, bar_color=(255, 255, 255), text_color=(0, 0, 0)):
    """在 BGR 图底部加一条白底标签栏（中英文）。返回新的 BGR 图。"""
    h, w = img_bgr.shape[:2]
    if bar_h is None:
        bar_h = max(28, int(round(h * 0.08)))
    font_size = max(14, int(bar_h * 0.55))
    bar_bgr = np.full((bar_h, w, 3), bar_color, dtype=np.uint8)

    if _HAS_PIL:
        pil = Image.fromarray(cv2.cvtColor(bar_bgr, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil)
        font = _load_cn_font(font_size)
        if font is not None:
            bbox = draw.textbbox((0, 0), label, font=font)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            x = (w - tw) // 2 - bbox[0]
            y = (bar_h - th) // 2 - bbox[1]
            draw.text((x, y), label, font=font, fill=text_color)
            bar_bgr = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)

    return np.vstack([img_bgr, bar_bgr])


def _gap(w, h, gap_px=6, color=(255, 255, 255)):
    return np.full((h, gap_px, 3), color, dtype=np.uint8)


def _run_external_dump(proj, seq_name, frames_list, work_dir, uav123_root):
    """Run ext_dump.py in a subprocess for one external project. Returns work_dir."""
    os.makedirs(work_dir, exist_ok=True)
    py = sys.executable
    script = os.path.join(_prj, 'tracking', 'ext_dump.py')
    cmd = [py, script, '--proj', proj, '--seq', seq_name,
           '--frames'] + [str(f) for f in frames_list] + [
           '--out_dir', work_dir, '--uav123_root', uav123_root]
    print('[ext] run: %s' % ' '.join(cmd), flush=True)
    subprocess.run(cmd, check=True)
    return work_dir


def _load_ext_heat(proj, frame_idx, work_dir, heat):
    """Load one frame's search crop + score map dumped by ext_dump.py.
    Returns (search_rgb, heat2d) or (search_rgb, None) if score missing."""
    search_fp = os.path.join(work_dir, '%s_f%06d_search.npy' % (proj, frame_idx))
    score_fp = os.path.join(work_dir, '%s_f%06d_score.npy' % (proj, frame_idx))
    search_rgb = np.load(search_fp)
    if os.path.exists(score_fp):
        return search_rgb, np.load(score_fp)
    return search_rgb, None


def _make_compare_row(seq_name, t_idx, methods, root, ext_work, iav_trackers, heat, attn_layer):
    """生成单个 (seq, frame) 的一行横向对比图（BGR numpy）。"""
    img_sub, start, end, anno_sub = SEQS[seq_name]
    frames = [os.path.join(root, img_sub, '%06d.jpg' % f) for f in range(start, end + 1)]
    gt = load_gt(os.path.join(root, anno_sub))

    # 所有 IAV 方法在该帧只跑一次
    iav_results = {}
    for kind, arg, label in methods:
        if kind != 'iav':
            continue
        trk, cap = iav_trackers[label]
        iav_results[label] = _run_to_frame(trk, cap, frames, gt, t_idx, heat, attn_layer)

    # 第 1 列：Search Region（用 Ours 实际裁剪的搜索区域，底图与最右列 Ours 完全一致；叠加 GT 红框）
    iav_first = next(((k, a, l) for k, a, l in methods if k == 'iav'), None)
    if iav_first is not None:
        _, _, i_label = iav_first
        r0 = iav_results[i_label]
        trk0 = iav_trackers[i_label][0]
        search_size = trk0.params.search_size
        search_bgr = cv2.cvtColor(r0['search_rgb'], cv2.COLOR_RGB2BGR)
        if r0['pre_state'] is not None and r0['resize_factor'] is not None:
            gt_box = gt[t_idx]
            if not np.any(np.isnan(gt_box)):
                gt_norm = _gt_box_in_crop(gt_box, r0['pre_state'], r0['resize_factor'], search_size)
                if _box_in_view(gt_norm, margin=0.1):
                    search_bgr = draw_box_bgr(search_bgr, gt_norm, color=(0, 0, 255), thickness=2)
    else:
        first_kind, first_arg, first_label = methods[0]
        search_rgb0, _ = _load_ext_heat(first_kind, t_idx, ext_work, heat)
        search_bgr = cv2.cvtColor(search_rgb0, cv2.COLOR_RGB2BGR)
    cols = [add_bottom_label(search_bgr, 'Search Region')]

    # 后续每一列：按 methods 顺序画热力图
    for kind, arg, label in methods:
        if kind == 'iav':
            r = iav_results[label]
            m = r['score_map'] if heat == 'score' else r['attn_map']
            ov = heatmap_overlay(r['search_rgb'], m)
        else:
            search_rgb_e, sm = _load_ext_heat(kind, t_idx, ext_work, heat)
            if sm is None:
                ov = cv2.cvtColor(search_rgb_e, cv2.COLOR_RGB2BGR)
            else:
                ov = heatmap_overlay(search_rgb_e, sm)
        cols.append(add_bottom_label(ov, label))

    row = cols[0]
    for c in cols[1:]:
        row = np.hstack([row, _gap(0, row.shape[0], 6), c])
    return row


def _build_iav_trackers(methods):
    """构建所有 IAVTrack 内部方法的 tracker（各自独立状态）。"""
    iav_trackers = {}
    for kind, arg, label in methods:
        if kind == 'iav':
            trk, cap, bb, lz, fs = _build_tracker(arg)
            iav_trackers[label] = (trk, cap)
    return iav_trackers


def _dump_ext_for_seq(seq_name, methods, target_frames, ext_work, root):
    """把该序列所有外部方法的目标帧 dump 出来（每个项目独立子进程）。"""
    for kind, arg, label in methods:
        if kind != 'iav':
            _run_external_dump(kind, seq_name, sorted(target_frames), ext_work, root)


def run_compare_mixed(seq_name, methods, root, out_root, target_frames, heat, attn_layer):
    """跨方法横向对比：methods 是 (kind, arg, label) 三元组，kind ∈ iav/sglatrack/litetrack/smat。

    每个目标帧输出一张横向拼图：Search | <外部方法...> | Ours。
    """
    cmp_dir = os.path.join(out_root, 'compare_ext')
    os.makedirs(cmp_dir, exist_ok=True)
    ext_work = os.path.join(out_root, '_ext', seq_name)

    _dump_ext_for_seq(seq_name, methods, target_frames, ext_work, root)
    iav_trackers = _build_iav_trackers(methods)

    for t_idx in sorted(target_frames):
        row = _make_compare_row(seq_name, t_idx, methods, root, ext_work, iav_trackers, heat, attn_layer)
        out_fp = os.path.join(cmp_dir, '%s_f%06d_%s.png' % (seq_name, t_idx, heat))
        cv2.imwrite(out_fp, row)
        print('[compare_ext] saved %s' % out_fp, flush=True)


def run_compare_panel(seq_frames, methods, root, out_root, heat, attn_layer):
    """多序列多行合成一张图：seq_frames = [(seq_name, frame_idx), ...]。

    每个 (seq, frame) 生成一行（横向对比），最后纵向拼接成一张 3 行 × N 列的大图。
    """
    cmp_dir = os.path.join(out_root, 'compare_ext')
    os.makedirs(cmp_dir, exist_ok=True)

    rows = []
    for seq_name, t_idx in seq_frames:
        ext_work = os.path.join(out_root, '_ext', seq_name)
        _dump_ext_for_seq(seq_name, methods, [t_idx], ext_work, root)
        iav_trackers = _build_iav_trackers(methods)
        row = _make_compare_row(seq_name, t_idx, methods, root, ext_work, iav_trackers, heat, attn_layer)
        rows.append(row)

    # 统一宽度（列数相同应一致；保险起见 pad 到最宽）
    max_w = max(r.shape[1] for r in rows)
    rows = [r if r.shape[1] == max_w else np.hstack(
        [r, np.full((r.shape[0], max_w - r.shape[1], 3), 255, dtype=np.uint8)]) for r in rows]

    gap_h = 6
    out = rows[0]
    for r in rows[1:]:
        gap = np.full((gap_h, max_w, 3), 255, dtype=np.uint8)
        out = np.vstack([out, gap, r])

    out_fp = os.path.join(cmp_dir, 'combined_%s.png' % heat)
    cv2.imwrite(out_fp, out)
    print('[compare_ext] combined saved %s' % out_fp, flush=True)
    return out_fp


def run_compare(seq_name, methods, root, out_root, target_frames, heat, attn_layer):
    """多方法横向对比：每个目标帧输出一张 N 列横向拼图（Search | method1 | method2 ...），列底加方法名。"""
    img_sub, start, end, anno_sub = SEQS[seq_name]
    frames = [os.path.join(root, img_sub, '%06d.jpg' % f) for f in range(start, end + 1)]
    gt = load_gt(os.path.join(root, anno_sub))

    cmp_dir = os.path.join(out_root, 'compare')
    os.makedirs(cmp_dir, exist_ok=True)

    # 为每个方法构建一个 tracker（各自独立维护模板/状态，互不影响）
    trackers = []
    for cfg_name, label in methods:
        trk, cap, bb, lz, fs = _build_tracker(cfg_name)
        trackers.append({'cfg': cfg_name, 'label': label, 'trk': trk, 'cap': cap})

    for t_idx in sorted(target_frames):
        cols = []

        # 第 1 列：Search Region（用第一个方法跑一遍拿搜索裁剪图 + 该方法预测框）
        first = trackers[0]
        r0 = _run_to_frame(first['trk'], first['cap'], frames, gt, t_idx, 'score', attn_layer)
        search_bgr = draw_box_bgr(cv2.cvtColor(r0['search_rgb'], cv2.COLOR_RGB2BGR), r0['pred_box'])
        cols.append(add_bottom_label(search_bgr, 'Search Region'))

        # 后续每一列：该方法的热力图
        for m in trackers:
            r = _run_to_frame(m['trk'], m['cap'], frames, gt, t_idx, heat, attn_layer)
            if heat == 'score':
                ov = heatmap_overlay(r['search_rgb'], r['score_map'])
            elif heat == 'attn':
                ov = heatmap_overlay(r['search_rgb'], r['attn_map'])
            else:
                ov = heatmap_overlay(r['search_rgb'], r['score_map'])
            cols.append(add_bottom_label(ov, m['label']))

        # 横向拼接，列间留 6px 白缝
        row = cols[0]
        for c in cols[1:]:
            row = np.hstack([row, _gap(0, row.shape[0], 6), c])

        out_fp = os.path.join(cmp_dir, '%s_f%06d_%s.png' % (seq_name, t_idx, heat))
        cv2.imwrite(out_fp, row)
        print('[compare] saved %s' % out_fp, flush=True)


def run_sequence(seq_name, cfg_name, root, out_root, target_frames, mode, attn_layer):
    img_sub, start, end, anno_sub = SEQS[seq_name]
    frames = [os.path.join(root, img_sub, '%06d.jpg' % f) for f in range(start, end + 1)]
    gt = load_gt(os.path.join(root, anno_sub))

    _patch_wsl_paths()

    param_module = importlib.import_module('lib.test.parameter.avtrack')
    params = param_module.parameters(cfg_name)
    params.debug = 0
    params.save_all_boxes = False

    tracker_module = importlib.import_module('lib.test.tracker.avtrack')
    tracker = tracker_module.get_tracker_class()(params, 'uav123')

    backbone = tracker.network.backbone
    lens_z = int(backbone.pos_embed_z.shape[1])
    feat_sz = tracker.feat_sz
    search_size = tracker.params.search_size

    handles, attn_indices = ([], [])
    if mode in ('attn', 'both'):
        handles, attn_indices = register_attention_hooks(backbone, attn_layer)

    seq_out = os.path.join(out_root, seq_name)
    os.makedirs(seq_out, exist_ok=True)

    captured = {}
    orig_return = tracker._track_return

    def wrapped_return(out_dict, pred_score_map, pred_boxes, x_patch_arr, image, info, resize_factor):
        captured['score_map'] = pred_score_map.detach().cpu().squeeze().numpy()
        captured['pred_boxes'] = pred_boxes.detach().cpu()
        captured['x_patch'] = x_patch_arr
        return orig_return(out_dict, pred_score_map, pred_boxes, x_patch_arr, image, info, resize_factor)

    tracker._track_return = wrapped_return

    try:
        for i, fp in enumerate(frames):
            image = cv2.cvtColor(cv2.imread(fp), cv2.COLOR_BGR2RGB)
            if i == 0:
                tracker.initialize(image, {'init_bbox': gt[0]})
                continue
            tracker.track(image, None)
            if i not in target_frames:
                continue

            img_rgb = captured['x_patch']
            pred_box = captured['pred_boxes'].mean(dim=0).numpy()  # (cx,cy,w,h) in [0,1]

            search_bgr = draw_box_bgr(cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR), pred_box)
            cv2.imwrite(os.path.join(seq_out, 'f%06d_search.png' % i), search_bgr)

            # 论文 panel：search 在上、热力图在下，纵向堆叠，并给每张加中英文标题
            panel_parts = [add_title_bar(search_bgr, 'Search + Pred Box / 搜索区域与预测框')]

            if mode in ('score', 'both'):
                sm = captured['score_map']
                ov = heatmap_overlay(img_rgb, sm)
                cv2.imwrite(os.path.join(seq_out, 'f%06d_score.png' % i), ov)
                panel_parts.append(add_title_bar(ov, 'Score Map / 响应热力图'))

            if mode in ('attn', 'both'):
                am = attention_map(backbone, attn_indices, lens_z, feat_sz)
                ov = heatmap_overlay(img_rgb, am)
                cv2.imwrite(os.path.join(seq_out, 'f%06d_attn.png' % i), ov)
                panel_parts.append(add_title_bar(ov, 'Attention Map / 注意力热力图'))

            cv2.imwrite(os.path.join(seq_out, 'f%06d_panel.png' % i), np.vstack(panel_parts))

            if (i + 1) % 200 == 0:
                print('[%s] %d/%d' % (seq_name, i + 1, len(frames)), flush=True)
    finally:
        for h in handles:
            h.remove()

    print('[%s] DONE  saved frames: %s' % (seq_name, sorted(target_frames)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--config', default='ablation_stage2_msca_bddr_mixed')
    p.add_argument('--seqs', nargs='+', default=['group2_1'])
    p.add_argument('--frames', nargs='+', type=int, default=None,
                   help='Explicit frame indices (image-file index, >=1). If omitted, sample --num_frames evenly.')
    p.add_argument('--num_frames', type=int, default=4)
    p.add_argument('--mode', default='both', choices=['score', 'attn', 'both'])
    p.add_argument('--attn_layer', default='last', choices=['last', 'mean'])
    p.add_argument('--uav123_root', default='E:/member/sth/IAVtrack-main/data/UAV123')
    p.add_argument('--out_root', default='E:/member/sth/IAVtrack-main/output/heatmaps')

    # ---- 多方法横向对比（论文 Fig.2 风格）----
    p.add_argument('--compare', action='store_true',
                   help='Enable multi-method horizontal comparison panel (IAVTrack ablation only).')
    p.add_argument('--compare_ext', action='store_true',
                   help='Cross-method comparison: mix IAVTrack with external projects (SGLATrack/LiteTrack/SMAT).')
    p.add_argument('--heat', default='score', choices=['score', 'attn'],
                   help='Which heatmap to show for each method column (compare mode).')
    p.add_argument('--seq_frames', nargs='+', default=None,
                   help='"seq:frame" pairs for --compare_ext panel mode, one row each, '
                        'e.g. group2_1:100 car14:200 person18:150. Produces a single combined image.')
    p.add_argument('--methods', nargs='+',
                   default=None,
                   help='Comparison columns. For --compare: "cfg:Label". For --compare_ext: "kind:arg:Label" '
                        'with kind in {iav,sglatrack,litetrack,smat}; arg = yaml name for iav, "-" for others.')
    args = p.parse_args()

    def _targets(s):
        if args.frames:
            return set(args.frames)
        _, start, end, _ = SEQS[s]
        n_img = end - start + 1
        t = set(int(round(start - 1 + (n_img - 1) * k / (args.num_frames - 1)))
                for k in range(args.num_frames)) if args.num_frames > 1 else {n_img - 1}
        t.discard(0)
        return t

    # 默认对比列：Search | SGLATrack | LiteTrack | SMAT | Ours
    if args.compare_ext and args.methods is None:
        args.methods = [
            'sglatrack:-:SGLATrack',
            'litetrack:-:LiteTrack',
            'smat:-:SMAT',
            'iav:ablation_stage2_msca_bddr_mixed:Ours',
        ]
    elif args.compare and args.methods is None:
        args.methods = [
            'deit_tiny_patch16_224_30ep_baseline:Baseline',
            'ablation_01_msca_hfda_v2:+MSCA',
            'ablation_stage2_msca_bddr_mixed:Ours',
        ]

    def _parse_ext_methods():
        methods = []
        for item in args.methods:
            parts = item.split(':')
            if len(parts) == 3:
                methods.append((parts[0], parts[1], parts[2]))
            else:
                raise ValueError('compare_ext method must be kind:arg:Label, got %s' % item)
        return methods

    if args.compare_ext:
        methods = _parse_ext_methods()
        if args.seq_frames:
            # 多序列多行合成一张大图（用户给的是图像文件名编号，内部是 0-based index）
            seq_frames = []
            for sf in args.seq_frames:
                s, f = sf.rsplit(':', 1)
                start = SEQS[s][1]
                t_idx = int(f) - start
                seq_frames.append((s, t_idx))
            run_compare_panel(seq_frames, methods, args.uav123_root, args.out_root, args.heat, args.attn_layer)
        else:
            for s in args.seqs:
                target = _targets(s)
                run_compare_mixed(s, methods, args.uav123_root, args.out_root, target, args.heat, args.attn_layer)
    elif args.compare:
        methods = []
        for item in args.methods:
            cfg_name, label = item.split(':', 1)
            methods.append((cfg_name, label))
        for s in args.seqs:
            target = _targets(s)
            run_compare(s, methods, args.uav123_root, args.out_root, target, args.heat, args.attn_layer)
    else:
        for s in args.seqs:
            target = _targets(s)
            run_sequence(s, args.config, args.uav123_root, args.out_root, target, args.mode, args.attn_layer)


if __name__ == '__main__':
    main()
