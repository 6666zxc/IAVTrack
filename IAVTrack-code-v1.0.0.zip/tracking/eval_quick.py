"""Evaluate with standard AUC (trapezoidal integration over overlap thresholds).

对缺失的追踪结果做容错：某个配置还没跑（.txt 不存在）时跳过该序列，
最后显示 N/A，不会中断整个评估。
"""
import _init_paths
import os
import numpy as np
import torch
from tqdm import tqdm
from lib.test.evaluation import get_dataset, trackerlist
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

TRACKER_CONFIGS = [
    ('deit_tiny_patch16_224_30ep_baseline', 'Baseline'),
    ('ablation_02_bddr_v2', 'BDDR'),
    ('ablation_01_msca_only', 'MSCA-only'),
    ('ablation_01_hfda_only', 'HFDA-only'),
    ('ablation_01_msca_hfda_v2', 'MSCA+HFDA'),
    ('ablation_stage2_msca_bddr_mixed_v2', 'BDDR+MSCA+HFDA'),
    ('ablation_stage2_msca_bddr_mixed_v2_nofreeze', 'BDDR+MSCA+HFDA (nofreeze)'),
    ('ablation_bddr_atc', 'BDDR+ATC'),
    ('ablation_01_msca_only_atc', 'BDDR+MSCA+ATC'),
    ('ablation_01_hfda_only_atc', 'BDDR+HFDA+ATC'),
    ('ablation_stage2_msca_bddr_mixed_v2_atc', 'BDDR+MSCA+HFDA+ATC'),
    ('ablation_atc_anchored', 'ATC-anchored'),
    ('ablation_atc_full', 'ATC-full'),
    # ---- BDDR 组件消融 ----
    ('ablation_02_bddr_wo_neg', 'BDDR w/o Neg'),
    ('ablation_02_bddr_wo_debias', 'BDDR w/o Debias'),
    ('ablation_02_bddr_bcr', 'BDDR w/ BCR'),
    # ---- 模板更新策略消融 (BACTrack Table V) ----
    ('ablation_upd_none', 'Upd: None'),
    ('ablation_upd_interval', 'Upd: Fixed-10'),
    ('ablation_upd_thresh', 'Upd: Thresh0.5'),
    ('ablation_upd_always', 'Upd: Always'),
]

DATASETS = ['uavdt', 'dtb70']

# Standard 21 overlap thresholds: 0.0, 0.05, ..., 1.0
THRESHOLDS = torch.arange(0.0, 1.01, 0.05, dtype=torch.float64)

for ds_name in DATASETS:
    dataset = get_dataset(ds_name)
    results = {}

    for cfg_name, display in TRACKER_CONFIGS:
        trackers = trackerlist('avtrack', cfg_name, ds_name, None, display)
        trk = trackers[0]

        all_success_curves = []
        all_prec = []
        missing = 0

        for seq in tqdm(dataset, desc=f"{ds_name}/{display}", leave=False):
            results_path = '{}/{}/{}.txt'.format(trk.results_dir, ds_name, seq.name)
            if not os.path.isfile(results_path):
                missing += 1
                continue

            anno_bb = torch.tensor(seq.ground_truth_rect)
            pred_bb = torch.tensor(load_text(results_path, delimiter=('\t', ','), dtype=np.float64))

            err_overlap, err_center, _, valid = calc_seq_err_robust(
                pred_bb, anno_bb, seq.dataset, None)

            valid_overlap = err_overlap[valid]
            valid_center = err_center[valid]
            seq_len = anno_bb.shape[0]

            if seq_len > 0:
                success = (valid_overlap.view(-1, 1) > THRESHOLDS.view(1, -1)).sum(0).float() / seq_len
                all_success_curves.append(success)
                prec = (valid_center <= 20).float().mean().item()
                all_prec.append(prec)

        if missing > 0:
            print(f"  [{display}] missing {missing}/{len(dataset)} sequences")

        if all_success_curves:
            curves = torch.stack(all_success_curves)
            mean_curve = curves.mean(dim=0)
            auc = torch.trapz(mean_curve, THRESHOLDS).item()
            avg_prec = np.mean(all_prec)
            results[display] = (auc, avg_prec)
        else:
            results[display] = None

    # Print results table
    print(f"\n{'='*70}")
    print(f"  {ds_name}")
    print(f"{'='*70}")
    print(f"{'Tracker':<20} {'AUC':>10} {'Prec@20':>10}")
    print(f"{'-'*42}")

    for _, display in TRACKER_CONFIGS:
        r = results[display]
        if r is not None:
            print(f"{display:<20} {r[0]:>10.4f} {r[1]:>10.4f}")
        else:
            print(f"{display:<20} {'N/A':>10} {'N/A':>10}")

    # Deltas vs Baseline (only when baseline results exist)
    if results.get('Baseline') is not None:
        b_auc = results['Baseline'][0]
        print(f"{'vs Baseline':<20} {'':>10}", end="")
        for _, display in TRACKER_CONFIGS[1:]:
            r = results[display]
            d = (r[0] - b_auc) if r is not None else float('nan')
            print(f" {display} {d:+.4f}", end="")
        print()
    print(f"{'='*70}")
