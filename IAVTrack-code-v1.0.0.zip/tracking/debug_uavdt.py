"""Check which UAVDT sequences are being loaded and their frame/GT counts."""
import _init_paths
from lib.test.evaluation import get_dataset

dataset = get_dataset('uavdt')
print(f"Total sequences in dataset: {len(dataset)}")
print()

for seq in dataset:
    n_frames = len(seq.frames)
    n_valid = 0
    if seq.target_visible is not None:
        n_valid = seq.target_visible.sum()
    print(f"{seq.name:6s}  frames={n_frames:4d}  valid_gt={n_valid:4d}")

# Check which sequences are missing
all_seqs = set()
import os
seq_dir = r'E:\member\sth\IAVtrack-main\data\UAVDT\sequences'
for d in os.listdir(seq_dir):
    if os.path.isdir(os.path.join(seq_dir, d)):
        all_seqs.add(d)

loaded_seqs = {s.name for s in dataset}
missing = all_seqs - loaded_seqs
if missing:
    print(f"\nMissing sequences ({len(missing)}): {sorted(missing)}")
else:
    print("\nAll 50 sequences loaded.")
