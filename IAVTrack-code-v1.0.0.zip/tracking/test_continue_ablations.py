"""
补充测试：只跑 BDDR(冻结)+MSCA 和 BDDR+MSCA+ATC
在 UAVDT, UAV123, DTB70 上按顺序执行。
结果追加到已有的 tracking_results_20260720_145826 文件夹。
"""
import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker

EXPERIMENTS = [
    ("ablation_stage2_msca_bddr_mixed",     "BDDR(冻结)+MSCA"),
    ("ablation_stage2_msca_bddr_mixed_atc", "BDDR+MSCA+ATC"),
]

DATASETS = ["uavdt", "uav123", "dtb70"]
TRACKER_NAME = "avtrack"

# 指向已有的时间戳结果目录
RESULTS_BASE = r"E:\member\sth\IAVtrack-main\output\test\tracking_results_20260720_145826"


if __name__ == "__main__":
    total = len(EXPERIMENTS) * len(DATASETS)
    count = 0

    for exp_idx, (param_name, exp_label) in enumerate(EXPERIMENTS, 1):
        for ds_idx, ds_name in enumerate(DATASETS, 1):
            count += 1
            print(f"\n{'=' * 70}")
            print(f"[{count}/{total}] {exp_label}  @  {ds_name}")
            print(f"      YAML: {param_name}")
            print(f"{'=' * 70}")

            dataset = get_dataset(ds_name)
            tracker = Tracker(TRACKER_NAME, param_name, ds_name)
            # 覆盖 results_dir 指向已有目录
            tracker.results_dir = os.path.join(RESULTS_BASE, TRACKER_NAME, param_name)
            run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=1)

            print(f"[{count}/{total}] 完成: {exp_label} @ {ds_name}")

    print(f"\n{'=' * 70}")
    print(f"全部补充实验完成! 结果在: {RESULTS_BASE}")
    print(f"{'=' * 70}")
