"""
重测 + 评估一体脚本：BDDR 组件消融(v2) + 模块消融重测，结果写入新目录。

新结果目录: output/test/tracking_results_retest/avtrack/<config>/<dataset>/
(与旧 tracking_results 并列，不覆盖旧结果)

测试范围（只测这些，只评估这些）:
  DTB70 : MSCA-only / HFDA-only / MSCA+HFDA / BDDR / BDDR+MSCA+HFDA /
          BDDR+MSCA+HFDA+ATC / BDDR w/o debias / BDDR w/o neg / BDDR w/ BCR
  UAV123: MSCA-only / HFDA-only / MSCA+HFDA /
          BDDR w/o debias / BDDR w/o neg / BDDR w/ BCR

checkpoint 尚不存在的配置（BDDR 三消融训练中）自动跳过测试，
训练完成后重跑本脚本即可补测（已完成的结果会自动跳过，不会重跑）。

用法:
  python tracking/test_eval_retest.py                # 全部测试 + 评估
  python tracking/test_eval_retest.py --dataset dtb70
  python tracking/test_eval_retest.py --eval-only    # 只评估已有结果
"""
import copy
import os
import sys

import numpy as np
import torch
import yaml
from tqdm import tqdm

prj_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.evaluation.environment import env_settings
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

# —— 全局 cfg 快照 ——
# update_config_from_file 是 merge 语义：上一个 yaml 的键（如 USE_MSCA_HFDA /
# MSCA_HFDA_MODE / CHECKPOINT_NAME）会残留到下一个未显式声明的配置。
# 每个配置测试前把全局 cfg 恢复为 config.py 默认值，保证模型构建正确。
from lib.config.avtrack.config import cfg as _global_cfg
_CFG_DEFAULT = copy.deepcopy(_global_cfg)


def _reset_cfg():
    _global_cfg.clear()
    _global_cfg.update(copy.deepcopy(_CFG_DEFAULT))


TRACKER_NAME = "avtrack"
RESULTS_SUBDIR = "tracking_results_retest"  # 新结果目录（与旧 tracking_results 并列）
THRESHOLDS = torch.arange(0.0, 1.01, 0.05, dtype=torch.float64)

EXPERIMENTS = {
    "dtb70": [
        ("ablation_01_msca_only",                  "MSCA-only"),
        ("ablation_01_hfda_only",                  "HFDA-only"),
        ("ablation_01_msca_hfda_v2",               "MSCA+HFDA"),
        ("ablation_02_bddr_v2",                    "BDDR"),
        ("ablation_stage2_msca_bddr_mixed_v2",     "BDDR+MSCA+HFDA"),
        ("ablation_stage2_msca_bddr_mixed_v2_atc", "BDDR+MSCA+HFDA+ATC"),
        ("ablation_02_bddr_wo_debias",             "BDDR w/o debias"),
        ("ablation_02_bddr_wo_neg",                "BDDR w/o neg"),
        ("ablation_02_bddr_bcr",                   "BDDR w/ BCR"),
    ],
    "uav123": [
        ("ablation_01_msca_only",                  "MSCA-only"),
        ("ablation_01_hfda_only",                  "HFDA-only"),
        ("ablation_01_msca_hfda_v2",               "MSCA+HFDA"),
        ("ablation_02_bddr_wo_debias",             "BDDR w/o debias"),
        ("ablation_02_bddr_wo_neg",                "BDDR w/o neg"),
        ("ablation_02_bddr_bcr",                   "BDDR w/ BCR"),
    ],
}


def _argv_value(flag):
    return sys.argv[sys.argv.index(flag) + 1] if flag in sys.argv else None


def _results_root(env):
    return os.path.join(env.save_dir, "test", RESULTS_SUBDIR)


def _expected_checkpoint(env, yaml_name):
    """与 lib/test/parameter/avtrack.py 完全一致的 checkpoint 路径推导。"""
    yaml_file = os.path.join(env.prj_dir, 'experiments/avtrack/%s.yaml' % yaml_name)
    with open(yaml_file, encoding='utf-8') as f:
        y = yaml.safe_load(f) or {}
    test_cfg = y.get('TEST', {}) or {}
    epoch = int(test_cfg.get('EPOCH', 500))
    ckpt_name = test_cfg.get('CHECKPOINT_NAME', None) or yaml_name
    return os.path.join(env.save_dir,
                        "checkpoints/train/avtrack/%s/AVTrack_ep%04d.pth.tar" % (ckpt_name, epoch))


def run_tests(datasets):
    env = env_settings()
    results_root = _results_root(env)
    print("=" * 70)
    print(f"重测结果目录: {results_root}")
    print("=" * 70)

    for ds_name in datasets:
        configs = EXPERIMENTS[ds_name]
        dataset = get_dataset(ds_name)
        print(f"\n### {ds_name}: {len(configs)} 个配置 × {len(dataset)} 条序列")

        for idx, (param_name, label) in enumerate(configs, 1):
            ckpt = _expected_checkpoint(env, param_name)
            if not os.path.isfile(ckpt):
                print(f"\n[{idx}/{len(configs)}] {label}: checkpoint 不存在，跳过测试"
                      f"（训完后重跑本脚本即可补测）\n       {ckpt}")
                continue

            print(f"\n[{idx}/{len(configs)}] {label} ({param_name}) @ {ds_name}")
            _reset_cfg()
            tracker = Tracker(TRACKER_NAME, param_name, ds_name, run_id=None)
            tracker.results_dir = os.path.join(results_root, param_name)
            os.makedirs(os.path.join(tracker.results_dir, ds_name), exist_ok=True)
            run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=1)


def evaluate(datasets):
    env = env_settings()
    results_root = _results_root(env)

    for ds_name in datasets:
        configs = EXPERIMENTS[ds_name]
        dataset = get_dataset(ds_name)
        results = {}

        for param_name, label in configs:
            all_curves, all_prec, missing = [], [], 0
            for seq in tqdm(dataset, desc=label, leave=False):
                path = os.path.join(results_root, param_name, ds_name, f"{seq.name}.txt")
                if not os.path.isfile(path):
                    missing += 1
                    continue
                anno_bb = torch.tensor(seq.ground_truth_rect)
                pred_bb = torch.tensor(load_text(path, delimiter=('\t', ','), dtype=np.float64))
                err_overlap, err_center, _, valid = calc_seq_err_robust(
                    pred_bb, anno_bb, seq.dataset, None)
                seq_len = anno_bb.shape[0]
                if seq_len > 0:
                    succ = (err_overlap[valid].view(-1, 1) > THRESHOLDS.view(1, -1)) \
                        .sum(0).float() / seq_len
                    all_curves.append(succ)
                    all_prec.append((err_center[valid] <= 20).float().mean().item())

            if missing > 0:
                print(f"  [{label}] 缺失 {missing}/{len(dataset)} 条序列结果")
            if all_curves:
                mean_curve = torch.stack(all_curves).mean(dim=0)
                results[label] = (torch.trapz(mean_curve, THRESHOLDS).item(),
                                  float(np.mean(all_prec)))
            else:
                results[label] = (None, None)

        print(f"\n{'=' * 62}")
        print(f"  {ds_name} 重测结果  ({RESULTS_SUBDIR})")
        print(f"{'=' * 62}")
        print(f"{'Tracker':<28} {'AUC':>10} {'Prec@20':>10}")
        print(f"{'-' * 50}")
        for _, label in configs:
            auc, prec = results[label]
            if auc is not None:
                print(f"{label:<28} {auc:>10.4f} {prec:>10.4f}")
            else:
                print(f"{label:<28} {'N/A':>10} {'N/A':>10}")
        print(f"{'=' * 62}")


if __name__ == "__main__":
    only = _argv_value("--dataset")
    if only is not None and only not in EXPERIMENTS:
        sys.exit(f"未知 --dataset: {only}（可选: {list(EXPERIMENTS)}）")
    datasets = [only] if only else list(EXPERIMENTS)

    # --config 只测/只评指定配置（如 --config ablation_stage2_msca_bddr_mixed_v2_atc）
    only_cfg = _argv_value("--config")
    if only_cfg is not None:
        EXPERIMENTS = {ds: [c for c in cfgs if c[0] == only_cfg]
                       for ds, cfgs in EXPERIMENTS.items()}
        datasets = [ds for ds in datasets if EXPERIMENTS[ds]]
        if not datasets:
            sys.exit(f"未知 --config: {only_cfg}")
        for ds in datasets:
            print(f"只测 {ds}: {[c[1] for c in EXPERIMENTS[ds]]}")

    if "--eval-only" not in sys.argv:
        run_tests(datasets)
    evaluate(datasets)
