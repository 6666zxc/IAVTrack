"""
论文标准: Params + FLOPs + FP32/FP16 FPS (随机张量直接测)
"""
import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

import torch

from lib.config.avtrack.config import cfg, update_config_from_file
from lib.models.avtrack.avtrack import build_avtrack

try:
    from thop import profile as thop_profile
    HAS_THOP = True
except ImportError:
    HAS_THOP = False


def fmt(n):
    if n >= 1e9: return f"{n/1e9:.2f}G"
    elif n >= 1e6: return f"{n/1e6:.2f}M"
    elif n >= 1e3: return f"{n/1e3:.2f}K"
    return str(n)


def measure_fps(model, z_embed, search_img, t_anno, s_anno):
    with torch.no_grad():
        for _ in range(10):
            _ = model.forward_from_z_embed(z_embed, search_img, t_anno, s_anno)
        torch.cuda.synchronize()
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(200):
            _ = model.forward_from_z_embed(z_embed, search_img, t_anno, s_anno)
        end.record()
        torch.cuda.synchronize()
        return 200 / start.elapsed_time(end) * 1000


def measure_flops(model, template, search, t_anno, s_anno):
    """用 thop 统计单次前向 FLOPs (template + search)"""
    flops, _ = thop_profile(
        model, inputs=(template, search, t_anno, s_anno), verbose=False
    )
    return flops


CONFIGS = [
    ("deit_tiny_patch16_224_30ep_baseline",  "Baseline (12L)"),
    ("ablation_02_bddr_v2",                   "+BDDR"),
    ("ablation_stage2_msca_bddr_mixed",       "+MSCA-HFDA"),
    ("ablation_stage2_msca_bddr_got10k_atc",  "Full (GOT10k+ATC)"),
]

T_IMG   = torch.randn(1, 3, 128, 128).cuda()
S_IMG   = torch.randn(1, 3, 256, 256).cuda()
T_ANNO  = torch.randn(1, 4).cuda()
S_ANNO  = torch.randn(1, 4).cuda()

W = 90
print(f"{'=' * W}")
print(f"AVTrack — Params / FLOPs / FPS (FP32 vs FP16)")
print(f"Inference: forward_from_z_embed  |  256x256 + 128x128")
print(f"{'=' * W}")
print(f"{'Configuration':<28} {'Params':>10} {'FLOPs':>10} {'FP32 FPS':>10} {'FP16 FPS':>10}")
print(f"{'-' * W}")

if not HAS_THOP:
    print("[WARNING] thop 未安装，FLOPs 列将显示 N/A")
    print("          pip install thop")

for yaml_name, label in CONFIGS:
    yaml_file = os.path.join(prj_path, "experiments/avtrack", f"{yaml_name}.yaml")
    update_config_from_file(yaml_file)
    print(f"  [debug] backbone={cfg.MODEL.BACKBONE.TYPE}")

    model = build_avtrack(cfg, training=False).cuda().eval()
    b = model.backbone

    all_p = sum(p.numel() for p in model.parameters() if p.requires_grad)
    # 排除训练专用模块 (global_stat_x, djs_loss)
    all_p -= sum(p.numel() for p in model.global_stat_x.parameters())
    if hasattr(model, 'djs_loss') and list(model.djs_loss.parameters()):
        all_p -= sum(p.numel() for p in model.djs_loss.parameters())

    # 分模块打印
    def module_params(mod):
        return sum(p.numel() for p in mod.parameters() if p.requires_grad)
    print(f"    backbone={fmt(module_params(model.backbone))}  "
          f"box_head={fmt(module_params(model.box_head))}  "
          f"bddr={fmt(module_params(model.bddr)) if model.bddr else 'N/A'}  "
          f"msca={fmt(module_params(model.msca_hfda)) if model.msca_hfda else 'N/A'}  "
          f"global_stat_x={fmt(module_params(model.global_stat_x))}  "
          f"total(infer)={fmt(all_p)}")

    # FP32 FPS (先测，避免 thop hook 污染)
    with torch.no_grad():
        z32 = b.patch_embed(T_IMG) + b.pos_embed_z
    fps32 = measure_fps(model, z32, S_IMG, T_ANNO, S_ANNO)

    # FP16
    model_half = model.half()
    with torch.no_grad():
        b_h = model_half.backbone
        z16 = b_h.patch_embed(T_IMG.half()) + b_h.pos_embed_z.half()
    fps16 = measure_fps(model_half, z16, S_IMG.half(), T_ANNO.half(), S_ANNO.half())

    del model, model_half
    torch.cuda.empty_cache()

    # FLOPs (用独立模型，避免 thop hook 干扰)
    flops_str = "N/A"
    if HAS_THOP:
        flops_model = build_avtrack(cfg, training=False).cuda().eval()
        with torch.no_grad():
            flops_val = measure_flops(flops_model, T_IMG, S_IMG, T_ANNO, S_ANNO)
        flops_str = fmt(flops_val)
        del flops_model
        torch.cuda.empty_cache()

    print(f"{label:<28} {fmt(all_p):>10} {flops_str:>10} {fps32:>8.1f}  {fps16:>8.1f}")

print(f"{'=' * W}")
