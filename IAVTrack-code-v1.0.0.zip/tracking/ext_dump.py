#!/usr/bin/env python3
"""Worker: run ONE external tracker (SGLATrack / LiteTrack / SMAT) on ONE UAV123 sequence,
and dump per-frame search crop + score map to .npy for later composition.

This script must be executed as a STANDALONE process (its own sys.path), because all
these projects share the same top-level package name `lib`.

Usage (called by vis_heatmap.py, not meant for direct use):
    python tracking/ext_dump.py --proj sglatrack --seq group2_1 \
        --frames 10 100 --out_dir <tmp_dir> --uav123_root <path>
"""
import argparse
import importlib.util
import os
import sys

import numpy as np

# never write __pycache__ into the (read-only / sandboxed) external repos
sys.dont_write_bytecode = True

PROJ_ROOTS = {
    'sglatrack': r'E:\member\sth\efficient contrast\SGLATrack-main',
    'litetrack': r'E:\member\sth\efficient contrast\LiteTrack-main',
    'smat': r'E:\member\sth\efficient contrast\SMAT-main',
}

# seq -> (image dir, startFrame, endFrame, anno file)  (UAV123)
SEQS = {
    'group2_1': ('data_seq/UAV123/group2', 1, 907, 'anno/UAV123/group2_1.txt'),
    'car14': ('data_seq/UAV123/car14', 1, 1327, 'anno/UAV123/car14.txt'),
    'person18': ('data_seq/UAV123/person18', 1, 1393, 'anno/UAV123/person18.txt'),
}


def _patch_local(proj_root):
    """Patch lib.test.evaluation.local so WSL /mnt/x/... paths become Windows x:/...
    Must be called BEFORE importing any lib.* of the target project."""
    local_py = os.path.join(proj_root, 'lib', 'test', 'evaluation', 'local.py')
    spec = importlib.util.spec_from_file_location('lib.test.evaluation.local', local_py)
    lm = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lm)
    orig = lm.local_env_settings

    def patched():
        s = orig()
        for a in dir(s):
            if a.startswith('_'):
                continue
            v = getattr(s, a)
            if isinstance(v, str) and v.startswith('/mnt/'):
                parts = v.split('/')
                if len(parts) >= 4 and len(parts[2]) == 1:
                    setattr(s, a, parts[2].upper() + ':/' + '/'.join(parts[3:]))
        return s

    lm.local_env_settings = patched
    sys.modules['lib.test.evaluation.local'] = lm


def load_gt(path):
    import re
    boxes = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = re.split(r'[\s,]+', line)
            if len(parts) < 4:
                continue
            boxes.append([float(p) for p in parts[:4]])
    return np.array(boxes, dtype=np.float64)


def build_tracker(proj, uav123_root):
    """Return (tracker, captured_dict, search_size). captured_dict is filled per-frame via hook."""
    import cv2  # noqa
    import torch  # noqa

    proj_root = PROJ_ROOTS[proj]
    sys.path.insert(0, proj_root)
    _patch_local(proj_root)

    if proj == 'sglatrack':
        from lib.test.parameter.sglatrack import parameters
        params = parameters('deit_distilled')
        params.debug = 0
        params.save_all_boxes = False
        from lib.test.tracker.sglatrack import sglatrack as _T
        tracker = _T(params, 'uav123')
        network_attr = 'network'
        track_returns_score = False
    elif proj == 'litetrack':
        from lib.test.parameter.litetrack import parameters
        params = parameters('B9_cae_center_all_ep300', 300)
        params.debug = 0
        params.save_all_boxes = False
        from lib.test.tracker.litetrack import LiteTrack as _T
        tracker = _T(params, 'uav')
        network_attr = 'network'
        track_returns_score = False
    elif proj == 'smat':
        from lib.test.parameter.mobilevitv2_track import parameters
        params = parameters('mobilevitv2_256_128x1_ep300')
        params.debug = 0
        params.save_all_boxes = False
        from lib.test.tracker.mobilevitv2_track import MobileViTv2Track as _T
        tracker = _T(params, 'uav')
        network_attr = 'network'
        track_returns_score = False
    else:
        raise ValueError(proj)

    # monkey-patch network forward to capture score_map each frame
    network = getattr(tracker, network_attr)
    captured = {}
    orig_forward = network.forward

    def wrapped_forward(*args, **kwargs):
        out = orig_forward(*args, **kwargs)
        if isinstance(out, dict) and 'score_map' in out:
            captured['score_map'] = out['score_map'].detach().cpu().squeeze().numpy()
        return out

    network.forward = wrapped_forward

    return tracker, captured, tracker.params.search_size


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--proj', required=True, choices=list(PROJ_ROOTS.keys()))
    p.add_argument('--seq', required=True)
    p.add_argument('--frames', nargs='+', type=int, required=True)
    p.add_argument('--out_dir', required=True)
    p.add_argument('--uav123_root', default=r'E:\member\sth\IAVtrack-main\data\UAV123')
    args = p.parse_args()

    import cv2

    img_sub, start, end, anno_sub = SEQS[args.seq]
    frames = [os.path.join(args.uav123_root, img_sub, '%06d.jpg' % f) for f in range(start, end + 1)]
    gt = load_gt(os.path.join(args.uav123_root, anno_sub))

    tracker, captured, search_size = build_tracker(args.proj, args.uav123_root)
    target = set(args.frames)
    max_f = max(target)

    os.makedirs(args.out_dir, exist_ok=True)

    for i in range(0, max_f + 1):
        image = cv2.cvtColor(cv2.imread(frames[i]), cv2.COLOR_BGR2RGB)
        if i == 0:
            tracker.initialize(image, {'init_bbox': gt[0]})
            continue
        tracker.track(image, None)
        if i in target:
            # capture search crop from tracker internals (last processed x_patch_arr)
            x_patch = getattr(tracker, 'x_patch_arr', None)
            if x_patch is None:
                # fall back: re-crop via tracker.state
                from lib.train.data.processing_utils import sample_target
                x_patch, _, _ = sample_target(image, tracker.state,
                                              tracker.params.search_factor,
                                              output_sz=tracker.params.search_size)
            sm = captured.get('score_map', None)
            np.save(os.path.join(args.out_dir, '%s_f%06d_search.npy' % (args.proj, i)), x_patch)
            if sm is not None:
                np.save(os.path.join(args.out_dir, '%s_f%06d_score.npy' % (args.proj, i)), sm)
            print('[ext_dump:%s] frame %d done' % (args.proj, i), flush=True)

    print('[ext_dump:%s] ALL DONE' % args.proj, flush=True)


if __name__ == '__main__':
    main()
