import _init_paths
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [8, 8]

from lib.test.analysis.plot_results import print_results
from lib.test.evaluation import get_dataset, trackerlist

trackers = []
dataset_name = 'dtb70'

"""avtrack BDDR v2"""
trackers.extend(trackerlist(
    name='avtrack',
    parameter_name='ablation_02_bddr_v2',
    dataset_name=dataset_name,
    run_ids=None,
    display_name='avtrack-bddr-v2'
))

dataset = get_dataset(dataset_name)
print_results(trackers, dataset, dataset_name, merge_results=True,
              plot_types=('success', 'norm_prec', 'prec'))
