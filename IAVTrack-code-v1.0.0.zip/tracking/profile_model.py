import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

import argparse
import torch
from thop import profile
from thop.utils import clever_format
import time
import importlib


def parse_args():
    """
    args for training.
    """
    parser = argparse.ArgumentParser(description='Parse args for training')
    # for train
    parser.add_argument('--script', type=str, default='avtrack', choices=['avtrack'],
                        help='training script name')
    parser.add_argument('--config', type=str, default='vitb_256_mae_ce_32x4_ep300', help='yaml configure file name')
    args = parser.parse_args()

    return args


def evaluate_vit_v2(model, template, search, template_anno, search_anno, fwd_fn):
    '''先测 FPS（真实跟踪路径），再测 FLOPs/Params（完整 forward），避免 thop hook 污染'''
    # 1) FPS 先测
    T_w = 500
    T_t = 1000
    print("testing speed (real tracking path) ...")
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    with torch.no_grad():
        for i in range(T_w):
            _ = fwd_fn(search)
        start = time.time()
        for i in range(T_t):
            _ = fwd_fn(search)
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        end = time.time()
        avg_lat = (end - start) / T_t
        print("The average overall latency is %.2f ms" % (avg_lat * 1000))
        print("FPS is %.2f fps" % (1. / avg_lat))

    # 2) FLOPs/Params 后测（profile 的 hook 残留不影响已完成的 FPS）
    macs1, params1 = profile(
        model,
        inputs=(template, search, template_anno, search_anno),
        custom_ops=None,
        verbose=False,
    )
    macs, params = clever_format([macs1, params1], "%.3f")
    print('overall macs is ', macs)
    print('overall params is ', params)

def evaluate_vit(model, template, search, template_anno, search_anno):
    '''Speed Test'''
    macs1, params1 = profile(
        model,
        inputs=(template, search, template_anno, search_anno),
        custom_ops=None,
        verbose=False,
    )
    macs, params = clever_format([macs1, params1], "%.3f")
    print('overall macs is ', macs)
    print('overall params is ', params)

    T_w = 500
    T_t = 1000
    print("testing speed ...")
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    with torch.no_grad():
        # overall
        for i in range(T_w):
            _ = model(template, search, template_anno, search_anno)
        start = time.time()
        for i in range(T_t):
            _ = model(template, search, template_anno, search_anno)
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        end = time.time()
        avg_lat = (end - start) / T_t
        print("The average overall latency is %.2f ms" % (avg_lat * 1000))
        print("FPS is %.2f fps" % (1. / avg_lat))


if __name__ == "__main__":
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    if torch.cuda.is_available():
        torch.cuda.set_device(device)
    # Compute the Flops and Params of our STARK-S model
    args = parse_args()
    '''update cfg'''
    prj_dir = os.path.dirname(os.path.abspath(__file__))
    yaml_fname = os.path.join(prj_dir, '../experiments/%s/%s.yaml' % (args.script, args.config))
    config_module = importlib.import_module('lib.config.%s.config' % args.script)
    cfg = config_module.cfg
    config_module.update_config_from_file(yaml_fname)
    '''set some values'''
    bs = 1
    z_sz = cfg.TEST.TEMPLATE_SIZE
    x_sz = cfg.TEST.SEARCH_SIZE

    if args.script == "avtrack":
        model_module = importlib.import_module('lib.models')
        model_constructor = model_module.build_avtrack
        model = model_constructor(cfg, training=False)
        # 固定随机种子：模型含自适应跳层(USE_ADAPTIVE_SKIP)，激活层数依赖输入，
        # 输入随机会导致 FLOPs/FPS/params 每次变化，固定种子后结果可复现。
        torch.manual_seed(0)
        torch.cuda.manual_seed(0)
        # get the template and search
        template = torch.randn(bs, 3, z_sz, z_sz)
        search = torch.randn(bs, 3, x_sz, x_sz)
        template_anno = torch.zeros(bs, 4, device=device)
        search_anno = torch.zeros(bs, 4, device=device)
        # transfer to device
        model = model.to(device)
        model.eval()
        template = template.to(device)
        search = search.to(device)

        # 完整参数量统计：thop 只统计“被 hook 且被执行的 Conv/Linear/BN”等模块，
        # 会漏掉 pos_embed/cls_token/LayerNorm/相对位置编码等 nn.Parameter，以及
        # 推理时不被调用的模块（如 global_stat_x）。这里用 model.parameters() 精确统计。
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        bb_params = sum(p.numel() for p in model.backbone.parameters())
        head_params = sum(p.numel() for p in model.box_head.parameters())
        other_params = total_params - bb_params - head_params
        print("== Manual param breakdown ==")
        print("backbone: %.3f M" % (bb_params / 1e6))
        print("box_head: %.3f M" % (head_params / 1e6))
        print("other (global_stat_x/bddr/msca): %.3f M" % (other_params / 1e6))
        print("TOTAL (all params): %.3f M" % (total_params / 1e6))
        print("TOTAL (trainable): %.3f M" % (trainable_params / 1e6))
        # 推理参数量（与其他跟踪器统一口径）：排除仅训练用的 global_stat_x/djs_loss
        gs_params = sum(p.numel() for p in model.global_stat_x.parameters())
        print("Inference params (paper): %.3f M" % ((total_params - gs_params) / 1e6))

        b = model.backbone
        z_pre = b.patch_embed(template) + b.pos_embed_z
        if hasattr(b, "forward_from_z_embed"):
            print("Using forward_from_z_embed (real tracking path)")
            def _fwd(s):
                return model.forward_from_z_embed(z_pre, s, [], [], is_distill=False)
        else:
            _fwd = lambda s: model(template, s, template_anno, search_anno)

        # 统计 AM 实际激活层数（前2层固定执行，第2~11层由 active_score_module 决定）
        with torch.no_grad():
            _, aux = model.backbone.forward_from_z_embed(z_pre, search, is_distill=False)
        probs = aux.get('probs_active', [])
        if probs:
            n_active = sum(1 for p in probs if (p > 0.5).sum().item() > 0)
            print("AM activated layers: %d/12 (2 fixed + %d/%d conditional)" % (2 + n_active, n_active, len(probs)))
        else:
            print("AM activated layers: 12/12 (adaptive skip disabled, all layers run)")

        merge_layer = cfg.MODEL.BACKBONE.MERGE_LAYER
        if merge_layer <= 0:
            evaluate_vit_v2(model, template, search, template_anno, search_anno, _fwd)
        else:
            evaluate_vit(model, template, search, template_anno, search_anno)

    else:
        raise NotImplementedError
