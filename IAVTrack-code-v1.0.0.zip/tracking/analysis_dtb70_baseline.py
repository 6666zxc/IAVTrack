import _init_paths
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [8, 8]

from lib.test.analysis.plot_results import print_results
from lib.test.evaluation import get_dataset, trackerlist

trackers = []
dataset_name = 'dtb70'

"""avtrack"""
trackers.extend(trackerlist(
    name='avtrack',
    parameter_name='deit_tiny_patch16_224_30ep_baseline',
    dataset_name=dataset_name,
    run_ids=None,
    display_name='avtrack'
))

dataset = get_dataset(dataset_name)
print_results(trackers, dataset, dataset_name, merge_results=True, plot_types=('success', 'norm_prec', 'prec'))
