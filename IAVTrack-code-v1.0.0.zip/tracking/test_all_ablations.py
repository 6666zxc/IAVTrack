"""
顺序测试脚本：依次在 UAVDT, UAV123, DTB70 上运行 4 个实验配置
1. Baseline
2. BDDR
3. BDDR (冻结) + MSCA
4. BDDR + MSCA + ATC

结果保存到独立的时间戳文件夹中，不覆盖旧结果。
"""
import os
import sys
from datetime import datetime

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.evaluation.environment import env_settings


# ========== 配置 ==========
# 4 个实验，按顺序
EXPERIMENTS = [
    ("deit_tiny_patch16_224_30ep_baseline",          "Baseline"),
    ("ablation_02_bddr_v2",                           "BDDR"),
    ("ablation_stage2_msca_bddr_mixed",               "BDDR(冻结)+MSCA"),
    ("ablation_stage2_msca_bddr_mixed_atc",           "BDDR+MSCA+ATC"),
]

# 3 个数据集，按顺序
DATASETS = ["uavdt", "uav123", "dtb70"]

TRACKER_NAME = "avtrack"
NUM_GPUS = 1


def run_ablation_sequence():
    # 创建带时间戳的结果根目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    env = env_settings()
    new_results_root = os.path.join(env.save_dir, "test", f"tracking_results_{timestamp}")
    os.makedirs(new_results_root, exist_ok=True)

    print("=" * 70)
    print(f"结果根目录: {new_results_root}")
    print(f"共 {len(EXPERIMENTS)} 个实验 × {len(DATASETS)} 个数据集 = {len(EXPERIMENTS) * len(DATASETS)} 次测试")
    print("=" * 70)

    total = len(EXPERIMENTS) * len(DATASETS)
    count = 0

    for exp_idx, (param_name, exp_label) in enumerate(EXPERIMENTS, 1):
        for ds_idx, ds_name in enumerate(DATASETS, 1):
            count += 1
            print(f"\n{'=' * 70}")
            print(f"[{count}/{total}] 实验 {exp_idx}/{len(EXPERIMENTS)}: {exp_label}")
            print(f"        数据集 {ds_idx}/{len(DATASETS)}: {ds_name}")
            print(f"        参数文件: {param_name}")
            print(f"{'=' * 70}")

            # 为每个实验-数据集组合创建一个 tracker，手动设置 results_dir 避免冲突
            dataset = get_dataset(ds_name)
            tracker = Tracker(TRACKER_NAME, param_name, ds_name, run_id=None)

            # 覆盖 results_dir 指向新目录
            tracker.results_dir = os.path.join(
                new_results_root, TRACKER_NAME, param_name
            )
            os.makedirs(os.path.join(tracker.results_dir, ds_name), exist_ok=True)

            run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=NUM_GPUS)

            print(f"[{count}/{total}] 完成: {exp_label} @ {ds_name}")

    print(f"\n{'=' * 70}")
    print(f"全部完成! 结果保存在: {new_results_root}")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    run_ablation_sequence()
