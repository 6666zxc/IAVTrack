"""将 GOT-10k test 平铺结果打包为官方提交 zip。

官方要求解压后结构：
  <tracker_name>/
  ├── GOT-10k_Test_000001/
  │   ├── GOT-10k_Test_000001_001.txt   # N×4，每行 <xmin>,<ymin>,<w>,<h>
  │   └── GOT-10k_Test_000001_time.txt  # N×1 每帧耗时
  └── ...

用法:
  python tracking/pack_got10k_test.py <param_name> <tracker_name>
示例:
  python tracking/pack_got10k_test.py ablation_00_baseline_got10k IAVtrack_Baseline
  python tracking/pack_got10k_test.py ablation_stage2_msca_bddr_got10k_atc IAVtrack_BDDR_MSCA_ATC
"""
import os
import sys
import glob
import zipfile
import numpy as np

prj = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))


def pack(param_name, tracker_name):
    src = os.path.join(prj, 'output', 'test', 'tracking_results', 'avtrack', param_name, 'got10k')
    if not os.path.isdir(src):
        sys.exit('结果目录不存在: %s' % src)

    bb_files = sorted([f for f in glob.glob(os.path.join(src, 'GOT-10k_Test_*.txt'))
                       if not f.endswith('_time.txt')])
    if len(bb_files) != 180:
        sys.exit('结果文件数为 %d（应为 180），请先跑完 test 集' % len(bb_files))

    out_zip = os.path.join(prj, 'output', 'got10k_test_%s.zip' % tracker_name)
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for bb in bb_files:
            seq = os.path.splitext(os.path.basename(bb))[0]
            # 每行: xmin,ymin,width,height（1-based 整数）
            data = np.loadtxt(bb, delimiter='\t', dtype=int).reshape(-1, 4)
            lines = '\n'.join('%d,%d,%d,%d' % (r[0], r[1], r[2], r[3]) for r in data)
            zf.writestr('%s/%s/%s_001.txt' % (tracker_name, seq, seq), lines)

            time_file = bb[:-4] + '_time.txt'
            if os.path.isfile(time_file):
                times = np.loadtxt(time_file, delimiter='\t', dtype=float).reshape(-1)
                zf.writestr('%s/%s/%s_time.txt' % (tracker_name, seq, seq),
                            '\n'.join('%.6f' % t for t in times))
    print('已生成: %s （%d 条序列，tracker=%s）' % (out_zip, len(bb_files), tracker_name))


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    pack(sys.argv[1], sys.argv[2])
