import _init_paths
import os
import numpy as np
import torch
from tqdm import tqdm

from lib.test.evaluation import get_dataset
from lib.test.evaluation.environment import env_settings
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

DATASET_NAME = 'dtb70'
RESULTS_DIR = env_settings().results_path

# (yaml 配置名, 表格显示名)
TRACKERS_CFG = [
    ("ablation_02_bddr_v2",         "BDDR (full)"),
    ("ablation_02_bddr_wo_debias",  "BDDR w/o debias"),
    ("ablation_02_bddr_wo_neg",     "BDDR w/o neg"),
    ("ablation_02_bddr_bcr",        "BCR"),
]

thr_overlap = torch.arange(0.0, 1.0 + 0.05, 0.05, dtype=torch.float64)


def evaluate_one():
    dataset = get_dataset(DATASET_NAME)
    n_trackers = len(TRACKERS_CFG)
    n_seqs = len(dataset)

    all_succ_sum = [torch.zeros(len(thr_overlap), dtype=torch.float64) for _ in range(n_trackers)]
    all_prec20 = torch.zeros(n_trackers)

    valid_count = 0
    for seq in tqdm(dataset, desc=DATASET_NAME):
        anno_bb = torch.tensor(seq.ground_truth_rect)
        seq_ok = True

        for trk_id, (param, _label) in enumerate(TRACKERS_CFG):
            results_path = os.path.join(RESULTS_DIR, "avtrack", param, DATASET_NAME, f"{seq.name}.txt")
            if not os.path.isfile(results_path):
                print(f"  [WARN] Missing: {results_path}")
                seq_ok = False
                break
            pred_bb = torch.tensor(load_text(str(results_path), delimiter=('\t', ','), dtype=np.float64))
            err_overlap, err_center, _, valid = calc_seq_err_robust(
                pred_bb, anno_bb, seq.dataset, None)

            valid_overlap = err_overlap[valid]
            valid_center = err_center[valid]
            seq_len = anno_bb.shape[0]
            if seq_len <= 0:
                seq_ok = False
                break

            # success 分母用完整帧数（标准 OTB/DTB70 协议，无效帧算失败）
            succ = (valid_overlap.view(-1, 1) > thr_overlap.view(1, -1)).sum(0).float() / seq_len
            all_succ_sum[trk_id] += succ

            # prec 分母用有效帧数（与 eval_quick 一致）
            prec = (valid_center <= 20).float().mean().item()
            all_prec20[trk_id] += prec * 100.0

        if seq_ok:
            valid_count += 1

    print(f"\n{'=' * 48}")
    print(f"  Dataset: {DATASET_NAME}  ({valid_count}/{n_seqs} sequences)")
    print(f"{'=' * 48}")
    print(f"{'Experiment':<22} {'AUC':>8} {'Prec20':>8}")
    print(f"{'-' * 48}")
    for trk_id, (_param, label) in enumerate(TRACKERS_CFG):
        auc = torch.trapz(all_succ_sum[trk_id] / valid_count, thr_overlap).item() * 100.0
        prec20 = all_prec20[trk_id].item() / valid_count
        print(f"{label:<22} {auc:>8.2f} {prec20:>8.2f}")
    print(f"{'=' * 48}\n")


if __name__ == "__main__":
    evaluate_one()
