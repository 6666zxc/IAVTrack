"""
评估 tracking_results_20260720_145826 下所有 4 个实验
按顺序输出 UAVDT, UAV123, DTB70 的 AUC / Prec@20
"""
import _init_paths
import os
import torch
import numpy as np
from tqdm import tqdm

from lib.test.evaluation import get_dataset
from lib.test.evaluation.tracker import Tracker
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

RESULTS_DIR = r"E:\member\sth\IAVtrack-main\output\test\tracking_results_20260720_145826"

TRACKERS_CFG = [
    ("deit_tiny_patch16_224_30ep_baseline",  "Baseline"),
    ("ablation_02_bddr_v2",                  "BDDR"),
    ("ablation_stage2_msca_bddr_mixed",      "BDDR+MSCA"),
    ("ablation_stage2_msca_bddr_mixed_atc",  "BDDR+MSCA+ATC"),
]

DATASETS = ["uavdt", "uav123", "dtb70"]


def evaluate_one(ds_name):
    dataset = get_dataset(ds_name)
    n_trackers = len(TRACKERS_CFG)
    n_seqs = len(dataset)
    threshold_set_overlap = torch.arange(0.0, 1.0 + 0.05, 0.05, dtype=torch.float64)
    threshold_set_center = torch.arange(0, 51, dtype=torch.float64)

    all_auc = torch.zeros(n_trackers)
    all_prec20 = torch.zeros(n_trackers)

    valid_count = 0
    for seq in tqdm(dataset, desc=ds_name):
        anno_bb = torch.tensor(seq.ground_truth_rect)
        target_visible = torch.tensor(seq.target_visible, dtype=torch.uint8) if seq.target_visible is not None else None
        seq_results_found = True

        for trk_id, (param, label) in enumerate(TRACKERS_CFG):
            results_path = os.path.join(RESULTS_DIR, "avtrack", param, ds_name, f"{seq.name}.txt")
            if not os.path.isfile(results_path):
                print(f"  [WARN] Missing: {results_path}")
                seq_results_found = False
                break
            pred_bb = torch.tensor(load_text(str(results_path), delimiter=('\t', ','), dtype=np.float64))
            try:
                err_overlap, err_center, _, valid_frame = calc_seq_err_robust(
                    pred_bb, anno_bb, seq.dataset, target_visible)
            except Exception as e:
                print(f"  [ERR] {label} on {seq.name}: {e}")
                seq_results_found = False
                break

            seq_len = valid_frame.long().sum()
            if seq_len <= 0:
                seq_results_found = False
                break

            # AUC
            succ = (err_overlap[valid_frame].view(-1, 1) > threshold_set_overlap.view(1, -1)).sum(0).float() / seq_len
            auc = succ.mean().item()
            all_auc[trk_id] += auc

            # Prec@20
            prec = (err_center[valid_frame].view(-1, 1) <= threshold_set_center.view(1, -1)).sum(0).float() / seq_len
            prec20 = prec[20].item() * 100.0
            all_prec20[trk_id] += prec20

        if seq_results_found:
            valid_count += 1

    print(f"\n{'=' * 70}")
    print(f"  Dataset: {ds_name}  ({valid_count}/{n_seqs} sequences)")
    print(f"{'=' * 70}")
    print(f"{'Experiment':<30} {'AUC':>8}  {'Prec@20':>8}")
    print(f"{'-' * 48}")
    for trk_id, (param, label) in enumerate(TRACKERS_CFG):
        auc = all_auc[trk_id].item() / valid_count * 100.0
        prec20 = all_prec20[trk_id].item() / valid_count
        print(f"{label:<30} {auc:>7.2f}  {prec20:>7.2f}")
    print(f"{'=' * 70}\n")


if __name__ == "__main__":
    for ds in DATASETS:
        evaluate_one(ds)
