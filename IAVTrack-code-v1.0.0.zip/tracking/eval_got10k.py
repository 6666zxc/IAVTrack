"""评估 GOT-10k: AO / SR0.50 / SR0.75"""
import _init_paths
import os
import numpy as np
import torch
from tqdm import tqdm

from lib.test.evaluation import get_dataset
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

RESULTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "output", "test", "tracking_results", "avtrack")

CONFIGS = [
    ("ablation_00_baseline_got10k",              "Baseline"),
    ("ablation_stage2_msca_bddr_got10k_atc",     "BDDR+MSCA+ATC"),
]

DS_NAME = "got10k_val"

dataset = get_dataset(DS_NAME)
n_seqs = len(dataset)

print(f"\n{'='*60}")
print(f"  GOT-10k Validation  ({n_seqs} sequences)")
print(f"{'='*60}")
print(f"{'Tracker':<20} {'AO':>8}  {'SR0.50':>8}  {'SR0.75':>8}")
print(f"{'-'*48}")

for param_name, label in CONFIGS:
    all_ao, all_sr50, all_sr75, missing = [], [], [], 0
    for seq in tqdm(dataset, desc=label, leave=False):
        results_path = os.path.join(RESULTS_DIR, param_name, "got10k", f"{seq.name}.txt")
        if not os.path.isfile(results_path):
            missing += 1
            continue

        pred_bb = torch.tensor(load_text(str(results_path), delimiter=('\t', ','), dtype=np.float64))
        anno_bb = torch.tensor(seq.ground_truth_rect)

        try:
            err_overlap, _, _, valid = calc_seq_err_robust(pred_bb, anno_bb, seq.dataset, None)
        except Exception:
            continue

        overlaps = err_overlap[valid]
        if len(overlaps) == 0:
            continue

        all_ao.append(overlaps.mean().item())
        all_sr50.append((overlaps > 0.5).float().mean().item())
        all_sr75.append((overlaps > 0.75).float().mean().item())

    ao = np.mean(all_ao) * 100 if all_ao else 0
    sr50 = np.mean(all_sr50) * 100 if all_sr50 else 0
    sr75 = np.mean(all_sr75) * 100 if all_sr75 else 0
    n_eval = len(all_ao)
    flag = f" ({n_eval}/{n_seqs - missing})" if missing > 0 else ""
    print(f"{label:<20} {ao:>7.2f}  {sr50:>7.2f}  {sr75:>7.2f}{flag}")

print(f"{'='*60}\n")
