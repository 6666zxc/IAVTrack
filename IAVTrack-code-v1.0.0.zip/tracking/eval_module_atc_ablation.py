"""Evaluate module + ATC ablation on DTB70 and UAVDT.

Prints one table per dataset: baseline+ATC / BDDR+ATC / MSCA-HFDA+ATC
(AUC and Prec@20).
"""
import _init_paths
import os
import numpy as np
import torch
from tqdm import tqdm
from lib.test.evaluation import get_dataset, trackerlist
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

THRESHOLDS = torch.arange(0.0, 1.01, 0.05, dtype=torch.float64)

CONFIGS = [
    ('ablation_baseline_atc', 'Baseline + ATC'),
    ('ablation_bddr_atc',     'BDDR + ATC'),
    ('ablation_msca_atc',     'MSCA-HFDA + ATC'),
]

DATASETS = ['dtb70', 'uavdt']


def evaluate(dataset_name):
    dataset = get_dataset(dataset_name)
    results = {}
    for cfg_name, display in CONFIGS:
        trackers = trackerlist('avtrack', cfg_name, dataset_name, None, display)
        trk = trackers[0]

        all_success_curves = []
        all_prec = []
        missing = 0

        for seq in tqdm(dataset, desc=f"{display}", leave=False):
            results_path = '{}/{}/{}.txt'.format(trk.results_dir, dataset_name, seq.name)
            if not os.path.isfile(results_path):
                missing += 1
                continue

            anno_bb = torch.tensor(seq.ground_truth_rect)
            pred_bb = torch.tensor(load_text(results_path, delimiter=('\t', ','), dtype=np.float64))

            err_overlap, err_center, _, valid = calc_seq_err_robust(
                pred_bb, anno_bb, seq.dataset, None)

            valid_overlap = err_overlap[valid]
            valid_center = err_center[valid]
            seq_len = anno_bb.shape[0]

            if seq_len > 0:
                success = (valid_overlap.view(-1, 1) > THRESHOLDS.view(1, -1)).sum(0).float() / seq_len
                all_success_curves.append(success)
                prec = (valid_center <= 20).float().mean().item()
                all_prec.append(prec)

        if missing > 0:
            print(f"  [{display}] missing {missing}/{len(dataset)} sequences")

        if len(all_success_curves) > 0:
            curves = torch.stack(all_success_curves)
            mean_curve = curves.mean(dim=0)
            auc = torch.trapz(mean_curve, THRESHOLDS).item()
            avg_prec = np.mean(all_prec)
            results[display] = (auc, avg_prec)
        else:
            results[display] = (None, None)
    return results


def print_table(title, results):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")
    print(f"{'Tracker':<22} {'AUC':>10} {'Prec@20':>10}")
    print(f"{'-'*44}")
    for _, display in CONFIGS:
        auc, prec = results[display]
        if auc is not None:
            print(f"{display:<22} {auc:>10.4f} {prec:>10.4f}")
        else:
            print(f"{display:<22} {'N/A':>10} {'N/A':>10}")
    print(f"{'='*60}")


if __name__ == "__main__":
    for ds in DATASETS:
        print(f"\nEvaluating on {ds}")
        res = evaluate(ds)
        print_table(f"Module + ATC Ablation ({ds})", res)
