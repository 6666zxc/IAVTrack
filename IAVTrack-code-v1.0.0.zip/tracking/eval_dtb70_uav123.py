"""DTB70 + UAV123 合并评估表：同一行展示同一配置在两个数据集上的 AUC / Prec@20。

评估方式与 eval_quick.py 完全一致（21 个重叠阈值梯形积分 AUC + Prec@20）。
在某数据集上没有任何结果的配置显示 N/A；两个数据集都无结果的配置不列出。
"""
import _init_paths
import os
import numpy as np
import torch
from tqdm import tqdm
from lib.test.evaluation import get_dataset, trackerlist
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

TRACKER_CONFIGS = [
    ('deit_tiny_patch16_224_30ep_baseline', 'Baseline'),
    ('ablation_02_bddr_v2', 'BDDR'),
    ('ablation_01_msca_only', 'MSCA-only'),
    ('ablation_01_hfda_only', 'HFDA-only'),
    ('ablation_01_msca_hfda_v2', 'MSCA+HFDA'),
    ('ablation_stage2_msca_bddr_mixed_v2', 'BDDR+MSCA+HFDA'),
    ('ablation_stage2_msca_bddr_mixed_v2_nofreeze', 'BDDR+MSCA+HFDA (nofreeze)'),
    ('ablation_bddr_atc', 'BDDR+ATC'),
    ('ablation_01_msca_only_atc', 'BDDR+MSCA+ATC'),
    ('ablation_01_hfda_only_atc', 'BDDR+HFDA+ATC'),
    ('ablation_stage2_msca_bddr_mixed_v2_atc', 'BDDR+MSCA+HFDA+ATC'),
    ('ablation_atc_anchored', 'ATC-anchored'),
    ('ablation_atc_full', 'ATC-full'),
    # ---- BDDR 组件消融 ----
    ('ablation_02_bddr_wo_neg', 'BDDR w/o Neg'),
    ('ablation_02_bddr_wo_debias', 'BDDR w/o Debias'),
    ('ablation_02_bddr_bcr', 'BDDR w/ BCR'),
    # ---- 模板更新策略消融 (BACTrack Table V) ----
    ('ablation_upd_none', 'Upd: None'),
    ('ablation_upd_interval', 'Upd: Fixed-10'),
    ('ablation_upd_thresh', 'Upd: Thresh0.5'),
    ('ablation_upd_always', 'Upd: Always'),
]

DATASETS = ['dtb70', 'uav123']

# Standard 21 overlap thresholds: 0.0, 0.05, ..., 1.0
THRESHOLDS = torch.arange(0.0, 1.01, 0.05, dtype=torch.float64)


def eval_config_on_dataset(cfg_name, display, ds_name, dataset):
    """与 eval_quick.py 相同的逐序列评估，返回 (AUC, Prec@20) 或 None。"""
    trackers = trackerlist('avtrack', cfg_name, ds_name, None, display)
    trk = trackers[0]

    all_success_curves = []
    all_prec = []

    for seq in tqdm(dataset, desc=f"{ds_name}/{display}", leave=False):
        results_path = '{}/{}/{}.txt'.format(trk.results_dir, ds_name, seq.name)
        if not os.path.isfile(results_path):
            continue

        anno_bb = torch.tensor(seq.ground_truth_rect)
        pred_bb = torch.tensor(load_text(results_path, delimiter=('\t', ','), dtype=np.float64))

        err_overlap, err_center, _, valid = calc_seq_err_robust(
            pred_bb, anno_bb, seq.dataset, None)

        valid_overlap = err_overlap[valid]
        valid_center = err_center[valid]
        seq_len = anno_bb.shape[0]

        if seq_len > 0:
            success = (valid_overlap.view(-1, 1) > THRESHOLDS.view(1, -1)).sum(0).float() / seq_len
            all_success_curves.append(success)
            prec = (valid_center <= 20).float().mean().item()
            all_prec.append(prec)

    if not all_success_curves:
        return None
    mean_curve = torch.stack(all_success_curves).mean(dim=0)
    auc = torch.trapz(mean_curve, THRESHOLDS).item()
    return auc, np.mean(all_prec)


datasets = {ds: get_dataset(ds) for ds in DATASETS}

rows = []
for cfg_name, display in TRACKER_CONFIGS:
    row = {ds: eval_config_on_dataset(cfg_name, display, ds, datasets[ds]) for ds in DATASETS}
    if all(v is None for v in row.values()):
        continue  # 两个数据集都无结果，不列出
    rows.append((display, row))

# Print combined table
print(f"\n{'='*78}")
print(f"  DTB70 + UAV123")
print(f"{'='*78}")
print(f"{'Tracker':<26} {'DTB70 AUC':>10} {'DTB70 P@20':>11} {'UAV123 AUC':>11} {'UAV123 P@20':>12}")
print(f"{'-'*72}")


def fmt(v):
    return f"{v:>10.4f}" if v is not None else f"{'N/A':>10}"


for display, row in rows:
    d = row['dtb70']
    u = row['uav123']
    print(f"{display:<26} {fmt(d[0] if d else None)} {fmt(d[1] if d else None):>11} "
          f"{fmt(u[0] if u else None):>11} {fmt(u[1] if u else None):>12}")
print(f"{'='*78}")
