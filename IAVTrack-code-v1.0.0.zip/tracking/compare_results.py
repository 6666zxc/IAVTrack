import _init_paths
import argparse
import numpy as np
from tqdm import tqdm
import os
import torch
from lib.test.evaluation import get_dataset, trackerlist

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='got10k_val',
                    choices=['got10k_val', 'got10k_test'])
args = parser.parse_args()

report_name = 'got10k'

trackers = []
trackers.extend(trackerlist(
    name='avtrack', parameter_name='ablation_00_baseline_got10k',
    dataset_name=report_name, run_ids=None, display_name='Baseline'))
trackers.extend(trackerlist(
    name='avtrack', parameter_name='ablation_02_bddr_got10k',
    dataset_name=report_name, run_ids=None, display_name='BDDR'))

dataset = get_dataset(args.dataset)

n_seq = len(dataset)
n_trk = len(trackers)
overlaps = np.full((n_seq, n_trk), np.nan)
speeds = np.full((n_seq, n_trk), np.nan)

for seq_id, seq in enumerate(tqdm(dataset)):
    anno = np.array(seq.ground_truth_rect)
    for trk_id, trk in enumerate(trackers):
        results_path = os.path.join(trk.results_dir, report_name, f'{seq.name}.txt')
        time_path = os.path.join(trk.results_dir, report_name, f'{seq.name}_time.txt')

        if not (os.path.exists(results_path) and os.path.exists(time_path)):
            continue

        pred = np.loadtxt(results_path, delimiter='\t')
        if pred.ndim != 2 or pred.shape[0] < 2:
            continue
        times = np.loadtxt(time_path)
        times = times[times > 0]
        if len(times) == 0:
            continue

        speeds[seq_id, trk_id] = np.mean(1.0 / times)

        # Compute per-frame IoU
        min_len = min(len(pred), len(anno))
        pred_t = torch.tensor(pred[:min_len])
        anno_t = torch.tensor(anno[:min_len])

        # pred: [N, 4] (x, y, w, h), anno: same
        px1, py1 = pred_t[:, 0], pred_t[:, 1]
        pw, ph = pred_t[:, 2], pred_t[:, 3]
        px2, py2 = px1 + pw, py1 + ph

        ax1, ay1 = anno_t[:, 0], anno_t[:, 1]
        aw, ah = anno_t[:, 2], anno_t[:, 3]
        ax2, ay2 = ax1 + aw, ay1 + ah

        ix1 = torch.max(px1, ax1)
        iy1 = torch.max(py1, ay1)
        ix2 = torch.min(px2, ax2)
        iy2 = torch.min(py2, ay2)

        iw = (ix2 - ix1).clamp(min=0)
        ih = (iy2 - iy1).clamp(min=0)
        inter = iw * ih
        union = pw * ph + aw * ah - inter

        ious = inter / (union + 1e-8)
        valid = (union > 0)
        if valid.sum() == 0:
            continue
        overlaps[seq_id, trk_id] = ious[valid].mean().item()

# Report
valid_seqs = ~np.isnan(overlaps[:, 0]) & ~np.isnan(overlaps[:, 1])
n_common = valid_seqs.sum()

print(f'\n===== GOT-10k Validation Results ({n_common} common sequences) =====\n')
print(f'{"Metric":<20} {"Baseline":>10} {"BDDR":>10} {"Delta":>10}')
print('-' * 50)

for name, ov1, ov2 in [
    ('AO', np.nanmean(overlaps[valid_seqs, 0]), np.nanmean(overlaps[valid_seqs, 1])),
    ('SR(0.50)', np.nanmean(overlaps[valid_seqs, 0] > 0.5), np.nanmean(overlaps[valid_seqs, 1] > 0.5)),
    ('SR(0.75)', np.nanmean(overlaps[valid_seqs, 0] > 0.75), np.nanmean(overlaps[valid_seqs, 1] > 0.75)),
]:
    print(f'{name:<20} {ov1:>10.4f} {ov2:>10.4f} {ov2 - ov1:>+10.4f}')

fps1 = np.nanmean(speeds[valid_seqs, 0])
fps2 = np.nanmean(speeds[valid_seqs, 1])
print(f'{"FPS":<20} {fps1:>10.2f} {fps2:>10.2f} {fps2 - fps1:>+10.2f}')
