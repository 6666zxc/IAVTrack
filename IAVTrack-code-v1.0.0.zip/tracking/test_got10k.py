"""测试 GOT-10k: Baseline, BDDR+MSCA, BDDR+MSCA+ATC"""
import os
import sys

prj_path = os.path.join(os.path.dirname(__file__), '..')
if prj_path not in sys.path:
    sys.path.append(prj_path)

from lib.test.evaluation import get_dataset
from lib.test.evaluation.running import run_dataset
from lib.test.evaluation.tracker import Tracker

CONFIGS = [
    ("ablation_00_baseline_got10k",              "Baseline"),
    ("ablation_stage2_msca_bddr_got10k_atc",     "BDDR+MSCA+ATC"),
]

DS_NAME = "got10k_val"
TRACKER_NAME = "avtrack"

def main():
    results_root = os.path.join(
        os.path.dirname(__file__), "..", "output", "test", "tracking_results", TRACKER_NAME
    )
    results_root = os.path.abspath(results_root)

    for param_name, label in CONFIGS:
        print(f"\n{'='*50}")
        print(f"  {label} @ {DS_NAME}")
        print(f"  Config: {param_name}")
        print(f"{'='*50}")

        dataset = get_dataset(DS_NAME)
        tracker = Tracker(TRACKER_NAME, param_name, DS_NAME, run_id=None)
        tracker.results_dir = os.path.join(results_root, param_name)
        os.makedirs(os.path.join(tracker.results_dir, "got10k"), exist_ok=True)

        run_dataset(dataset, [tracker], debug=0, threads=0, num_gpus=1)
        print(f"完成: {label}")

    print(f"\n全部完成")

if __name__ == "__main__":
    main()
