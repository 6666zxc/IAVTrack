"""Evaluate DTB70 for the 4 ablation configs."""
import _init_paths
import os
import numpy as np
import torch
from tqdm import tqdm
from lib.test.evaluation import get_dataset, trackerlist
from lib.test.analysis.extract_results import calc_seq_err_robust
from lib.test.utils.load_text import load_text

THRESHOLDS = torch.arange(0.0, 1.01, 0.05, dtype=torch.float64)
DATASET_NAME = 'dtb70'

TRACKER_CONFIGS = [
    ('deit_tiny_patch16_224_30ep_baseline', 'Baseline'),
    ('ablation_02_bddr_v2', 'BDDR'),
    ('ablation_stage2_msca_bddr_mixed', 'BDDR+MSCA'),
    ('ablation_stage2_msca_bddr_mixed_atc', 'BDDR+MSCA+ATC'),
]

dataset = get_dataset(DATASET_NAME)
print(f"Evaluating {len(dataset)} sequences on {DATASET_NAME}\n")

results = {}
for cfg_name, display in TRACKER_CONFIGS:
    trackers = trackerlist('avtrack', cfg_name, DATASET_NAME, None, display)
    trk = trackers[0]

    all_success_curves = []
    all_prec = []
    missing = 0

    for seq in tqdm(dataset, desc=f"{display}"):
        results_path = '{}/{}/{}.txt'.format(trk.results_dir, DATASET_NAME, seq.name)
        if not os.path.isfile(results_path):
            missing += 1
            continue

        anno_bb = torch.tensor(seq.ground_truth_rect)
        pred_bb = torch.tensor(load_text(results_path, delimiter=('\t', ','), dtype=np.float64))

        err_overlap, err_center, _, valid = calc_seq_err_robust(
            pred_bb, anno_bb, seq.dataset, None)

        valid_overlap = err_overlap[valid]
        valid_center = err_center[valid]
        seq_len = anno_bb.shape[0]

        if seq_len > 0:
            success = (valid_overlap.view(-1, 1) > THRESHOLDS.view(1, -1)).sum(0).float() / seq_len
            all_success_curves.append(success)
            prec = (valid_center <= 20).float().mean().item()
            all_prec.append(prec)

    if missing > 0:
        print(f"  [{display}] missing {missing}/{len(dataset)} sequences")

    if len(all_success_curves) > 0:
        curves = torch.stack(all_success_curves)
        mean_curve = curves.mean(dim=0)
        auc = torch.trapz(mean_curve, THRESHOLDS).item()
        avg_prec = np.mean(all_prec)
        results[display] = (auc, avg_prec)
    else:
        results[display] = (None, None)

print(f"\n{'='*60}")
print(f"  {DATASET_NAME.upper()} Ablation Results")
print(f"{'='*60}")
print(f"{'Tracker':<20} {'AUC':>10} {'Prec@20':>10}")
print(f"{'-'*42}")
for _, display in TRACKER_CONFIGS:
    auc, prec = results[display]
    if auc is not None:
        print(f"{display:<20} {auc:>10.4f} {prec:>10.4f}")
    else:
        print(f"{display:<20} {'N/A':>10} {'N/A':>10}")
print(f"{'='*60}\n")
